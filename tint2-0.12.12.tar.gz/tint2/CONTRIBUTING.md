Please read https://gitlab.com/o9000/tint2/wikis/Development
