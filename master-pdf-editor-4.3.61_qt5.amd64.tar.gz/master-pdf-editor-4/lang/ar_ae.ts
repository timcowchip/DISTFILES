<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ar_SA" sourcelanguage="en">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>حول</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="60"/>
        <source>Ok</source>
        <translation>موافق</translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="14"/>
        <source>Document Actions</source>
        <translation>إجراءات المستند</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="86"/>
        <source>Edit</source>
        <translation>تحرير</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="93"/>
        <source>Java Script</source>
        <translation>جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="20"/>
        <source>Actions</source>
        <translation>الإجراءات</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="42"/>
        <source>Document Will Close</source>
        <translation>مستند ستغلق</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="47"/>
        <source>Document Will Save</source>
        <translation>مستند سيحفظ</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="52"/>
        <source>Document Did Save</source>
        <translation>مستند لم يحفظ</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="57"/>
        <source>Document Will Print</source>
        <translation>سيتم طباعة المستند</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="62"/>
        <source>Document Did Print</source>
        <translation>مستند طبع</translation>
    </message>
</context>
<context>
    <name>AnnotTextInspectorDlg</name>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="14"/>
        <source>Format</source>
        <translation>صيغة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="20"/>
        <source>Text</source>
        <translation>نص</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="174"/>
        <source>Borders and Colors</source>
        <translation>الحدود والألوان</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="184"/>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="189"/>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="194"/>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="199"/>
        <source>3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="204"/>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="209"/>
        <source>5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="214"/>
        <source>6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="219"/>
        <source>7</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="224"/>
        <source>8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="229"/>
        <source>9</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="234"/>
        <source>10</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="242"/>
        <source>Border Color</source>
        <translation>لون الحد</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="249"/>
        <source>Fill Color</source>
        <translation>لون التعبئة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="257"/>
        <source>Solid</source>
        <translation>صلب</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="262"/>
        <source>Dashed</source>
        <translation>متقطع</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="270"/>
        <source>Line Style</source>
        <translation>نمط الخط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="277"/>
        <source>Line Width</source>
        <translation>عرض الخط</translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="14"/>
        <source>Appearance Options</source>
        <translation>خيارات المظهر</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="20"/>
        <source>Show when printing</source>
        <translation>إظهار عند الطباعة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="27"/>
        <source>Show when displaying on screen</source>
        <translation>إظهار عند العرض على الشاشة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="34"/>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation>الحفاظ على موقع وحجم نص العلامة المائية ثابتة عند الطباعة على أحجام الصفحات المختلفة</translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="14"/>
        <source>Background</source>
        <translation>الخلفية</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="20"/>
        <source>Saved Settings</source>
        <translation>الإعدادات المحفوظة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="39"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="53"/>
        <source>None</source>
        <translation>لاشيء</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="61"/>
        <source>Save</source>
        <translation>حفظ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="71"/>
        <source>Source</source>
        <translation>مصدر</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="77"/>
        <source>File</source>
        <translation>ملف</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="91"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="299"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="305"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="375"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="381"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="407"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="506"/>
        <source>Total pages :</source>
        <translation>مجموع الصفحات:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="98"/>
        <source>Color</source>
        <translation>لون</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="118"/>
        <source>Page Number</source>
        <translation>رقم الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="134"/>
        <source>Browse</source>
        <translation>استعراض</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="167"/>
        <source>Scale</source>
        <translation>مقياس</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="193"/>
        <source>Appearance</source>
        <translation>مظهر</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="199"/>
        <source>Rotation</source>
        <translation>دوران</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="217"/>
        <source>Options</source>
        <translation>الخيارات</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="237"/>
        <source>Opacity</source>
        <translation>العتامه</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="293"/>
        <source>Scale relative to target page</source>
        <translation>مقياس نسبه إلى الصفحة المستهدفة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="303"/>
        <source>Position</source>
        <translation>موقع</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="309"/>
        <source>Vertical distance</source>
        <translation>مسافة عموديه</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="323"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="382"/>
        <source>from</source>
        <translation>من</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="337"/>
        <source>Top</source>
        <translation>أعلى</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="342"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="398"/>
        <source>Center</source>
        <translation>توسيط</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="347"/>
        <source>Bottom</source>
        <translation>اسفل</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="368"/>
        <source>Horizontal distance</source>
        <translation>مسافة أفقيه</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="393"/>
        <source>Left</source>
        <translation>يسار</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="403"/>
        <source>Right</source>
        <translation>يمين</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="411"/>
        <source>Units</source>
        <translation>وحدات</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="419"/>
        <source>Points</source>
        <translation>نقاط</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="424"/>
        <source>Inches</source>
        <translation>بوصه</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="429"/>
        <source>Millimeters</source>
        <translation>ملليمتر</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="461"/>
        <source>Page Range Options...</source>
        <translation>خيارات نطاق الصفحة...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="123"/>
        <source>Save Settings</source>
        <translation>حفظ الإعدادات</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="123"/>
        <source>Save current settings as:</source>
        <translation>حفظ الإعدادات الحالية ك:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="133"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>الإعدادات بهذا الاسم موجودة بالفعل. هل تريد استبدال الإعدادات القديمة ؟</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="168"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>هل تريد بالتاكيد حذف الاعداد</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="168"/>
        <source> ?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="229"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="245"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="263"/>
        <source> mm</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="283"/>
        <source>Open File</source>
        <translation>فتح ملف</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="283"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>(*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm) كل الملفات المدعومة </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="309"/>
        <source>There was an error opening the document !</source>
        <translation>حدث خطا اثناء فتح المستند!</translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation>خصائص  قائمة العناوين</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation>الخيارات</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation>نص</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="83"/>
        <source>Set current position</source>
        <translation>تعيين الموقع الحالي</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="93"/>
        <source>Appearance</source>
        <translation>مظهر</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="112"/>
        <source>Style</source>
        <translation>نمط</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="126"/>
        <source>Plain</source>
        <translation>سهل</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="131"/>
        <source>Italic</source>
        <translation>مائل</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="136"/>
        <source>Bold</source>
        <translation>غامق</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="141"/>
        <source>Italic &amp; Bold</source>
        <translation>غامق &amp; مائل</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="162"/>
        <source>Color</source>
        <translation>لون</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation>رقم الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="176"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="289"/>
        <source>Actions</source>
        <translation>الإجراءات</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="348"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="329"/>
        <source>Edit</source>
        <translation>تحرير</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="182"/>
        <source>Add an Action</source>
        <translation>أضافه اجراء</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="217"/>
        <source>Trigger</source>
        <translation>حافز</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="201"/>
        <source>Action</source>
        <translation>اجراء</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="209"/>
        <source>Mouse Up</source>
        <translation>فأر فوق</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="225"/>
        <source>Goto a Page View</source>
        <translation>انتقل إلى عرض الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="230"/>
        <source>Open/execute a File</source>
        <translation>فتح/تنفيذ ملف</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="235"/>
        <source>Open a web link</source>
        <translation>فتح ارتباط ويب</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="240"/>
        <source>Reset form</source>
        <translation>أعاده تعيين النموذج</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="245"/>
        <source>Show/Hide fields</source>
        <translation>إظهار/إخفاء الحقول</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="250"/>
        <source>Submit a form</source>
        <translation>إرسال نموذج</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="255"/>
        <source>Run a JavaScript</source>
        <translation>تشغيل جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="263"/>
        <source>Add</source>
        <translation>اضافة</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="66"/>
        <source>untitled</source>
        <translation>معنونة</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="208"/>
        <source>Do you want to set the current position?</source>
        <translation>هل تريد تعيين الموضع الحالي ؟</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="210"/>
        <source>Custom</source>
        <translation>مخصص</translation>
    </message>
</context>
<context>
    <name>CombineFilesDlg</name>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="14"/>
        <source>Create a new document from files</source>
        <translation>إنشاء مستند جديد من الملفات</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="154"/>
        <source>Output</source>
        <translation>ناتج</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="221"/>
        <source>Append to Current Document </source>
        <translation>إلحاق بالمستند الحالي</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="228"/>
        <source>Create New Document</source>
        <translation>إنشاء مستند جديد</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="163"/>
        <source>Position</source>
        <translation>موقع</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="169"/>
        <source>Before current page</source>
        <translation>قبل الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="179"/>
        <source>After last page</source>
        <translation>بعد الصفحة الاخيره</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="186"/>
        <source>After current page</source>
        <translation>بعد الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="196"/>
        <source>Before first page</source>
        <translation>قبل الصفحة الاولي</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="23"/>
        <source>Add Files</source>
        <translation>اضافة ملفات</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="40"/>
        <source>Add Folder</source>
        <translation>اضافة مجلد</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="98"/>
        <source>Up</source>
        <translation>اعلى</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="109"/>
        <source>Down</source>
        <translation>اسفل</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="120"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="144"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="61"/>
        <source>Page Range</source>
        <translation>نطاق الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="61"/>
        <source>File Name</source>
        <translation>اسم الملف</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="244"/>
        <source>Browse</source>
        <translation>استعراض</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="41"/>
        <source>Save</source>
        <translation>حفظ</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="56"/>
        <source>untitled</source>
        <translation>معنونة</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="61"/>
        <source>Total pages</source>
        <translation>مجموع الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="299"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="506"/>
        <source>Save As PDF</source>
        <translation>حفظ باسم مستند محمول</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="301"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="508"/>
        <source>PDF Files (*.pdf)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="331"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="335"/>
        <source>Open</source>
        <translation>فتح</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="332"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="336"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>(*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm) كل الملفات المدعومة </translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="363"/>
        <source>Select directory</source>
        <translation>تحديد الدليل</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="536"/>
        <source>Save failed</source>
        <translation>فشل الحفظ</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="537"/>
        <source>Can&apos;t save to the file:</source>
        <translation>لا يمكن الحفظ إلى الملف:</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="537"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
قد يكون الملف للقراءة فقط أو مستخدم من قبل تطبيق آخر.</translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation>حذف الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="26"/>
        <source>Page Range</source>
        <translation>نطاق الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="32"/>
        <source>Pages</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation>العينة: 1 ، 6-8 ، 12</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="78"/>
        <source>Current Page</source>
        <translation>الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="88"/>
        <source>Pages from</source>
        <translation>صفحات من</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="114"/>
        <source>to:</source>
        <translation>الى:</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="140"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>لا يمكن استرداد الصفحات التي تمت ازالتها مع عمليه التراجع.</translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="14"/>
        <source>Distance Tool</source>
        <translation>أداه المسافة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="36"/>
        <source>Measurement</source>
        <translation>قياس</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="71"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="98"/>
        <source>Distance:</source>
        <translation>مسافة:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="91"/>
        <source>Angle:</source>
        <translation>زاوية:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="121"/>
        <source>Cursor Location</source>
        <translation>موقع المؤشر</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="140"/>
        <source>X:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="160"/>
        <source>Y:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="183"/>
        <source>Units and Markup Settings</source>
        <translation>إعدادات الوحدات والعلامات</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="270"/>
        <source>Scale Ratio:</source>
        <translation>نسبه الجدول:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="190"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="245"/>
        <source>pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="195"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="250"/>
        <source>in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="200"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="255"/>
        <source>mm</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="263"/>
        <source>=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="277"/>
        <source>Annotation:</source>
        <translation>توضيحي:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="61"/>
        <source>°</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="24"/>
        <source>Distance</source>
        <translation>مسافة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="28"/>
        <source>Perimeter</source>
        <translation>محيط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="35"/>
        <source>Area</source>
        <translation>منطقة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="38"/>
        <source> sq</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="198"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="201"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="205"/>
        <source> mm</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>DlgIconPlacement</name>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="14"/>
        <source>Icon Placement</source>
        <translation>موضع الايقونة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="20"/>
        <source>Fit to bounds</source>
        <translation>ملائمة للحدود</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="27"/>
        <source>When to scale:</source>
        <translation>متى يتم قياس:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="35"/>
        <source>Proportionally</source>
        <translation>متناسب</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="40"/>
        <source>Non-Proportionally</source>
        <translation>غير متناسب</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="103"/>
        <source>Button</source>
        <translation>زر</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="204"/>
        <source>Scale:</source>
        <translation>مقياس:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="222"/>
        <source>Always</source>
        <translation>دائما</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="227"/>
        <source>Never</source>
        <translation>ابدا</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="232"/>
        <source>Icon is too big</source>
        <translation>الايقونه كبيره جدا</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="237"/>
        <source>Icon is too small</source>
        <translation>الايقونة صغيرة جدا</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="245"/>
        <source>Use this dialog to change the way the icon is scaled to fit inside the button</source>
        <translation>استخدم مربع الحوار هذا لتغيير الطريقة التي يتم بها تحجيم الايقونة  لاحتواءه داخل الزر</translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="14"/>
        <source>Page Number and Date Format</source>
        <translation>رقم الصفحة وتنسيق التاريخ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="26"/>
        <source>Date Format</source>
        <translation>تنسيق التاريخ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="56"/>
        <source>Page Number Format</source>
        <translation>تنسيق رقم الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="82"/>
        <source>Start Page Number</source>
        <translation>رقم صفحه البدء</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="43"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="46"/>
        <source>of</source>
        <translation>من</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="45"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="46"/>
        <source>Page</source>
        <translation>صفحة</translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="14"/>
        <source>Page Range Options</source>
        <translation>خيارات نطاق الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="23"/>
        <source>Page Range</source>
        <translation>نطاق الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="69"/>
        <source>Sample: 1,6-8,12</source>
        <translation>العينة: 1 ، 6-8 ، 12</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="90"/>
        <source>Even and Odd pages</source>
        <translation>وحتى الصفحات الفردية</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="95"/>
        <source>Even pages</source>
        <translation>حتى صفحات</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="100"/>
        <source>Odd pages</source>
        <translation>الصفحات الفردية</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="39"/>
        <source>Pages</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="29"/>
        <source>All Pages</source>
        <translation>كل الصفحات</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="20"/>
        <source>Cut</source>
        <translation>قطع</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="21"/>
        <source>Copy</source>
        <translation>نسخ</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="22"/>
        <source>Paste</source>
        <translation>لصق</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="23"/>
        <source>Select All</source>
        <translation>حدد الكل</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="30"/>
        <source>Add Sticky Note</source>
        <translation>أضافه ملاحظه دبقة</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="31"/>
        <source>Highlight Text</source>
        <translation>تمييز النص</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="32"/>
        <source>Strikeout Text</source>
        <translation>نص مشطوب</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="33"/>
        <source>Underline Text</source>
        <translation>تسطير النص</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="34"/>
        <source>Add Bookmark</source>
        <translation>اضافة قائمةَ العناوين</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1614"/>
        <location filename="../../src/docpage/docpage.cpp" line="1655"/>
        <source>Goto a Page View</source>
        <translation>انتقل إلى عرض الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1623"/>
        <source>Open a web link</source>
        <translation>فتح ارتباط ويب</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1633"/>
        <source>Open/execute a File</source>
        <translation>فتح/تنفيذ ملف</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1645"/>
        <source>Run a JavaScript</source>
        <translation>تشغيل جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2599"/>
        <source>Open File</source>
        <translation>فتح ملف</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="104"/>
        <source>Copy</source>
        <translation>نسخ</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="105"/>
        <source>Cut</source>
        <translation>قطع</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="106"/>
        <source>Paste</source>
        <translation>لصق</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="107"/>
        <source>Select All</source>
        <translation>حدد الكل</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="108"/>
        <source>Options</source>
        <translation>الخيارات</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="109"/>
        <source>Edit text</source>
        <translation>تحرير نص</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="110"/>
        <source>Signature options</source>
        <translation>خيارات التوقيع</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="111"/>
        <source>Undo</source>
        <translation>تراجع</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="112"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="113"/>
        <source>Set Fit to Page</source>
        <translation>تعيين ملاءمة إلى الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="114"/>
        <source>Save Image to file</source>
        <translation>حفظ الصورة إلى ملف</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1052"/>
        <source>Save As...</source>
        <translation>حفظ باسم...</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1054"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1064"/>
        <source>PNG Images (*.png)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2158"/>
        <source>Open Image</source>
        <translation>فتح الصورة</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2158"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>(*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm) ملف الصور</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2195"/>
        <source>ERROR Loading Image !</source>
        <translation>خطا في تحميل الصورة!</translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation>اجراء</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation>محرر جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="165"/>
        <source>Show</source>
        <translation>اظهار</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="77"/>
        <location filename="../../src/forms/EditActionForm.ui" line="83"/>
        <location filename="../../src/forms/EditActionForm.ui" line="232"/>
        <source>Select Fields</source>
        <translation>تحديد الحقول</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="126"/>
        <location filename="../../src/forms/EditActionForm.ui" line="258"/>
        <source>Deselect All</source>
        <translation>إلغاء تحديد الكل</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="152"/>
        <source>Hide</source>
        <translation>إخفاء</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="113"/>
        <location filename="../../src/forms/EditActionForm.ui" line="238"/>
        <source>Select All</source>
        <translation>حدد الكل</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="323"/>
        <source>Browse</source>
        <translation>استعراض</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="179"/>
        <source>Format</source>
        <translation>صيغة</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="185"/>
        <source>FDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="195"/>
        <source>HTML</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="202"/>
        <source>XFDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="209"/>
        <source>PDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="271"/>
        <source>Method</source>
        <translation>طريقة</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="278"/>
        <source>Local file</source>
        <translation>ملف محلي</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="283"/>
        <source>E-mail</source>
        <translation>بريد الكتروني</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="288"/>
        <source>FTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="293"/>
        <source>HTTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="336"/>
        <source>Use anonymous</source>
        <translation>استخدام مجهول</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="346"/>
        <source>Need user name and password</source>
        <translation>بحاجة إلى اسم المستخدم وكلمه السر</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="356"/>
        <source>User name</source>
        <translation>اسم المستخدم</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="383"/>
        <source>Password</source>
        <translation>كلمة السر</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="109"/>
        <source>Open File</source>
        <translation>فتح ملف</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="111"/>
        <source>All Files (*.*)</source>
        <translation>كل الملفات (*. *)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="181"/>
        <source>Show/Hide Fields</source>
        <translation>إظهار/إخفاء الحقول</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="185"/>
        <source>Select Field</source>
        <translation>تحديد الحقل</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="215"/>
        <source>Reset Form</source>
        <translation>أعاده تعيين النموذج</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Action</source>
        <translation>اجراء</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="90"/>
        <source>Open/execute a File</source>
        <translation>فتح/تنفيذ ملف</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="91"/>
        <source>Enter a file:</source>
        <translation>ادخل ملف:</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation>استعراض</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation>انتقل للصفحة</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="82"/>
        <source>Page Number</source>
        <translation>رقم الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="89"/>
        <source>Zoom Mode</source>
        <translation>وضع تكبير/تصغير</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="96"/>
        <source>Zoom (%)</source>
        <translation>تكبير/تصغير (%)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="103"/>
        <source>X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="110"/>
        <source>Y</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="134"/>
        <source>Custom</source>
        <translation>مخصص</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="139"/>
        <source>Fit Page</source>
        <translation>ملاءمة الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="144"/>
        <source>Fit Width</source>
        <translation>ملائمة العرض</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="149"/>
        <source>Fit Height</source>
        <translation>ملائمة الارتفاع</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="154"/>
        <source>Fit Visible</source>
        <translation>ملائمة مرئية</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="162"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="178"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="194"/>
        <source>auto</source>
        <translation>تلقائي</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="181"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="197"/>
        <source> px</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="98"/>
        <source>Open a web link</source>
        <translation>فتح ارتباط ويب</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Enter a web site:</source>
        <translation>ادخل موقع ويب:</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="106"/>
        <source>Named Action</source>
        <translation>اجراء مسمي</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="160"/>
        <source>Open File</source>
        <translation>فتح ملف</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="162"/>
        <source>All Files (*.*)</source>
        <translation>كل الملفات (*. *)</translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation>استخراج الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>اسم الملف</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>استعراض</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="67"/>
        <source>Page Range</source>
        <translation>نطاق الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="73"/>
        <source>Current Page</source>
        <translation>الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="83"/>
        <source>All Pages</source>
        <translation>كل الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="93"/>
        <source>Pages</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="123"/>
        <source>Sample: 1,6-8,12</source>
        <translation>العينة: 1 ، 6-8 ، 12</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="133"/>
        <source>Extract pages as a single file</source>
        <translation>استخراج الصفحات كملف واحد</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="143"/>
        <source>Export Bookmarks</source>
        <translation>تصدير قوائم العناوين </translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation>موافق</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="34"/>
        <location filename="../../src/ExportPageDialog.cpp" line="72"/>
        <source>Export Pages</source>
        <translation>تصدير الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="111"/>
        <source>Save As PDF</source>
        <translation>حفظ باسم PDF</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="113"/>
        <source>PDF Files (*.pdf)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="144"/>
        <location filename="../../src/ExportPageDialog.cpp" line="171"/>
        <source>Can&apos;t save to the file:</source>
        <translation>لا يمكن الحفظ إلى الملف:</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="144"/>
        <location filename="../../src/ExportPageDialog.cpp" line="171"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
قد يكون الملف للقراءة فقط أو مستخدم من قبل تطبيق آخر.</translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="14"/>
        <location filename="../../src/ExportTextDialog.cpp" line="87"/>
        <source>Export to text</source>
        <translation>تصدير إلى نص</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>اسم الملف</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>استعراض</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="67"/>
        <source>Page Range</source>
        <translation>نطاق الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="73"/>
        <source>Current Page</source>
        <translation>الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="83"/>
        <source>All Pages</source>
        <translation>كل الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="93"/>
        <source>Pages</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="123"/>
        <source>Sample: 1,6-8,12</source>
        <translation>العينة: 1 ، 6-8 ، 12</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="133"/>
        <source>Extract pages as a single file</source>
        <translation>استخراج الصفحات كملف واحد</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="10"/>
        <source>Export</source>
        <translation>تصدير</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="89"/>
        <source>txt files (*.txt)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="119"/>
        <location filename="../../src/ExportTextDialog.cpp" line="146"/>
        <source>Can&apos;t save to the file:</source>
        <translation>لا يمكن الحفظ إلى الملف:</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="119"/>
        <location filename="../../src/ExportTextDialog.cpp" line="146"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
قد يكون الملف للقراءة فقط أو مستخدم من قبل تطبيق آخر.</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation>خصائص المستند</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation>معلومات الوثيقة</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation>معلومات PDF</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation>العنوان</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation>الموضوع</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation>المؤلف</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation>كلمات رئيسية</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation>الخالق</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation>المنتج</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation>الامن</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="197"/>
        <source>Printing the document</source>
        <translation>طباعه المستند</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="184"/>
        <source>Print a high resolution version of the document</source>
        <translation>طباعه إصدار عالي الدقة من المستند</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="249"/>
        <source>Modifying document</source>
        <translation>تعديل المستند</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="210"/>
        <source>Fill in existing form or signature fields</source>
        <translation>تعبئة حقول النموذج أو التوقيع الموجودة</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="262"/>
        <source>Manage Pages and bookmarks</source>
        <translation>أداره الصفحات و قوائم العناوين </translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="123"/>
        <source>No Encryption</source>
        <translation>بلا تشفير</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="128"/>
        <source>Password Encryption</source>
        <translation>تشفير كلمه السر</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="136"/>
        <source>Change</source>
        <translation>تغيير</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="156"/>
        <source>Permissions</source>
        <translation>أذونات</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="171"/>
        <source>Extract the content of the document</source>
        <translation>استخراج محتوي المستند</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="223"/>
        <source>Content copying for accessibility</source>
        <translation>نسخ المحتوي لامكانيه الوصول</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="236"/>
        <source>Commenting</source>
        <translation>تعليق</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="308"/>
        <source>Initial View</source>
        <translation>العرض الاولي</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="314"/>
        <source>User Interface Options</source>
        <translation>خيارات واجهه المستخدم</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="320"/>
        <source>Hide tool bar</source>
        <translation>إخفاء شريط الاداوات</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="327"/>
        <source>Hide menu bar</source>
        <translation>إخفاء شريط القوائم</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="334"/>
        <source>Hide Window Controls</source>
        <translation>إخفاء عناصر تحكم الإطارات</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="344"/>
        <source>Windows Options</source>
        <translation>خيارات النوافذ</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="364"/>
        <source>Center window on screen</source>
        <translation>نافذه المركز علي الشاشة</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="350"/>
        <source>Display document title</source>
        <translation>عرض عنوان المستند</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="357"/>
        <source>Open in Full Screen mode</source>
        <translation>فتح في وضع ملء الشاشة</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="387"/>
        <source>Layout and Destination</source>
        <translation>التخطيط و الوجهة</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="493"/>
        <source>Navigation Tab:</source>
        <translation>تبويب التنقل:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="536"/>
        <source>Page layout:</source>
        <translation>تخطيط الصفحة:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="410"/>
        <location filename="../../src/FileSettings.ui" line="544"/>
        <location filename="../../src/FileSettings.cpp" line="218"/>
        <source>Default</source>
        <translation>افتراضي</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="549"/>
        <source>Single Page</source>
        <translation>صفحه واحده</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="554"/>
        <source>Single Page Continuous</source>
        <translation>صفحه واحده مستمرة</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="559"/>
        <source>Two-Up (Facing)</source>
        <translation>اثنان - أعلى (مواجهة)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="564"/>
        <source>Two-Up Continuous (Facing)</source>
        <translation>اثنين - حتى المستمر (مواجهة)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="569"/>
        <source>Two-Up (Cover Page)</source>
        <translation>اثنان - أعلى (صفحة الغلاف)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="574"/>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation>اثنان - متابعة مستمرة (صفحة الغلاف)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="529"/>
        <source>Zoom</source>
        <translation>تكبير/تصغير</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="415"/>
        <location filename="../../src/FileSettings.cpp" line="223"/>
        <source>Actual Size</source>
        <translation>الحجم الفعلي</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="420"/>
        <location filename="../../src/FileSettings.cpp" line="228"/>
        <source>Fit Page</source>
        <translation>ملاءمة الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="425"/>
        <location filename="../../src/FileSettings.cpp" line="233"/>
        <source>Fit Width</source>
        <translation>ملائمة العرض</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="430"/>
        <location filename="../../src/FileSettings.cpp" line="238"/>
        <source>Fit Height</source>
        <translation>ملائمة الارتفاع</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="435"/>
        <location filename="../../src/FileSettings.cpp" line="243"/>
        <source>Fit Visible</source>
        <translation>ملائمة مرئية</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="440"/>
        <source>25%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="445"/>
        <source>50%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="450"/>
        <source>75%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="455"/>
        <source>100%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="460"/>
        <source>125%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="465"/>
        <source>150%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="470"/>
        <source>200%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="475"/>
        <source>300%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="480"/>
        <source>400%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="485"/>
        <source>600%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="501"/>
        <source>Page Only</source>
        <translation>الصفحة فقط</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="506"/>
        <source>Bookmarks Panel</source>
        <translation>لوحة قوائم العناوين</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="511"/>
        <source>Pages Panel</source>
        <translation>لوحه الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="521"/>
        <source>Attachments Panel</source>
        <translation>لوحه المرفقات</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="632"/>
        <location filename="../../src/FileSettings.ui" line="722"/>
        <source>Actions</source>
        <translation>الإجراءات</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="638"/>
        <source>Document Open Actions</source>
        <translation>إجراءات المستندات المفتوحة</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="644"/>
        <source>Add an Action</source>
        <translation>أضافه اجراء</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="664"/>
        <source>Goto a Page View</source>
        <translation>انتقل إلى عرض الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="669"/>
        <source>Open/execute a File</source>
        <translation>فتح/تنفيذ ملف</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="674"/>
        <source>Open a web link</source>
        <translation>فتح ارتباط ويب</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="679"/>
        <source>Reset form</source>
        <translation>أعاده تعيين النموذج</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="684"/>
        <source>Show/Hide fields</source>
        <translation>إظهار/إخفاء الحقول</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="689"/>
        <source>Submit a form</source>
        <translation>إرسال نموذج</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="694"/>
        <source>Run a JavaScript</source>
        <translation>تشغيل جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="702"/>
        <source>Action</source>
        <translation>اجراء</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="709"/>
        <source>Add</source>
        <translation>اضافة</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="737"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="778"/>
        <source>Edit</source>
        <translation>تحرير</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="516"/>
        <source>Layers Panel</source>
        <translation>لوحه الطبقات</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="582"/>
        <source>Open to Page:</source>
        <translation>فتح للصفحة:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="589"/>
        <source>of :</source>
        <translation>من:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="607"/>
        <source>Fonts</source>
        <translation>خطوط</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="623"/>
        <source>Fonts used in this document</source>
        <translation>الخطوط المستخدمة في هذا المستند</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="684"/>
        <source>Password</source>
        <translation>كلمة السر</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="685"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>المستند محمي. الرجاء إدخال كلمه سر أذونات:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="702"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>كلمه سر غير صحيحه. الرجاء إدخال كلمه سر المالك.</translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="14"/>
        <source>Header &amp; Footer</source>
        <translation>العنوان الرأسي &amp; الهامش</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="130"/>
        <source>Top margin</source>
        <translation>الهامش العلوي</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="94"/>
        <source>Right margin</source>
        <translation>الهامش الأيمن</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="153"/>
        <source>Bottom margin</source>
        <translation>الهامش السفلي</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="71"/>
        <source>Left margin</source>
        <translation>الهامش الأيسر</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="32"/>
        <source>Units</source>
        <translation>وحدات</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="189"/>
        <source>Font</source>
        <translation>خط</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="195"/>
        <source>Color</source>
        <translation>لون</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="215"/>
        <source>Size</source>
        <translation>حجم</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="235"/>
        <source>Font Family</source>
        <translation>عائله الخط</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="352"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="366"/>
        <source>None</source>
        <translation>لاشيء</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="374"/>
        <source>Save</source>
        <translation>حفظ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="288"/>
        <source>Right Footer Text</source>
        <translation>نص التذييل الأيمن</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="20"/>
        <source>Margins</source>
        <translation>الهوامش</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="40"/>
        <source>Points</source>
        <translation>نقاط</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="45"/>
        <source>Inches</source>
        <translation>بوصه</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="50"/>
        <source>Millimeters</source>
        <translation>ملليمتر</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="295"/>
        <source>Center Header Text</source>
        <translation>نَص العنوان الرأسي المركزيِ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="302"/>
        <source>Left Footer Text</source>
        <translation>نَص الهامش اليسار</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="309"/>
        <source>Right Header Text</source>
        <translation>نَص الهامش الايمن</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="316"/>
        <source>Center Footer Text</source>
        <translation>نص الهامش المركزيِ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="323"/>
        <source>Left Header Text</source>
        <translation>نص العنوان الرأسي اليسار</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="333"/>
        <source>Saved Settings</source>
        <translation>الإعدادات المحفوظة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="427"/>
        <source>Insert Date</source>
        <translation>تاريخ الادراج</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="420"/>
        <source>Insert Page Number</source>
        <translation>ادراج رقم الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="410"/>
        <source>Page number and date format</source>
        <translation>رقم الصفحة وتنسيق التاريخ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="392"/>
        <source>Page Range Options...</source>
        <translation>خيارات نطاق الصفحة...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="298"/>
        <source>Save Settings</source>
        <translation>حفظ الإعدادات</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="298"/>
        <source>Save current settings as:</source>
        <translation>حفظ الإعدادات الحالية ك:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="308"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>الإعدادات بهذا الاسم موجودة بالفعل. هل تريد استبدال الإعدادات القديمة ؟</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="343"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>هل تريد بالتاكيد حذف الاعداد</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="343"/>
        <source> ?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="456"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="476"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="496"/>
        <source> mm</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="14"/>
        <source>Insert Pages</source>
        <translation>ادراج صفحات</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="26"/>
        <source>Before page</source>
        <translation>قبل الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="78"/>
        <source>After page</source>
        <translation>بعد الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="178"/>
        <source>Page Range</source>
        <translation>نطاق الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="184"/>
        <source>All Pages</source>
        <translation>كل الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="194"/>
        <source>Pages</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="220"/>
        <source>Sample: 1,6-8,12</source>
        <translation>العينة: 1 ، 6-8 ، 12</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="230"/>
        <source>Import Bookmarks</source>
        <translation>إستيراد قوائم العناوين </translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="130"/>
        <source>File Name</source>
        <translation>اسم الملف</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="165"/>
        <source>Browse</source>
        <translation>استعراض</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="145"/>
        <location filename="../../src/ImportPageDialog.cpp" line="192"/>
        <source>Total pages :</source>
        <translation>مجموع الصفحات:</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="20"/>
        <source>Position</source>
        <translation>موقع</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="107"/>
        <source>After last page</source>
        <translation>بعد الصفحة الاخيره</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="58"/>
        <source>Before first page</source>
        <translation>قبل الصفحة الاولي</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation>موافق</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="116"/>
        <source>Open File</source>
        <translation>فتح ملف</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="116"/>
        <source>PDF Files (*.pdf)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="146"/>
        <source>Password</source>
        <translation>كلمة السر</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="147"/>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation>الملف محمي. الرجاء إدخال كلمه سر لفتح المستند:</translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="185"/>
        <source>Read Error: This PDF is protected.</source>
        <translation>قراءه خطا: هذا المستند المحمول محمي.</translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="14"/>
        <source>Install languages</source>
        <translation>تثبيت اللغات</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="37"/>
        <source>Languages</source>
        <translation>اللغات</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="37"/>
        <source>Install</source>
        <translation>تثبيت</translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="14"/>
        <source>JavaScript Console</source>
        <translation>وحدة تحكم جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="36"/>
        <source>Run</source>
        <translation>تشغيل</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="43"/>
        <source>Clear</source>
        <translation>تنظيف</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="50"/>
        <source>Close</source>
        <translation>اغلاق</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="57"/>
        <source>Stays On Top</source>
        <translation>يبقي علي القمه</translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="14"/>
        <source>Document JavaScript</source>
        <translation>وثيقة جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="20"/>
        <source>Function Name</source>
        <translation>اسم الوظيفة</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="45"/>
        <source>Add</source>
        <translation>اضافة</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="52"/>
        <source>Edit</source>
        <translation>تحرير</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="59"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation>محرر جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation>اسم الوظيفة</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation>جافا سكريبت</translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="121"/>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="200"/>
        <source>Press shortcut</source>
        <translation>اختصار الضغط</translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsDlg</name>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="20"/>
        <source>Keyboard shortcuts</source>
        <translation>اختصارات لوحه المفاتيح</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="39"/>
        <source>Reset All</source>
        <translation>أعاده تعيين الكل</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="46"/>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="84"/>
        <source>Shortcut</source>
        <translation>اختصار</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="52"/>
        <source>Reset</source>
        <translation>أعاده</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="79"/>
        <source>Command</source>
        <translation>أمر</translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="743"/>
        <source> ms</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1703"/>
        <source>Smooth text and images</source>
        <translation>النص السلس والصور</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="759"/>
        <source>Time before a move or resize starts:</source>
        <translation>الوقت قبل بدء التحرك أو تغيير الحجم:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="772"/>
        <source>Select item by hovering the mouse</source>
        <translation>حدد العنصر عن طريق تحريك الماوس</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="122"/>
        <source>Saving Documents</source>
        <translation>حفظ المستندات</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="162"/>
        <source>Create backup file</source>
        <translation>إنشاء ملف النسخ الاحتياطي</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="148"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>اختيار الوجهة للمستندات &quot;حفظ باسم&quot;</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="135"/>
        <source>Last used folder</source>
        <translation>آخر مجلد مستخدم</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="140"/>
        <source>Original documents folder</source>
        <translation>مجلد المستندات الأصلية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="272"/>
        <source>Required field highlight color</source>
        <translation>لون تمييز الحقل المطلوب</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="252"/>
        <source>Highlight color</source>
        <translation>تمييز اللون</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="795"/>
        <source>Default font</source>
        <translation>الخط الافتراضي</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2554"/>
        <source>Built-in</source>
        <translation>مدمج</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2540"/>
        <source>Please choose the interface language</source>
        <translation>الرجاء اختيار لغة الواجهة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="993"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1013"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1079"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1086"/>
        <source>pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1967"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2575"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>يجب إعادة تشغيل البرنامج حتى تصبح التغييرات نافذة المفعول.</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1857"/>
        <source>Selected text color</source>
        <translation>لون النص المحدد</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1870"/>
        <source>Icon set</source>
        <translation>مجموعة أيقونة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1906"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="729"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1018"/>
        <source>Default</source>
        <translation>افتراضي</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1924"/>
        <source>Application Style</source>
        <translation>نمط التطبيق</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1987"/>
        <source>Use default program</source>
        <translation>استخدام البرنامج الافتراضي</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2006"/>
        <source>evolution</source>
        <translation>تطور</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2011"/>
        <source>kmail</source>
        <translation>م بريد</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2016"/>
        <source>thunderbird</source>
        <translation>طائر الرعد</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2024"/>
        <source>Use SMTP</source>
        <translation>استخدام SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2047"/>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2135"/>
        <source>Email address</source>
        <translation>عنوان البريد الإلكتروني</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2128"/>
        <source>Secure connections</source>
        <translation>اتصالات آمنة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2103"/>
        <source>NONE</source>
        <translation>لاشيء</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2108"/>
        <source>SSL</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2113"/>
        <source>STARTTLS</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2095"/>
        <source>SMTP server</source>
        <translation>ملقم SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2085"/>
        <source>User</source>
        <translation>مستخدم</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2121"/>
        <source>SMTP port</source>
        <translation>ملقم SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2068"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2465"/>
        <source>Password</source>
        <translation>كلمة السر</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="954"/>
        <source>Points</source>
        <translation>نقاط</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="959"/>
        <source>Inches</source>
        <translation>بوصه</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="964"/>
        <source>Millimeters</source>
        <translation>ملليمتر</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1664"/>
        <source>Always show Object Inspector</source>
        <translation>إظهار دائما الكائن المفتش</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1693"/>
        <source>Forbid files to enable Full Screen mode on opening</source>
        <translation>منع الملفات لتمكين وضع ملء الشاشة علي فتح</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1911"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="730"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1022"/>
        <source>Light</source>
        <translation>فاتح</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1916"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="731"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1026"/>
        <source>Dark</source>
        <translation>داكن</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2226"/>
        <source>Default path to tesseract ocr data files</source>
        <translation>المسار الافتراضي لملفات بيانات ocr</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2265"/>
        <source>Additional tesseract ocr config file</source>
        <translation>إضافية tesseract ocr ملف التكوين</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2327"/>
        <source>Install languages</source>
        <translation>تثبيت اللغات</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2347"/>
        <source>Direct internet connection</source>
        <translation>اتصال إنترنت مباشر</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2357"/>
        <source>Manual proxy configuration</source>
        <translation>تكوين الوكيل اليدوي</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2373"/>
        <source>HTTP Proxy</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2380"/>
        <source>SOCKS 5 Proxy</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2390"/>
        <source>Host</source>
        <translation>مضيف</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2400"/>
        <source>Port</source>
        <translation>منفذ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2056"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2443"/>
        <source>Authentication</source>
        <translation>مصادقه</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2455"/>
        <source>User name</source>
        <translation>اسم المستخدم</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2641"/>
        <source>Never</source>
        <translation>ابدا</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2646"/>
        <source>Weekly</source>
        <translation>أسبوعي</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2651"/>
        <source>Monthly</source>
        <translation>شهري</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2627"/>
        <source>Check for Updates Automatically</source>
        <translation>التحقق من وجود تحديثات تلقائيا</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="155"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2242"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2281"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="498"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="856"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1046"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1319"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1382"/>
        <source>Color</source>
        <translation>لون</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="469"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="807"/>
        <source>Size</source>
        <translation>حجم</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation>الإعدادات</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="172"/>
        <source>History</source>
        <translation>تاريخ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="184"/>
        <source>Restore last session when application start</source>
        <translation>استعاده جلسة العمل الاخيره عند بدء تشغيل التطبيق</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="191"/>
        <source>Restore last view settings when reopening</source>
        <translation>استعاده إعدادات العرض الاخيره عند أعاده فتح</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1106"/>
        <source>Enable JavaScript</source>
        <translation>تمكين جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="308"/>
        <source> Always hide document message bar </source>
        <translation>إخفاء شريط رسائل المستندات دوما</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1567"/>
        <source>Default Layout and Zoom</source>
        <translation>التخطيط الافتراضي والتكبير</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1580"/>
        <source>Default page layout</source>
        <translation>تخطيط الصفحة الافتراضي</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1591"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1675"/>
        <source>Automatic</source>
        <translation>تلقائي</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1680"/>
        <source>Single Page</source>
        <translation>صفحه واحده</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1685"/>
        <source>Facing Pages</source>
        <translation>الصفحات المتقابلة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1573"/>
        <source>Zoom</source>
        <translation>تكبير/تصغير</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="54"/>
        <source>Grid</source>
        <translation>شبكه</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="59"/>
        <source>JavaScript</source>
        <translation>جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="79"/>
        <source>Keyboard</source>
        <translation>لوحة المفاتيح</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="84"/>
        <source>Email</source>
        <translation>بريد الكتروني</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="89"/>
        <source>OCR</source>
        <translation>قارئ الأحرف البصرية.</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="94"/>
        <source>Network</source>
        <translation>شبكه</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="201"/>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation>فتح المستندات كعلامات تبويب جديده في نفس الإطار يتطلب أعاده التشغيل</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="208"/>
        <source>Enable scroll wheel zooming</source>
        <translation>تمكين تكبير عجله التمرير</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="215"/>
        <source>Show Start page</source>
        <translation>إظهار صفحه البدء</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="235"/>
        <source>Load all objects separately</source>
        <translation>تحميل كافة الكائنات بشكل منفصل</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="316"/>
        <source>Link</source>
        <translation>ارتباط</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="321"/>
        <source>Edit Box</source>
        <translation>مربع تحرير</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="326"/>
        <source>Check box</source>
        <translation>خانه اختيار</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="331"/>
        <source>Radio button</source>
        <translation>زر الراديو</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="336"/>
        <source>Combo box</source>
        <translation>مربع التحرير والسرد</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="341"/>
        <source>List box</source>
        <translation>مربع قائمه</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="346"/>
        <source>Button</source>
        <translation>زر</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="351"/>
        <source>Signature</source>
        <translation>توقيع</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="372"/>
        <source>Borders and Colors</source>
        <translation>الحدود وألوان</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="379"/>
        <source>Thin</source>
        <translation>رقيق</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="384"/>
        <source>Medium</source>
        <translation>متوسط</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="389"/>
        <source>Thick</source>
        <translation>سميك</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="397"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="611"/>
        <source>Border Color</source>
        <translation>لون الحد</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="404"/>
        <source>Fill Color</source>
        <translation>لون التعبئة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="412"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="626"/>
        <source>Solid</source>
        <translation>صلب</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="417"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="631"/>
        <source>Dashed</source>
        <translation>متقطع</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="422"/>
        <source>Beveled</source>
        <translation>مشطوف</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="427"/>
        <source>Inset</source>
        <translation>ادرج</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="432"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="636"/>
        <source>Underline</source>
        <translation>أكد</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="440"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="618"/>
        <source>Line Style</source>
        <translation>نمط الخط</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="447"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="597"/>
        <source>Line Thickness</source>
        <translation>سماكة الخط</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="482"/>
        <source>Auto</source>
        <translation>تلقائي</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="511"/>
        <source>Font</source>
        <translation>خط</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="527"/>
        <source>Style</source>
        <translation>نمط</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="538"/>
        <source>Check</source>
        <translation>تحقق</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="553"/>
        <source>Diamond</source>
        <translation>معين</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="558"/>
        <source>Square</source>
        <translation>مربع</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="591"/>
        <source>Options</source>
        <translation>الخيارات</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="644"/>
        <source>Highlight</source>
        <translation>تمييز</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="655"/>
        <source>None</source>
        <translation>لاشيء</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="660"/>
        <source>Invert</source>
        <translation>قلب</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="665"/>
        <source>OutLine</source>
        <translation>خطوط عريضة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="670"/>
        <source>Insert</source>
        <translation>ادراج</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="914"/>
        <source>Automatically change font when editing text</source>
        <translation>تغيير الخط تلقائيا عند تحرير النص</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="926"/>
        <source>Exact match only</source>
        <translation type="unfinished">المطابقة التامة فقط</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="946"/>
        <source>Units</source>
        <translation>وحدات</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="972"/>
        <source>Width between lines</source>
        <translation>العرض بين الأسطر</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="979"/>
        <source>Height between lines</source>
        <translation>الارتفاع بين الأسطر</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="986"/>
        <source>Left offset</source>
        <translation>أزاحه لليسار</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1006"/>
        <source>Top offset</source>
        <translation>الازاحه العليا</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1026"/>
        <source>Subdivision</source>
        <translation>تقسيم</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1118"/>
        <source>Show errors and  messages in console</source>
        <translation>إظهار الأخطاء والرسائل في وحده التحكم</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1128"/>
        <source>Enable safe reading mode</source>
        <translation>تمكين وضع القراءة الامنه</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1211"/>
        <source>Measurements</source>
        <translation>قياس</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1216"/>
        <source>Drawing</source>
        <translation>رسم</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1221"/>
        <source>Typewriter</source>
        <translation>كاتبه</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1596"/>
        <source>Actual Size</source>
        <translation>الحجم الفعلي</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1601"/>
        <source>Fit Page</source>
        <translation>ملاءمة الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1606"/>
        <source>Fit Width</source>
        <translation>ملائمة العرض</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1611"/>
        <source>25%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1616"/>
        <source>50%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1621"/>
        <source>75%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1626"/>
        <source>100%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1631"/>
        <source>125%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1636"/>
        <source>150%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1641"/>
        <source>200%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1646"/>
        <source>300%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1651"/>
        <source>400%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1656"/>
        <source>600%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="457"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1709"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1810"/>
        <source>Text</source>
        <translation>نص</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1716"/>
        <source>Bitmap Images</source>
        <translation>صور نقطية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1723"/>
        <source>Vector Images</source>
        <translation>صور المتجهة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1752"/>
        <source>System PPI</source>
        <translation>نظام PPI</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1798"/>
        <source>Replace Document Colors</source>
        <translation>استبدال ألوان المستند</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1817"/>
        <source>Page Background</source>
        <translation>خلفيه الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="64"/>
        <source>Comments</source>
        <translation>التعليقات</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="74"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="366"/>
        <source>Appearance</source>
        <translation>مظهر</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1864"/>
        <source>Theme</source>
        <translation>سمة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1746"/>
        <source>Resolution</source>
        <translation>الدقة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1762"/>
        <source>Custom</source>
        <translation>مخصص</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1485"/>
        <source>Author</source>
        <translation>المؤلف</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1183"/>
        <source>Pop-up Opacity</source>
        <translation>تعتيم المنبثقة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1290"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1408"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1527"/>
        <source>%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1191"/>
        <source>Sticky Note</source>
        <translation>ملاحظه دبقة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1273"/>
        <source>Type</source>
        <translation>نوع</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1306"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1369"/>
        <source>Opacity</source>
        <translation>العتامه</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1196"/>
        <source>Highlight Text</source>
        <translation>تمييز النص</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1201"/>
        <source>Strikeout Text</source>
        <translation>نص مشطوب</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1206"/>
        <source>Underline Text</source>
        <translation>تسطير النص</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1395"/>
        <source>Line Width</source>
        <translation>عرض الخط</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1931"/>
        <source>Icons in menus</source>
        <translation>الايقونات في القوائم</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="39"/>
        <source>System</source>
        <translation>النظام</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="99"/>
        <source>Language</source>
        <translation>اللغة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="104"/>
        <source>Update</source>
        <translation>تحديث</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="44"/>
        <source>Forms</source>
        <translation>اشكال</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="49"/>
        <source>Editing</source>
        <translation>التحرير</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="69"/>
        <source>Display</source>
        <translation>عرض</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="348"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="363"/>
        <source>Select directory</source>
        <translation>تحديد الدليل</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="377"/>
        <source>Open File</source>
        <translation>فتح ملف</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="648"/>
        <source>Arabic</source>
        <translation>العربية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="649"/>
        <source>Armenian</source>
        <translation>الأرمينية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="650"/>
        <source>Bulgarian</source>
        <translation>البلغارية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="651"/>
        <source>Catalan</source>
        <translation>الكتالانية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="652"/>
        <source>Chinese-Simplified</source>
        <translation>الصينية المبسطة</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="653"/>
        <source>Chinese-Traditional</source>
        <translation>الصينية التقليدية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="654"/>
        <source>Czech</source>
        <translation>التشيكية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="655"/>
        <source>Danish</source>
        <translation>الدانماركية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="656"/>
        <source>Dutch</source>
        <translation>الهولندية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="657"/>
        <source>English</source>
        <translation>الإنكليزية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="658"/>
        <source>Estonian</source>
        <translation>الإستونية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="659"/>
        <source>Finnish</source>
        <translation>الفنلندية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="660"/>
        <source>French</source>
        <translation>الفرنسية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="661"/>
        <source>Galician</source>
        <translation>الغاليشية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="662"/>
        <source>German</source>
        <translation>الألمانية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="663"/>
        <source>Greek</source>
        <translation>اليونانية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="664"/>
        <source>Hebrew</source>
        <translation>العبرية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="665"/>
        <source>Hungarian</source>
        <translation>المجرية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="666"/>
        <source>Irish</source>
        <translation>الأيرلندية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="667"/>
        <source>Italian</source>
        <translation>الإيطالية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="668"/>
        <source>Japanese</source>
        <translation>اليابانية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="669"/>
        <source>Korean</source>
        <translation>الكورية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="670"/>
        <source>Latvian</source>
        <translation>اللاتفية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="671"/>
        <source>Lithuanian</source>
        <translation>الليتوانية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="672"/>
        <source>Norwegian</source>
        <translation>النرويجية </translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="673"/>
        <source>Norwegian-Nynorsk</source>
        <translation>النرويجية-نينورسك</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="674"/>
        <source>Polish</source>
        <translation>البولندية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="675"/>
        <source>Portuguese</source>
        <translation>البرتغالية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="676"/>
        <source>Portuguese-Brazilian</source>
        <translation>البرتغالية-البرازيلية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="677"/>
        <source>Romanian</source>
        <translation>الرومانية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="678"/>
        <source>Russian</source>
        <translation>الروسية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="679"/>
        <source>Serbian</source>
        <translation>الصربية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="680"/>
        <source>Slovak</source>
        <translation>السلوفاكية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="681"/>
        <source>Slovenian</source>
        <translation>السلوفينية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="682"/>
        <source>Spanish</source>
        <translation>الإسبانية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="683"/>
        <source>Swedish</source>
        <translation>السويدية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="684"/>
        <source>Thai</source>
        <translation>التايلندية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="685"/>
        <source>Turkish</source>
        <translation>التركية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="686"/>
        <source>Ukrainian</source>
        <translation>الأوكرانية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="687"/>
        <source>Valencian</source>
        <translation>بلنسية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="688"/>
        <source>Vietnamese</source>
        <translation>الفيتنامية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="700"/>
        <source>Check Mark</source>
        <translation>علامة الاختيار</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1744"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1764"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1784"/>
        <source> mm</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="543"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="701"/>
        <source>Circle</source>
        <translation>دائره</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="702"/>
        <source>Comment</source>
        <translation>تعليق</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="548"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="703"/>
        <source>Cross</source>
        <translation>صليب</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="704"/>
        <source>Help</source>
        <translation>التعليمات</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="705"/>
        <source>Insert Text</source>
        <translation>ادراج نص</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="706"/>
        <source>Key</source>
        <translation>مفتاح</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="707"/>
        <source>New Paragraph</source>
        <translation>فقره جديده</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="708"/>
        <source>Text Note</source>
        <translation>المذكرة النصية</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="709"/>
        <source>Paragraph</source>
        <translation>فقره</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="710"/>
        <source>Right Arrow</source>
        <translation>سهم لليمين</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="711"/>
        <source>Right Pointer</source>
        <translation>سهم لليمين</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="563"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="712"/>
        <source>Star</source>
        <translation>نجم</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="713"/>
        <source>Up Arrow</source>
        <translation>سهم لاعلي</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="714"/>
        <source>Up Left Arrow</source>
        <translation>سهم لليسار الاعلى</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="715"/>
        <source>Graph</source>
        <translation>رسم بياني</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="716"/>
        <source>Paper Clip</source>
        <translation>قصاصه ورق</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="717"/>
        <source>Attachment</source>
        <translation>مرفق</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="718"/>
        <source>Tag</source>
        <translation>بطاقة</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../src/mainwindow.ui" line="36"/>
        <source>File</source>
        <translation>ملف</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="46"/>
        <source>Export to</source>
        <translation>تصدير إلى</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="178"/>
        <location filename="../../src/mainwindow.ui" line="1355"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="478"/>
        <source>Edit</source>
        <translation>تحرير</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="182"/>
        <source>Align Objects</source>
        <translation>محاذاة الكائنات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="79"/>
        <location filename="../../src/mainwindow.ui" line="1347"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="504"/>
        <source>View</source>
        <translation>عرض</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="209"/>
        <source>Document</source>
        <translation>مستند</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="136"/>
        <source>Help</source>
        <translation>التعليمات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="294"/>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="114"/>
        <source>Insert</source>
        <translation>ادراج</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="257"/>
        <location filename="../../src/mainwindow.ui" line="1371"/>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="103"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="582"/>
        <source>Comments</source>
        <translation>التعليقات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="146"/>
        <location filename="../../src/mainwindow.ui" line="1363"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="550"/>
        <source>Tools</source>
        <translation>الادوات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="53"/>
        <location filename="../../src/mainwindow.ui" line="1814"/>
        <source>New</source>
        <translation>جديد</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="765"/>
        <location filename="../../src/mainwindow.cpp" line="2954"/>
        <source>Create a new blank PDF</source>
        <translation>إنشاء مستند محمول فارغ جديد</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="768"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="316"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="459"/>
        <source>Open</source>
        <translation>فتح</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="645"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="646"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="647"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="709"/>
        <source>Stamp</source>
        <translation>طابع</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="325"/>
        <source>Ctrl+O</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="372"/>
        <source>Select text for copying and pasting</source>
        <translation>تحديد نص للنسخ واللصق</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="375"/>
        <source>Alt+5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="409"/>
        <source>PgUp</source>
        <translation>ص اعلى</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="424"/>
        <source>PgDown</source>
        <translation>ص اسفل</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="465"/>
        <source>Ctrl+0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="494"/>
        <source>Ctrl+H</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="520"/>
        <source>Ctrl+1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="538"/>
        <source>Ctrl+2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="547"/>
        <location filename="../../src/mainwindow.cpp" line="2289"/>
        <source>Save</source>
        <translation>حفظ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="553"/>
        <source>Save the document</source>
        <translation>حفظ المستند</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="556"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="565"/>
        <location filename="../../src/mainwindow.cpp" line="716"/>
        <location filename="../../src/mainwindow.cpp" line="4903"/>
        <location filename="../../src/mainwindow.cpp" line="4966"/>
        <source>Save As...</source>
        <translation>حفظ باسم...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="571"/>
        <source>Save the document with a new name</source>
        <translation>حفظ المستند باسم جديد</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="574"/>
        <source>Ctrl+Shift+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="583"/>
        <source>Print</source>
        <translation>طباعه</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="586"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;طباعه المستند&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="589"/>
        <source>Print the document</source>
        <translation>طباعه المستند</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="592"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="597"/>
        <location filename="../../src/mainwindow.ui" line="600"/>
        <source>Close</source>
        <translation>اغلاق</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="603"/>
        <source>Ctrl+W</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="608"/>
        <location filename="../../src/mainwindow.ui" line="611"/>
        <source>Exit</source>
        <translation>خروج</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="632"/>
        <source>Ctrl+3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="663"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;تحديد وتحرير النص والصور والتعليقات التوضيحية وحقول النموذج...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="666"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation>تحديد وتحرير النص والصور والتعليقات التوضيحية وحقول النموذج...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="687"/>
        <source>Select text for editing</source>
        <translation>تحديد نص للتحرير</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="690"/>
        <source>Alt+2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="699"/>
        <location filename="../../src/mainwindow.ui" line="1534"/>
        <location filename="../../src/mainwindow.ui" line="1580"/>
        <location filename="../../src/mainwindow.ui" line="1593"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="705"/>
        <source>Delete the currently selected object(s)</source>
        <translation>حذف الكائنات المحددة حاليا</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form and annotations for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;تحديد النموذج والتعليقات التوضيحية للتحرير&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="759"/>
        <source>Blank PDF</source>
        <translation>مستند محمول فارغ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="784"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print Preview (Ctrl+Shift+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Preview the document before printing.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print Preview (Ctrl+Shift+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;معاينه المستند قبل الطباعة.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="790"/>
        <source>Ctrl+Shift+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="805"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation>قص كائنات التحديد ووضعها في الحافظة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="823"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation>نسخ كائنات التحديد ووضعها في الحافظة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="841"/>
        <source>Paste from the Clipboard</source>
        <translation>لصق من الحافظة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="874"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="889"/>
        <source>Undo the last action</source>
        <translation>التراجع عن الاجراء الأخير</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="907"/>
        <source>Redo the previously undone action.</source>
        <translation>أعاده الاجراء الذي تم التراجع عنه سابقا.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="925"/>
        <source>Send to Back selected object.</source>
        <translation>إرسال إلى الخلف الكائن المحدد.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="934"/>
        <source>Bring to Front</source>
        <translation>إحضار إلى الامام</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="937"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;إحضار الكائن المحدد إلى الامام.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="940"/>
        <source>Bring to Front selected object.</source>
        <translation>إحضار الكائن المحدد للامام.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="975"/>
        <source>Ctrl+Shift+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="994"/>
        <source>Ctrl+Shift+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1005"/>
        <source>Ctrl+R</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1010"/>
        <location filename="../../src/mainwindow.ui" line="1013"/>
        <source>Extract Pages...</source>
        <translation>استخراج الصفحات...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1016"/>
        <source>Ctrl+Shift+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1021"/>
        <location filename="../../src/mainwindow.ui" line="1024"/>
        <source>Insert Pages...</source>
        <translation>ادراج صفحات...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1027"/>
        <source>Ctrl+Shift+I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1046"/>
        <source>Open window with document properties</source>
        <translation>فتح اطار مع خصائص المستند</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1064"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;انقر فوق الصفحة لأضافه ملاحظه في هذا الموضع&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1067"/>
        <source>Click the page to add a note at that position</source>
        <translation>انقر فوق الصفحة لأضافه ملاحظه في هذا الموضع</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1070"/>
        <source>Ctrl+6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1115"/>
        <location filename="../../src/mainwindow.ui" line="1622"/>
        <location filename="../../src/mainwindow.cpp" line="4192"/>
        <source>Text</source>
        <translation>نص</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1121"/>
        <source>Insert new text to current page</source>
        <translation>ادراج نص جديد إلى الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1124"/>
        <source>Ctrl+T</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1133"/>
        <location filename="../../src/mainwindow.cpp" line="4201"/>
        <source>Image</source>
        <translation>صوره</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1139"/>
        <source>Insert new image to current page</source>
        <translation>ادراج صوره جديده إلى الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1142"/>
        <source>Ctrl+I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1205"/>
        <source>Insert new link to current page</source>
        <translation>ادراج ارتباط جديد إلى الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1217"/>
        <source>Text Field</source>
        <translation>حقل النص</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1232"/>
        <source>Check Box</source>
        <translation>خانه اختيار</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1244"/>
        <source>Radio Button</source>
        <translation>زر الراديو</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1256"/>
        <source>Combo Box</source>
        <translation>مربع التحرير والسرد</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1268"/>
        <source>List Box</source>
        <translation>مربع قائمه</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1391"/>
        <location filename="../../src/mainwindow.ui" line="1394"/>
        <source>Open Object Inspector</source>
        <translation>فتح الكائن المفتش</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1399"/>
        <location filename="../../src/mainwindow.ui" line="1402"/>
        <source>Crop Pages</source>
        <translation>صفحات الاقتصاص</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1405"/>
        <source>Ctrl+K</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1414"/>
        <location filename="../../src/mainwindow.ui" line="1417"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>تدوير 90 درجه باتجاه عقارب الساعة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1426"/>
        <location filename="../../src/mainwindow.ui" line="1429"/>
        <location filename="../../src/mainwindow.ui" line="1432"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>تدوير 90 درجه مقابل عقارب الساعة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1437"/>
        <source>Export Form Data...</source>
        <translation>تصدير بيانات النموذج...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1442"/>
        <source>Import Form Data...</source>
        <translation>استيراد بيانات النموذج...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1447"/>
        <source>Export Comments Data...</source>
        <translation>تصدير بيانات التعليقات...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1452"/>
        <source>Import Comments Data...</source>
        <translation>استيراد بيانات التعليقات...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1457"/>
        <source>Save Optimized As...</source>
        <translation>حفظ الأمثل كما...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1460"/>
        <source>Ctrl+Alt+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1471"/>
        <source>F3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1484"/>
        <source>Document JavaScript</source>
        <translation>وثيقة جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1489"/>
        <source>Document Actions</source>
        <translation>إجراءات المستند</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1497"/>
        <source>Replace Document Colors</source>
        <translation>استبدال ألوان المستند</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1502"/>
        <source>Paste to Multiple Pages</source>
        <translation>لصق إلى صفحات متعددة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1505"/>
        <source>Ctrl+Shift+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1510"/>
        <source>JavaScript Console</source>
        <translation>وحدة تحكم جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1513"/>
        <source>Ctrl+J</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1518"/>
        <source>Page Properties</source>
        <translation>خصائص الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1526"/>
        <location filename="../../src/mainwindow.ui" line="1572"/>
        <location filename="../../src/mainwindow.ui" line="1585"/>
        <source>Add</source>
        <translation>اضافة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1529"/>
        <source>Ctrl+Shift+H</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1545"/>
        <source>Menu Bar</source>
        <translation>شريط القوائم</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1548"/>
        <source>F9</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1556"/>
        <source>Show Cover Page During Facing</source>
        <translation>إظهار صفحه الغلاف اثناء المواجهة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1564"/>
        <source>Full Screen</source>
        <translation>ملء الشاشة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1567"/>
        <source>F11</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1575"/>
        <source>Ctrl+Shift+W</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1588"/>
        <source>Ctrl+Shift+B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1598"/>
        <location filename="../../src/mainwindow.ui" line="1601"/>
        <source>Align Center Horizontal</source>
        <translation>محاذاة توسيط أفقي</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1606"/>
        <location filename="../../src/mainwindow.ui" line="1609"/>
        <source>Align Center Vertical</source>
        <translation>محاذاة توسيط عمودي</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1614"/>
        <source>Find Previous</source>
        <translation>البحث عن السابق</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1617"/>
        <source>Shift+F3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1641"/>
        <source>Send file via email</source>
        <translation>إرسال ملف عبر البريد الكتروني</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1828"/>
        <source>F12</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1833"/>
        <source>Typewriter</source>
        <translation>كاتبه</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1838"/>
        <source>Callout</source>
        <translation>شرح</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1847"/>
        <source>Formatted Text</source>
        <translation>نص منسق</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1850"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;ادراج نص منسق جديد إلى الصفحة الحالية&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1627"/>
        <location filename="../../src/mainwindow.ui" line="1630"/>
        <source>OCR</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1635"/>
        <source>Email</source>
        <translation>بريد الكتروني</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1638"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;إرسال ملف عبر البريد الكتروني&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1649"/>
        <location filename="../../src/mainwindow.ui" line="1652"/>
        <source>Grid</source>
        <translation>شبكه</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1655"/>
        <source>Ctrl+U</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1663"/>
        <location filename="../../src/mainwindow.ui" line="1666"/>
        <source>Snap to Grid</source>
        <translation>انطباق علي الشبكة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1669"/>
        <source>Ctrl+Shift+U</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1677"/>
        <location filename="../../src/mainwindow.ui" line="1680"/>
        <source>Distance Tool</source>
        <translation>أداه المسافة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1688"/>
        <location filename="../../src/mainwindow.ui" line="1691"/>
        <source>Perimeter Tool</source>
        <translation>أداه المحيط</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1699"/>
        <location filename="../../src/mainwindow.ui" line="1702"/>
        <source>Area Tool</source>
        <translation>أداه المنطقة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1721"/>
        <location filename="../../src/mainwindow.ui" line="1724"/>
        <source>Arrow</source>
        <translation>سهم</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1765"/>
        <location filename="../../src/mainwindow.ui" line="1768"/>
        <source>Attach a File as a Comment</source>
        <translation>ألحاق ملف باسم تعليق</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1773"/>
        <source>From Scanner</source>
        <translation>من الماسح الضوئي</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1776"/>
        <location filename="../../src/mainwindow.ui" line="1779"/>
        <source>Create a new document from scanner</source>
        <translation>إنشاء مستند جديد من الماسح الضوئي</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1784"/>
        <source>From Files</source>
        <translation>من الملفات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1787"/>
        <location filename="../../src/mainwindow.ui" line="1790"/>
        <source>Create a new document from files</source>
        <translation>إنشاء مستند جديد من الملفات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1806"/>
        <location filename="../../src/mainwindow.ui" line="1809"/>
        <source>Brush</source>
        <translation>فرشاه</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1825"/>
        <source>Menu</source>
        <translation>قائمه</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="919"/>
        <source>Send to Back</source>
        <translation>إرسال للخلف</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="922"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;إرسال الكائن المحدد للخلف..&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="708"/>
        <source>Del</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1331"/>
        <source>Statusbar</source>
        <translation>شريط المعلومات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="388"/>
        <location filename="../../src/mainwindow.ui" line="391"/>
        <source>First Page</source>
        <translation>الصفحة الاولي</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="403"/>
        <location filename="../../src/mainwindow.ui" line="406"/>
        <source>Previous Page</source>
        <translation>الصفحة السابقة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="418"/>
        <location filename="../../src/mainwindow.ui" line="421"/>
        <source>Next Page</source>
        <translation>الصفحة التالية</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="429"/>
        <location filename="../../src/mainwindow.ui" line="432"/>
        <source>Last Page</source>
        <translation>الصفحة الاخيره</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="719"/>
        <source>Alt+Del</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1235"/>
        <source>Check box</source>
        <translation>خانه اختيار</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1220"/>
        <source>Edit Box</source>
        <translation>مربع تحرير</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1247"/>
        <source>Radio button</source>
        <translation>زر الراديو</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1271"/>
        <source>List box</source>
        <translation>مربع قائمه</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1259"/>
        <source>Combo box</source>
        <translation>مربع التحرير والسرد</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1339"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="441"/>
        <source>Main</source>
        <translation>رئيسي</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1292"/>
        <location filename="../../src/mainwindow.ui" line="1295"/>
        <source>Signature</source>
        <translation>توقيع</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="838"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;لصق من الحافظة&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="860"/>
        <location filename="../../src/mainwindow.ui" line="863"/>
        <source>Set Fit to Page</source>
        <translation>تعيين ملاءمة إلى الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1151"/>
        <location filename="../../src/mainwindow.ui" line="1154"/>
        <location filename="../../src/mainwindow.ui" line="1710"/>
        <location filename="../../src/mainwindow.ui" line="1713"/>
        <source>Line</source>
        <translation>سطر</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1163"/>
        <location filename="../../src/mainwindow.ui" line="1166"/>
        <location filename="../../src/mainwindow.ui" line="1732"/>
        <location filename="../../src/mainwindow.ui" line="1735"/>
        <source>Rectangle</source>
        <translation>مستطيل</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1175"/>
        <location filename="../../src/mainwindow.ui" line="1178"/>
        <location filename="../../src/mainwindow.ui" line="1743"/>
        <location filename="../../src/mainwindow.ui" line="1746"/>
        <source>Ellipse</source>
        <translation>بيضاوي</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="781"/>
        <location filename="../../src/mainwindow.ui" line="787"/>
        <source>Print Preview</source>
        <translation>معاينه قبل الطباعة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="945"/>
        <location filename="../../src/mainwindow.ui" line="948"/>
        <source>Align Left</source>
        <translation>محاذاة لليسار</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="953"/>
        <location filename="../../src/mainwindow.ui" line="956"/>
        <source>Align Right</source>
        <translation>محاذاة لليمين</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="961"/>
        <location filename="../../src/mainwindow.ui" line="964"/>
        <source>Align Top</source>
        <translation>محاذاة للاعلى</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1032"/>
        <location filename="../../src/mainwindow.ui" line="1035"/>
        <source>Align Bottom</source>
        <translation>محاذاة للاسفل</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="645"/>
        <location filename="../../src/mainwindow.ui" line="648"/>
        <source>Reduce Page Thumbnails</source>
        <translation>تصغير مصغرات الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="637"/>
        <location filename="../../src/mainwindow.ui" line="640"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>تكبير مصغرات الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="773"/>
        <location filename="../../src/mainwindow.ui" line="776"/>
        <source>Images</source>
        <translation>صور</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="969"/>
        <location filename="../../src/mainwindow.ui" line="972"/>
        <source>Insert Blank Pages</source>
        <translation>ادراج صفحات فارغه</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1040"/>
        <source>Properties</source>
        <translation>الخصائص</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1043"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;فتح اطار مع خصائص المستند&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1052"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1118"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;ادراج نص جديد إلى الصفحة الحالية&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1136"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;ادراج صوره جديده إلى الصفحة الحالية&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1202"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;ادراج ارتباط جديد إلى الصفحة الحالية&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1208"/>
        <source>Ctrl+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1223"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1310"/>
        <source>Home page</source>
        <translation>الصفحة الرئيسية</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1315"/>
        <source>Register...</source>
        <translation>تسجيل...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1320"/>
        <source>Check for Update</source>
        <translation>التحقق من وجود تحديث</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="883"/>
        <source>Undo</source>
        <translation>تراجع</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="886"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;التراجع عن الاجراء الأخير&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="892"/>
        <source>Ctrl+Z</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1187"/>
        <location filename="../../src/mainwindow.ui" line="1190"/>
        <location filename="../../src/mainwindow.ui" line="1754"/>
        <location filename="../../src/mainwindow.ui" line="1757"/>
        <source>Pencil</source>
        <translation>قلم</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1280"/>
        <location filename="../../src/mainwindow.ui" line="1283"/>
        <source>Button</source>
        <translation>زر</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="444"/>
        <location filename="../../src/mainwindow.ui" line="447"/>
        <source>Zoom In</source>
        <translation>تكبير</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="450"/>
        <source>Ctrl++</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="474"/>
        <location filename="../../src/mainwindow.ui" line="477"/>
        <source>Zoom Out</source>
        <translation>تصغير</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="480"/>
        <source>Ctrl+-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="459"/>
        <location filename="../../src/mainwindow.ui" line="462"/>
        <source>Actual Size</source>
        <translation>الحجم الفعلي</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="380"/>
        <location filename="../../src/mainwindow.ui" line="383"/>
        <source>Settings</source>
        <translation>الإعدادات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1305"/>
        <source>Contents</source>
        <translation>التعليقات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="488"/>
        <location filename="../../src/mainwindow.ui" line="491"/>
        <source>Highlight Fields</source>
        <translation>تمييز الحقول</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="345"/>
        <location filename="../../src/mainwindow.ui" line="351"/>
        <source>Hand Tool</source>
        <translation>أداه اليد</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="681"/>
        <source>Edit Text</source>
        <translation>تحرير نص</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="988"/>
        <location filename="../../src/mainwindow.ui" line="991"/>
        <source>Page layout</source>
        <translation>تخطيط الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="901"/>
        <source>Redo</source>
        <translation>أعاده</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="904"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;أعاده الاجراء الذي تم التراجع عنه سابقا.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="910"/>
        <source>Ctrl+Y</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="799"/>
        <source>Cut</source>
        <translation>قطع</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation>محرر مستند محمول رئيسي</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="91"/>
        <source>Page Display</source>
        <translation>عرض الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="100"/>
        <source>Go To</source>
        <translation>الانتقال إلى</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="109"/>
        <source>Search</source>
        <translation>بحث</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="158"/>
        <location filename="../../src/mainwindow.ui" line="1379"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="566"/>
        <source>Forms</source>
        <translation>اشكال</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="213"/>
        <source>Header and Footer</source>
        <translation>العنوان الرأسي و الهامش</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="220"/>
        <source>Watermark</source>
        <translation>علامة مائية</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="227"/>
        <source>Background</source>
        <translation>الخلفية</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="261"/>
        <source>Measurements</source>
        <translation>قياس</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="269"/>
        <source>Drawing</source>
        <translation>رسم</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="319"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="330"/>
        <location filename="../../src/mainwindow.ui" line="333"/>
        <source>About</source>
        <translation>حول</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="348"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;استخدم أداه اليد لنقل الصفحات وفتح الارتباطات وتحديد النص.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="369"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;تحديد نص للنسخ واللصق&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="394"/>
        <source>Home</source>
        <translation>الصفحة الرئيسية</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="435"/>
        <source>End</source>
        <translation>نهاية</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="499"/>
        <location filename="../../src/mainwindow.ui" line="502"/>
        <source>Reset Forms</source>
        <translation>أعاده تعيين النماذج</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="514"/>
        <location filename="../../src/mainwindow.ui" line="517"/>
        <source>Fit Page</source>
        <translation>ملاءمة الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="532"/>
        <location filename="../../src/mainwindow.ui" line="535"/>
        <source>Fit Width</source>
        <translation>ملائمة العرض</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="550"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;حفظ المستند&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="568"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;حفظ المستند باسم جديد&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="614"/>
        <source>Ctrl+Q</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="626"/>
        <location filename="../../src/mainwindow.ui" line="629"/>
        <source>Facing Pages</source>
        <translation>الصفحات المتقابلة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="684"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;تحديد نص للتحرير&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="702"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;حذف الكائنات المحددة حاليا&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="713"/>
        <location filename="../../src/mainwindow.ui" line="716"/>
        <source>Delete Pages</source>
        <translation>حذف الصفحه</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="731"/>
        <location filename="../../src/mainwindow.ui" line="737"/>
        <location filename="../../src/mainwindow.ui" line="1798"/>
        <source>Edit Forms</source>
        <translation>تحرير النماذج</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="734"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="754"/>
        <source>Ctrl+F11</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="762"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;إنشاء مستند محمول فارغ جديد&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="802"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;قص الكائنات التي تم تحديدها ووضعها في الحافظة&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="808"/>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="817"/>
        <source>Copy</source>
        <translation>نسخ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="820"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;نسخ كائنات تم تحديدها ووضعها في الحافظة&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="826"/>
        <source>Ctrl+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="835"/>
        <source>Paste</source>
        <translation>لصق</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="844"/>
        <source>Ctrl+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="849"/>
        <location filename="../../src/mainwindow.ui" line="852"/>
        <source>Select All</source>
        <translation>حدد الكل</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="855"/>
        <source>Ctrl+A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="660"/>
        <source>Edit Document</source>
        <translation>تحرير مستند</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="669"/>
        <source>Alt+1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1199"/>
        <source>Link</source>
        <translation>ارتباط</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1079"/>
        <location filename="../../src/mainwindow.ui" line="1082"/>
        <source>Highlight Text</source>
        <translation>تمييز النص</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1061"/>
        <source>Add Sticky Note</source>
        <translation>أضافه ملاحظه دبقة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1091"/>
        <location filename="../../src/mainwindow.ui" line="1094"/>
        <source>Strikeout Text</source>
        <translation>نص مشطوب</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1103"/>
        <location filename="../../src/mainwindow.ui" line="1106"/>
        <source>Underline Text</source>
        <translation>تسطير النص</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="366"/>
        <source>Select Text</source>
        <translation>تحديد نص</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="740"/>
        <source>Alt+3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1300"/>
        <source>HTML</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="868"/>
        <location filename="../../src/mainwindow.ui" line="871"/>
        <location filename="../../src/mainwindow.ui" line="1479"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="539"/>
        <source>Find</source>
        <translation>بحث</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1468"/>
        <source>Find Next</source>
        <translation>بحث عن التالي</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="999"/>
        <location filename="../../src/mainwindow.ui" line="1002"/>
        <source>Rotate Pages</source>
        <translation>استدارة الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="980"/>
        <location filename="../../src/mainwindow.ui" line="983"/>
        <source>Move Pages</source>
        <translation>نقل الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="354"/>
        <source>Alt+4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2065"/>
        <source>Open failed</source>
        <translation>فشل الفتح</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2066"/>
        <source>Cannot open file :
</source>
        <translation>لا يمكن فتح الملف:
</translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="39"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="426"/>
        <source>Empty recent files list</source>
        <translation>إفراغ قائمه الملفات الاخيره</translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="68"/>
        <source>Prev/Next</source>
        <translation>السابق/التالي</translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="91"/>
        <source>Edit Tools</source>
        <translation>أدوات التحرير</translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="147"/>
        <source>Page :</source>
        <translation>صفحة:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="322"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="461"/>
        <source>Open a PDF file</source>
        <translation>افتح ملف المستند</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="689"/>
        <location filename="../../src/mainwindow.cpp" line="4894"/>
        <location filename="../../src/mainwindow.cpp" line="4957"/>
        <source>untitled</source>
        <translation>معنونة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="726"/>
        <source>PDF Files (*.pdf)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="35"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="422"/>
        <source>Recent Files</source>
        <translation>الملفات الأخيرة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="295"/>
        <location filename="../../src/mainwindow.cpp" line="361"/>
        <source>There was an error opening the document !</source>
        <translation>حدث خطا اثناء فتح المستند!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="518"/>
        <location filename="../../src/mainwindow.cpp" line="532"/>
        <source>All Supported Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps);;All Files (*)</source>
        <translation> (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps);;All Files (*) كل الملفات المدعومة </translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="645"/>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation>غير معتمد مؤقتا. اختر اسم ملف مستند محمول للحفظ XPS الحفظ في.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="887"/>
        <source>Export completed</source>
        <translation>اكتمل التصدير</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1250"/>
        <location filename="../../src/mainwindow.cpp" line="1266"/>
        <source>Can&apos;t find :</source>
        <translation>لا يمكن العثور علي:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1321"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>من المطلوب أعاده تشغيل البرنامج بحيث تكون التغييرات نافذه المفعول.</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>داكن</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>افتراضي</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>فاتح</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2283"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>تم تعديل المستند %s
هل تريد حفظ التغييرات التي أجريتها؟</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2290"/>
        <source>Close Without Saving</source>
        <translation>إغلاق بدون حفظ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2291"/>
        <source>Cancel</source>
        <translation>الغاء الامر</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2578"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation>لا يمكن لمحرر مستند محمول الرئيسي العثور علي أي عناوين رأسية وهوامش في المستند.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2591"/>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation>هل تريد حذف العناوين الرأسية والهوامش من المستند؟</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2613"/>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation>يتعذر علي محرر مستند محمول العثور علي إيه علامات مائية في المستند.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2626"/>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation>هل تريد حذف العلامات المائية من المستند ؟</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2648"/>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation>يتعذر علي محرر مستند محمول العثور علي إيه خلفيه في المستند.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2661"/>
        <source>Do you want to delete the Background from the document?</source>
        <translation>هل تريد حذف الخلفية من المستند ؟</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3871"/>
        <source>Your installed version of Qt</source>
        <translation>Qt نسختك المثبتة من</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4186"/>
        <source>Characters</source>
        <translation>أحرف</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4187"/>
        <source>Font type</source>
        <translation>نوع الخط</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4189"/>
        <source>Font Embedded</source>
        <translation>الخط المضمن</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4191"/>
        <source>Font Not Embedded</source>
        <translation>الخط غير مضمن</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4197"/>
        <location filename="../../src/mainwindow.cpp" line="4282"/>
        <source>Width</source>
        <translation>العرض</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4198"/>
        <location filename="../../src/mainwindow.cpp" line="4283"/>
        <source>Height</source>
        <translation>الارتفاع</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4199"/>
        <source>Filter</source>
        <translation>فلتر</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4205"/>
        <source>Path</source>
        <translation>مسار</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4209"/>
        <source>Shading</source>
        <translation>تظليل</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4221"/>
        <location filename="../../src/mainwindow.cpp" line="4279"/>
        <source>Objects</source>
        <translation>الكائنات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4221"/>
        <location filename="../../src/mainwindow.cpp" line="4292"/>
        <source>Selected</source>
        <translation>محدد</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4296"/>
        <source>Page</source>
        <translation>صفحة</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4903"/>
        <location filename="../../src/mainwindow.cpp" line="4924"/>
        <location filename="../../src/mainwindow.cpp" line="4927"/>
        <location filename="../../src/mainwindow.cpp" line="4966"/>
        <location filename="../../src/mainwindow.cpp" line="4986"/>
        <location filename="../../src/mainwindow.cpp" line="4989"/>
        <source>FDF Files (*.fdf)</source>
        <translation>(*.fdf) ملفات مستند محمول</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2401"/>
        <source>A error occurred during the signature verification!</source>
        <translation>حدث خطأ أثناء التحقق من التوقيع!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="658"/>
        <location filename="../../src/mainwindow.cpp" line="758"/>
        <location filename="../../src/mainwindow.cpp" line="3057"/>
        <location filename="../../src/mainwindow.cpp" line="3167"/>
        <location filename="../../src/mainwindow.cpp" line="3276"/>
        <source>Save failed</source>
        <translation>فشل الحفظ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="69"/>
        <source>Ctrl+Shift++</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="45"/>
        <source>Ctrl+F12</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="70"/>
        <source>Ctrl+Shift+-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="659"/>
        <location filename="../../src/mainwindow.cpp" line="759"/>
        <location filename="../../src/mainwindow.cpp" line="3058"/>
        <location filename="../../src/mainwindow.cpp" line="3168"/>
        <location filename="../../src/mainwindow.cpp" line="3277"/>
        <source>Can&apos;t save to the file:</source>
        <translation>يتعذر الحفظ إلى الملف:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="659"/>
        <location filename="../../src/mainwindow.cpp" line="759"/>
        <location filename="../../src/mainwindow.cpp" line="3058"/>
        <location filename="../../src/mainwindow.cpp" line="3168"/>
        <location filename="../../src/mainwindow.cpp" line="3277"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
قد يكون الملف للقراءة فقط أو يستخدم بواسطة تطبيق آخر.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="30"/>
        <source>Your version already has the last update!</source>
        <translation>يحتوي الإصدار بالفعل على آخر تحديث!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="38"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>النسخة الجديدة متاحه!
هل تريد تحميل الآن ؟</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="518"/>
        <location filename="../../src/mainwindow.cpp" line="520"/>
        <location filename="../../src/mainwindow.cpp" line="4924"/>
        <location filename="../../src/mainwindow.cpp" line="4927"/>
        <location filename="../../src/mainwindow.cpp" line="4986"/>
        <location filename="../../src/mainwindow.cpp" line="4989"/>
        <source>Open File</source>
        <translation>فتح ملف</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="748"/>
        <location filename="../../src/mainwindow.ui" line="751"/>
        <location filename="../../src/mainwindow.ui" line="1388"/>
        <source>Object Inspector</source>
        <translation>كائن المفتش</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="657"/>
        <source>Toolbars</source>
        <translation>أشرطة الأدوات</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="83"/>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="77"/>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="133"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="523"/>
        <source>Zoom</source>
        <translation>تكبير/تصغير</translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="14"/>
        <source>Recognized text</source>
        <translation>نص معترف به</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="20"/>
        <source>Original</source>
        <translation>أصلي</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="55"/>
        <source>Text</source>
        <translation>نص</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.cpp" line="17"/>
        <source>Not Text</source>
        <translation>لا نص</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation>نقل الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="26"/>
        <source>Page Range</source>
        <translation>نطاق الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="32"/>
        <source>Pages</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation>العينة: 1 ، 6-8 ، 12</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="78"/>
        <source>Current Page</source>
        <translation>الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="88"/>
        <source>Pages from</source>
        <translation>صفحات من</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="114"/>
        <source>to:</source>
        <translation>الى:</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="140"/>
        <source>Destination</source>
        <translation>الوجهة</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="152"/>
        <source>To:</source>
        <translation>الى:</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="162"/>
        <source>Page</source>
        <translation>صفحة</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="211"/>
        <source>First</source>
        <translation>الاول</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="218"/>
        <source>Last</source>
        <translation>الأخير</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation>حجم الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="194"/>
        <source>Width</source>
        <translation>العرض</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="231"/>
        <source>Height</source>
        <translation>الارتفاع</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="33"/>
        <source>A0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="38"/>
        <source>A1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="43"/>
        <source>A2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="48"/>
        <source>A3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="53"/>
        <source>A4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="58"/>
        <source>A5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="63"/>
        <source>A6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="68"/>
        <source>A7</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="73"/>
        <source>A8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="78"/>
        <source>A9</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="83"/>
        <source>A10</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="88"/>
        <source>Letter</source>
        <translation>رسالة</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="93"/>
        <source>Tabloid</source>
        <translation>صحيفة</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="98"/>
        <source>B0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="103"/>
        <source>B1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="108"/>
        <source>B2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="113"/>
        <source>B3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="118"/>
        <source>B4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="123"/>
        <source>B5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="128"/>
        <source>Statement</source>
        <translation>بيان</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="133"/>
        <source>Executive</source>
        <translation>تنفيذي</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="138"/>
        <source>Folio</source>
        <translation>ورقة مطوية</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="143"/>
        <source>Quarto</source>
        <translation>ربعية</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="148"/>
        <source>Note</source>
        <translation>مذكره</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="153"/>
        <source>ANSI C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="158"/>
        <source>ANSI D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="163"/>
        <source>ANSI E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="168"/>
        <source>ANSI F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="173"/>
        <source>Custom page size</source>
        <translation>حجم الصفحة المخصص</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="218"/>
        <source>Portrait</source>
        <translation>طولي</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="223"/>
        <source>Landscape</source>
        <translation>عرضي</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="267"/>
        <source>Units</source>
        <translation>وحدات</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="296"/>
        <source>Contents Size</source>
        <translation>حجم المحتويات</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="308"/>
        <source>Left margin</source>
        <translation>الهامش الأيسر</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="348"/>
        <source>Top margin</source>
        <translation>الهامش العلوي</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="328"/>
        <source>Right margin</source>
        <translation>الهامش الأيمن</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="275"/>
        <source>Points</source>
        <translation>نقاط</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="280"/>
        <source>Inches</source>
        <translation>بوصه</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="285"/>
        <source>Millimeters</source>
        <translation>ملليمتر</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="368"/>
        <source>Bottom margin</source>
        <translation>الهامش السفلي</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="391"/>
        <source>Position</source>
        <translation>موقع</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="397"/>
        <source>Before current page</source>
        <translation>قبل الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="414"/>
        <source>After current page</source>
        <translation>بعد الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="421"/>
        <source>After last page</source>
        <translation>بعد الصفحة الاخيره</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="407"/>
        <source>Before first page</source>
        <translation>قبل الصفحة الاولي</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="431"/>
        <source>Number of pages</source>
        <translation>عدد الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="457"/>
        <source>Page(s)</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="437"/>
        <source>Create</source>
        <translation>إنشاء</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="182"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="209"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="231"/>
        <source> mm</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="14"/>
        <source>OCR Engine</source>
        <translation>محرك OCR</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="29"/>
        <source>Page Range</source>
        <translation>نطاق الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="35"/>
        <source>Sample: 1,6-8,12</source>
        <translation>العينة: 1 ، 6-8 ، 12</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="42"/>
        <source>Pages</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="72"/>
        <source>Current Page</source>
        <translation>الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="82"/>
        <source>All Pages</source>
        <translation>كل الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="95"/>
        <source>Languages</source>
        <translation>اللغات</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="125"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="187"/>
        <source>Selected</source>
        <translation>محدد</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="151"/>
        <source>Install languages</source>
        <translation>تثبيت اللغات</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="170"/>
        <source>Searchable Text</source>
        <translation>نص قابل للبحث</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="180"/>
        <source>Editable Text</source>
        <translation>نص قابل للتحرير</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="200"/>
        <source>Font Family</source>
        <translation>عائله الخط</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="220"/>
        <source>Manually edit all recognized text</source>
        <translation>تحرير كافة النص الذي تم التعرف عليه يدويا</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.cpp" line="60"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="284"/>
        <source>auto</source>
        <translation>تلقائي</translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="14"/>
        <source>OCR</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="27"/>
        <source>Cancel</source>
        <translation>الغاء الامر</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.cpp" line="150"/>
        <source>Are you sure you want to stop document recognition?</source>
        <translation>هل تريد بالتاكيد إيقاف التعرف علي المستند ؟</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="57"/>
        <source>No Properties
There is no object selections.</source>
        <translation>لا توجد خصائص لا يوجد تحديدات كائن.</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="331"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3166"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3385"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2020"/>
        <source>Text</source>
        <translation>نص</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="142"/>
        <source>Property</source>
        <translation>الخاصية</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="147"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="913"/>
        <source>Value</source>
        <translation>القيمة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="466"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="797"/>
        <source>Add</source>
        <translation>اضافة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="476"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2748"/>
        <source>Actions</source>
        <translation>الإجراءات</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="498"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1869"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1903"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1975"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2031"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2867"/>
        <source>Edit</source>
        <translation>تحرير</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="508"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="784"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="574"/>
        <source>Behavior</source>
        <translation>سلوك</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="728"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1309"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1455"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1610"/>
        <source>None</source>
        <translation>لاشيء</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="733"/>
        <source>Push</source>
        <translation>دفع</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="738"/>
        <source>Outline</source>
        <translation>خطوط عريضة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="743"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1314"/>
        <source>Invert</source>
        <translation>قلب</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="777"/>
        <source>Item</source>
        <translation>مادة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="810"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1085"/>
        <source>Export Value</source>
        <translation>قيمه التصدير</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="650"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="852"/>
        <source>Up</source>
        <translation>اعلى</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="655"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="836"/>
        <source>Down</source>
        <translation>اسفل</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="880"/>
        <source>Sort Items</source>
        <translation>فرز المواد</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="859"/>
        <source>Commit selected value immediately</source>
        <translation>التزام بالقيمة المحددة فورا</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="873"/>
        <source>Multiple selection</source>
        <translation>تحديد متعدد</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="866"/>
        <source>Allow user to enter custom text</source>
        <translation>السماح للمستخدم بإدخال نص مخصص</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="960"/>
        <source>Password</source>
        <translation>كلمة السر</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="967"/>
        <source>Scrollable</source>
        <translation>قابل للتمرير</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="974"/>
        <source>Check spelling</source>
        <translation>تدقيق إملائي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="981"/>
        <source>Limit to</source>
        <translation>حدد إلى</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="995"/>
        <source>chars</source>
        <translation>حرف</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1002"/>
        <source>Split into</source>
        <translation>انقسم إلى</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="946"/>
        <source>Allow Rich Text formatting</source>
        <translation>السماح بتنسيق ريتش تكست</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="953"/>
        <source>Multi-line</source>
        <translation>متعدد - خط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1016"/>
        <source>cells</source>
        <translation>خلايا</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="928"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2496"/>
        <source>Left</source>
        <translation>يسار</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="933"/>
        <source>Center</source>
        <translation>توسيط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="938"/>
        <source>Right</source>
        <translation>يمين</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1026"/>
        <source>Default Value</source>
        <translation>القيمة الافتراضية</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="920"/>
        <source>Alignment</source>
        <translation>مواءمه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1098"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2634"/>
        <source>Style</source>
        <translation>نمط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1109"/>
        <source>Check</source>
        <translation>تحقق</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1114"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="238"/>
        <source>Circle</source>
        <translation>دائره</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1119"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="240"/>
        <source>Cross</source>
        <translation>صليب</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1124"/>
        <source>Diamond</source>
        <translation>معين</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1129"/>
        <source>Square</source>
        <translation>مربع</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1134"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="249"/>
        <source>Star</source>
        <translation>نجم</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1062"/>
        <source>Checked by Default</source>
        <translation>تحقق بشكل افتراضي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="581"/>
        <source>Layout</source>
        <translation>تخطيط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="592"/>
        <source>Label only</source>
        <translation>تسمية فقط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="597"/>
        <source>Icon only</source>
        <translation>ايقونة فقط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="602"/>
        <source>Icon top, label bottom</source>
        <translation>اعلي الايقونه ، أسفل التسمية</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="607"/>
        <source>Label top, icon bottom</source>
        <translation>اعلي التسمية ، أسفل الايقونه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="612"/>
        <source>Icon left, label right</source>
        <translation>ايقونة لليسار ، تسميه لليمين</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="617"/>
        <source>label left, icon right</source>
        <translation>التسمية اليسرى ، الايقونة اليمين</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="622"/>
        <source>Label over icon</source>
        <translation>ايقونة التسمية فوق</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="637"/>
        <source>Icon and Label</source>
        <translation>ايقونة و التسمية</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="660"/>
        <source>Rollover</source>
        <translation>يتدحرج</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="677"/>
        <source>State</source>
        <translation>الدولة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="684"/>
        <source>Choose Icon...</source>
        <translation>اختر أيقونه...</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="707"/>
        <source>Clear</source>
        <translation>تنظيف</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="714"/>
        <source>Label</source>
        <translation>تسميه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1186"/>
        <source>Buttons with the same name and value are selected in unison</source>
        <translation>يتم تحديد الأزرار التي تحمل نفس الاسم والقيمة في انسجام</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1251"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3156"/>
        <source>Line Thickness</source>
        <translation>سماكة الخط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1265"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3106"/>
        <source>Border Color</source>
        <translation>لون الحد</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1272"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3149"/>
        <source>Line Style</source>
        <translation>نمط الخط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1280"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3121"/>
        <source>Solid</source>
        <translation>صلب</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1285"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3126"/>
        <source>Dashed</source>
        <translation>متقطع</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1290"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3141"/>
        <source>Underline</source>
        <translation>أكد</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1298"/>
        <source>Highlight</source>
        <translation>تمييز</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1319"/>
        <source>OutLine</source>
        <translation>خطوط عريضة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1324"/>
        <source>Insert</source>
        <translation>ادراج</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1342"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;توقيع.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;لا توجد خيارات متوفرة&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1401"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2767"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2886"/>
        <source>Format</source>
        <translation>صيغة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1441"/>
        <source>Format category</source>
        <translation>صيغة الفئة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1460"/>
        <source>Number</source>
        <translation>عدد</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1465"/>
        <source>Percentage</source>
        <translation>مئوي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1470"/>
        <source>Date</source>
        <translation>التأريخ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1475"/>
        <source>Time</source>
        <translation>وقت</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1480"/>
        <source>Special</source>
        <translation>خاص</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1485"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1640"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="224"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="228"/>
        <source>Custom</source>
        <translation>مخصص</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1504"/>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1509"/>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1514"/>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1519"/>
        <source>3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1524"/>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1529"/>
        <source>5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1534"/>
        <source>6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1539"/>
        <source>7</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1544"/>
        <source>8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1549"/>
        <source>9</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1554"/>
        <source>10</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1563"/>
        <source>1,234.56</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1568"/>
        <source>1234.56</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1573"/>
        <source>1.234,56</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1578"/>
        <source>1234,56</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1592"/>
        <source>Currency Symbol</source>
        <translation>رمز العملة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1615"/>
        <source>Dollar ($)</source>
        <translation>الدولار ($)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1620"/>
        <source>Euro (€)</source>
        <translation>اليورو (€)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1625"/>
        <source>Pound (£)</source>
        <translation>رطل (£)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1630"/>
        <source>Yen (¥)</source>
        <translation>ين (¥)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1635"/>
        <source>Ruble (Руб)</source>
        <translation>روبل (Руб)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1661"/>
        <source>Show parentheses</source>
        <translation>إظهار الأقواس</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1681"/>
        <source>Decimal Places</source>
        <translation>المنازل العشرية</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1688"/>
        <source>Separation Style</source>
        <translation>نمط الفصل</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1695"/>
        <source>Use red text</source>
        <translation>استخدام النص الأحمر</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1712"/>
        <source>Date Options</source>
        <translation>خيارات التاريخ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1751"/>
        <source>Time Options</source>
        <translation>خيارات الوقت</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1784"/>
        <source>Special Options</source>
        <translation>خيارات خاصة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1842"/>
        <source>Format Script</source>
        <translation>تنسيق النص</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1876"/>
        <source>KeyStroke Script</source>
        <translation>مخطوطة ضربة مفتاح</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1927"/>
        <source>Validate</source>
        <translation>صدق</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1948"/>
        <source>Validation Script</source>
        <translation>مخطوطة تصديق</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1983"/>
        <source>Calculate</source>
        <translation>حساب</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2004"/>
        <source>Calculation Script</source>
        <translation>حساب البرنامج النصي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2133"/>
        <source>Fill text</source>
        <translation>تعبئة النص</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2138"/>
        <source>Stroke Text</source>
        <translation>نص حلقي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2143"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2946"/>
        <source>Fill and Stroke</source>
        <translation>تعبئة و الحلقة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2148"/>
        <source>Invisible</source>
        <translation>غير مرئى</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2162"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3113"/>
        <source>Fill Color</source>
        <translation>لون التعبئة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2188"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3014"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3437"/>
        <source>Line Width</source>
        <translation>عرض الخط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2217"/>
        <source>Character spacing</source>
        <translation>تباعد الأحرف</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2224"/>
        <source>Word spacing</source>
        <translation>تباعد الكلمات</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2231"/>
        <source>Line height</source>
        <translation>ارتفاع الخط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2274"/>
        <source>+</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2293"/>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2343"/>
        <source>F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2369"/>
        <source>D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2379"/>
        <source>E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2389"/>
        <source>A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2399"/>
        <source>C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2409"/>
        <source>B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2476"/>
        <source>Top</source>
        <translation>أعلى</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2524"/>
        <source>Maintain aspect ratio</source>
        <translation>الحفاظ علي نسبه الارتفاع</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2453"/>
        <source>Rotate</source>
        <translation>استدارة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="630"/>
        <source>Advanced</source>
        <translation>متقدم</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2552"/>
        <source>Units</source>
        <translation>وحدات</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2672"/>
        <source>Clipping Path</source>
        <translation>مسار القطع</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2805"/>
        <source>Selection change</source>
        <translation>تغيير الاختيار</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2833"/>
        <source>Do nothing</source>
        <translation>لا تفعل شيئا</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2840"/>
        <source>Execute this script</source>
        <translation>تنفيذ هذا البرنامج النصي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2936"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2954"/>
        <source>Fill</source>
        <translation>ملء</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3131"/>
        <source>Beveled</source>
        <translation>مشطوف</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3136"/>
        <source>Inset</source>
        <translation>ادرج</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3191"/>
        <source>Auto</source>
        <translation>تلقائي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3255"/>
        <source>ToolTip</source>
        <translation>اداة تلميح</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3271"/>
        <source>Orientation</source>
        <translation>التوجه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3279"/>
        <source>0 Degrees</source>
        <translation>0 درجه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3284"/>
        <source>90 Degrees</source>
        <translation>90 درجه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3289"/>
        <source>180 Degrees</source>
        <translation>180 درجه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3294"/>
        <source>270 Degrees</source>
        <translation>270 درجه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3315"/>
        <source>Read Only</source>
        <translation>قراءه فقط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3330"/>
        <source>Visible</source>
        <translation>مرئي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3335"/>
        <source>Hidden</source>
        <translation>مخفي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3340"/>
        <source>Visible but doesn&apos;t print</source>
        <translation>مرئية ولكن لا تطبع</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3345"/>
        <source>Hidden but printable</source>
        <translation>مخفيه ولكنها قابله للطباعة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3353"/>
        <source>Required</source>
        <translation>مطلوب</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3363"/>
        <source>Locked</source>
        <translation>مقفل</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3392"/>
        <source>Subject</source>
        <translation>الموضوع</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3447"/>
        <source>Author</source>
        <translation>المؤلف</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2068"/>
        <source>Font Family</source>
        <translation>عائله الخط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2097"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3178"/>
        <source>Size</source>
        <translation>حجم</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2113"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2916"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3467"/>
        <source>Type</source>
        <translation>نوع</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2503"/>
        <source>Coordinates</source>
        <translation>إحداثيات</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2511"/>
        <source>Absolute</source>
        <translation>مطلق</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2516"/>
        <source>Relative</source>
        <translation>نسبي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2560"/>
        <source>Points</source>
        <translation>نقاط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2565"/>
        <source>Inches</source>
        <translation>بوصه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2570"/>
        <source>Millimeters</source>
        <translation>ملليمتر</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2593"/>
        <source>Geometry</source>
        <translation>هندسه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2615"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3220"/>
        <source>Font</source>
        <translation>خط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2653"/>
        <source>Matrix</source>
        <translation>مصفوفة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2691"/>
        <source>General</source>
        <translation>عام</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2710"/>
        <source>Appearance</source>
        <translation>مظهر</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2729"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2786"/>
        <source>Options</source>
        <translation>الخيارات</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2941"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2989"/>
        <source>Stroke</source>
        <translation>حلقة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2979"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3001"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3207"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3417"/>
        <source>Color</source>
        <translation>لون</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3081"/>
        <source>Borders and Colors</source>
        <translation>الحدود والألوان</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3088"/>
        <source>Thin</source>
        <translation>رقيق</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3093"/>
        <source>Medium</source>
        <translation>متوسط</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3098"/>
        <source>Thick</source>
        <translation>سميك</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2175"/>
        <source>Stroke Color</source>
        <translation>حلقه ملونه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2201"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2966"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3027"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3430"/>
        <source>Opacity</source>
        <translation>العتامه</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="231"/>
        <source>Zip Code</source>
        <translation>الرمز البريدي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="231"/>
        <source>Zip Code+4</source>
        <translation>الرمز البريدي + 4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="231"/>
        <source>Phone Number</source>
        <translation>رقم الهاتف</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="231"/>
        <source>Social Security Number</source>
        <translation>رقم الضمان الاجتماعي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="237"/>
        <source>Check Mark</source>
        <translation>علامة الاختيار</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="239"/>
        <source>Comment</source>
        <translation>تعليق</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="241"/>
        <source>Help</source>
        <translation>التعليمات</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="242"/>
        <source>Insert Text</source>
        <translation>ادراج نص</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="243"/>
        <source>Key</source>
        <translation>مفتاح</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="244"/>
        <source>New Paragraph</source>
        <translation>فقره جديده</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="245"/>
        <source>Text Note</source>
        <translation>المذكرة النصية</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="246"/>
        <source>Paragraph</source>
        <translation>فقره</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="247"/>
        <source>Right Arrow</source>
        <translation>سهم لليمين</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="248"/>
        <source>Right Pointer</source>
        <translation>سهم لليمين</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="250"/>
        <source>Up Arrow</source>
        <translation>سهم لاعلي</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="251"/>
        <source>Up Left Arrow</source>
        <translation>سهم لليسار الاعلى</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="252"/>
        <source>Graph</source>
        <translation>رسم بياني</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="253"/>
        <source>Paper Clip</source>
        <translation>قصاصه ورق</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="254"/>
        <source>Attachment</source>
        <translation>مرفق</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="255"/>
        <source>Tag</source>
        <translation>بطاقة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1069"/>
        <source>Open</source>
        <translation>فتح</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1069"/>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation> (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm) كافة الملفات</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1542"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1549"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1562"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1569"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1615"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;لون الخطr&lt;/span&gt;&lt;/p&gt;&lt;p&gt;تغيير لون التعبئة&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1621"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;تغيير لون الحد&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1797"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="3768"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1802"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="3788"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1806"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="3808"/>
        <source> mm</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2044"/>
        <source>Image</source>
        <translation>صوره</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2086"/>
        <source>Shading</source>
        <translation>تظليل</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2110"/>
        <source>Header and Footer</source>
        <translation>العنوان الرأسي و الهامش</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2112"/>
        <source>Watermark</source>
        <translation>علامة مائية</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2114"/>
        <source>Background</source>
        <translation>الخلفية</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2466"/>
        <source>Width</source>
        <translation>العرض</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2486"/>
        <source>Height</source>
        <translation>الارتفاع</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2065"/>
        <source>Path</source>
        <translation>مسار</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3322"/>
        <source>Form Field</source>
        <translation>حقل نموذج</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3245"/>
        <source>Name</source>
        <translation>الاسم</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1554"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1603"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;تغيير عائله الخط&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3062"/>
        <source>Remove</source>
        <translation>أزاله</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="422"/>
        <source>Goto a Page View</source>
        <translation>انتقل إلى عرض الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="354"/>
        <source>Add an Action</source>
        <translation>أضافه اجراء</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="360"/>
        <source>Trigger</source>
        <translation>حافز</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="368"/>
        <source>Mouse Up</source>
        <translation>فأر فوق</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="373"/>
        <source>Mouse Down</source>
        <translation>فارة أسفل</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="378"/>
        <source>Mouse Enter</source>
        <translation>أدخل الماوس</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="383"/>
        <source>Mouse Exit</source>
        <translation>خروج الماوس</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="388"/>
        <source>On Receive Focus</source>
        <translation>عند تلقي التركيز</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="393"/>
        <source>On Lose Focus</source>
        <translation>عند فقدان التركيز</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="414"/>
        <source>Action</source>
        <translation>اجراء</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="427"/>
        <source>Open/execute a File</source>
        <translation>فتح/تنفيذ ملف</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="432"/>
        <source>Open a web link</source>
        <translation>فتح ارتباط ويب</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="437"/>
        <source>Reset form</source>
        <translation>أعاده تعيين النموذج</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="442"/>
        <source>Show/Hide fields</source>
        <translation>إظهار/إخفاء الحقول</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="447"/>
        <source>Submit a form</source>
        <translation>إرسال نموذج</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="452"/>
        <source>Run a JavaScript</source>
        <translation>تشغيل جافا سكريبت</translation>
    </message>
</context>
<context>
    <name>ObjectTreeView</name>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="14"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="33"/>
        <source>Object TreeView</source>
        <translation>عرض شجره الكائنات</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="20"/>
        <source>Show</source>
        <translation>اظهار</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="40"/>
        <source>Options</source>
        <translation>الخيارات</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="69"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="208"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="229"/>
        <source>Page</source>
        <translation>صفحة</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="20"/>
        <source>Expand All</source>
        <translation>توسيع الكل</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="21"/>
        <source>Collapse All</source>
        <translation>طي كل</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="64"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="107"/>
        <source>All</source>
        <translation>الكل</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="75"/>
        <source>Images</source>
        <translation>صور</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="80"/>
        <source>Paths</source>
        <translation>مسارات</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="85"/>
        <source>Shadings</source>
        <translation>الظلال</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="90"/>
        <source>Containers</source>
        <translation>الحاويات</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="113"/>
        <source>Text Fields</source>
        <translation>حقول النص</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="118"/>
        <source>List Boxes</source>
        <translation>مربعات القائمة</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="123"/>
        <source>Combo Boxes</source>
        <translation>مربعات التحرير والسرد</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="128"/>
        <source>Check Boxes</source>
        <translation>خانات الاختيار</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="133"/>
        <source>Radio Buttons</source>
        <translation>أزرار الراديو</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="138"/>
        <source>Buttons</source>
        <translation>أزرار</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="143"/>
        <source>Links</source>
        <translation>ارتباطات</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="148"/>
        <source>Signatures</source>
        <translation>التوقيعات</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="212"/>
        <source>All Pages</source>
        <translation>كل الصفحات</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation>تخطيط الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="69"/>
        <location filename="../../src/PageLayoutDialog.ui" line="89"/>
        <location filename="../../src/PageLayoutDialog.ui" line="121"/>
        <location filename="../../src/PageLayoutDialog.ui" line="138"/>
        <location filename="../../src/PageLayoutDialog.ui" line="155"/>
        <location filename="../../src/PageLayoutDialog.ui" line="172"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="257"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="102"/>
        <source>Contents Size</source>
        <translation>حجم المحتويات</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="114"/>
        <source>Left margin</source>
        <translation>الهامش الأيسر</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="131"/>
        <source>Top margin</source>
        <translation>الهامش العلوي</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="148"/>
        <source>Right margin</source>
        <translation>الهامش الأيمن</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="165"/>
        <source>Bottom margin</source>
        <translation>الهامش السفلي</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="53"/>
        <source>Page Size</source>
        <translation>حجم الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="59"/>
        <source>Width</source>
        <translation>العرض</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.cpp" line="284"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.cpp" line="306"/>
        <source> mm</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="79"/>
        <source>Height</source>
        <translation>الارتفاع</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="185"/>
        <source>Units</source>
        <translation>وحدات</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="214"/>
        <source>Page Range</source>
        <translation>نطاق الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="276"/>
        <source>Even and Odd pages</source>
        <translation>وحتى الصفحات الفردية</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="281"/>
        <source>Even pages</source>
        <translation>حتى صفحات</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="286"/>
        <source>Odd pages</source>
        <translation>الصفحات الفردية</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="304"/>
        <source>Pages from</source>
        <translation>صفحات من</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="294"/>
        <source>Current Page</source>
        <translation>الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="196"/>
        <source>Points</source>
        <translation>نقاط</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="201"/>
        <source>Inches</source>
        <translation>بوصه</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="206"/>
        <source>Millimeters</source>
        <translation>ملليمتر</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="220"/>
        <source>All Pages</source>
        <translation>كل الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="252"/>
        <source>to:</source>
        <translation>الى:</translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="14"/>
        <source>Page Properties</source>
        <translation>خصائص الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="50"/>
        <source>Tab Order</source>
        <translation>ترتيب الجدولة</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="69"/>
        <source>Use Row Order</source>
        <translation>استخدام ترتيب الصفوف</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="76"/>
        <source>Use Column Order</source>
        <translation>استخدام ترتيب الاعمده</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="62"/>
        <source>Use Document Structure</source>
        <translation>استخدام بنيه المستند</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="83"/>
        <source>Unspecified</source>
        <translation>غير معروفة</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="120"/>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="126"/>
        <source>Actions</source>
        <translation>الإجراءات</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="201"/>
        <source>Add an Action</source>
        <translation>أضافه اجراء</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="214"/>
        <source>Trigger</source>
        <translation>حافز</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="245"/>
        <source>Open Page</source>
        <translation>فتح للصفحة</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="250"/>
        <source>Close Page</source>
        <translation>إغلاق الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="207"/>
        <source>Action</source>
        <translation>اجراء</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="259"/>
        <source>Goto a Page View</source>
        <translation>انتقل إلى عرض الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="264"/>
        <source>Open/execute a File</source>
        <translation>فتح/تنفيذ ملف</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="269"/>
        <source>Open a web link</source>
        <translation>فتح ارتباط ويب</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="274"/>
        <source>Reset form</source>
        <translation>أعاده تعيين النموذج</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="279"/>
        <source>Show/Hide fields</source>
        <translation>إظهار/إخفاء الحقول</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="284"/>
        <source>Submit a form</source>
        <translation>إرسال نموذج</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="289"/>
        <source>Run a JavaScript</source>
        <translation>تشغيل جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="221"/>
        <source>Add</source>
        <translation>اضافة</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="327"/>
        <location filename="../../src/forms/PagePropertiesDlg.cpp" line="50"/>
        <source>Current Page</source>
        <translation>الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="141"/>
        <source>Edit</source>
        <translation>تحرير</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="160"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../../src/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation>ادخل كلمه السر</translation>
    </message>
    <message>
        <location filename="../../src/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation>كلمة السر:</translation>
    </message>
    <message>
        <location filename="../../src/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>الملف محمي. الرجاء إدخال كلمه سر لفتح المستند</translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <location filename="../../src/pastedialog.ui" line="14"/>
        <source>Paste to multiple pages</source>
        <translation>لصق إلى صفحات متعددة</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="26"/>
        <source>Page Range</source>
        <translation>نطاق الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="32"/>
        <source>Pages</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation>العينة: 1 ، 6-8 ، 12</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="78"/>
        <source>All pages</source>
        <translation>كل الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="88"/>
        <source>Except current one</source>
        <translation>ما عدا الحالية واحده</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <location filename="../../src/docpage/texteditor/plaintextedit.cpp" line="235"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation>لا يحتوي هذا الخط علي هذه الأحرف.
حاول اختيار خط آخر.</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="14"/>
        <source>Print Preview</source>
        <translation>معاينه قبل الطباعة</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="305"/>
        <source>Printer</source>
        <translation>الطابعة</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="320"/>
        <source>Properties</source>
        <translation>الخصائص</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="65"/>
        <source>72</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="412"/>
        <source>Document</source>
        <translation>مستند</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="417"/>
        <source>Document and Annotations</source>
        <translation>الوثيقة والشروح</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="401"/>
        <source>Print:</source>
        <translation>طباعة:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="70"/>
        <source>150</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="75"/>
        <source>300</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="80"/>
        <source>600</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="85"/>
        <source>900</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="90"/>
        <source>1200</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="104"/>
        <source>DPI</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="146"/>
        <source>All</source>
        <translation>الكل</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="161"/>
        <source>Pages</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="236"/>
        <source>Even pages</source>
        <translation>حتى صفحات</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="241"/>
        <source>Odd pages</source>
        <translation>الصفحات الفردية</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="352"/>
        <source>Actual Size</source>
        <translation>الحجم الفعلي</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="366"/>
        <source>Center</source>
        <translation>توسيط</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="359"/>
        <source>Print as Grayscale</source>
        <translation>طباعه كتدرج رمادي</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="379"/>
        <source>Aspect Ratio</source>
        <translation>نسبه الارتفاع</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="334"/>
        <source>Ignore aspect ratio</source>
        <translation>تجاهل نسبه الارتفاع</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="339"/>
        <source>Keep aspect ratio</source>
        <translation>إبقاء نسبه الارتفاع</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="344"/>
        <source>Keep aspect ratio by expanding</source>
        <translation>الحفاظ علي نسبه الجانب عن طريق توسيع</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="292"/>
        <source>Orientation</source>
        <translation>التوجه</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="41"/>
        <source>Portrait</source>
        <translation>طولي</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="46"/>
        <source>Landscape</source>
        <translation>عرضي</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="127"/>
        <source>Print as Image</source>
        <translation>طباعه كصوره</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="223"/>
        <source>Subset</source>
        <translation>فرعي</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="231"/>
        <source>All pages in range</source>
        <translation>كافة الصفحات في النطاق</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="252"/>
        <source>Duplex Printing</source>
        <translation>طباعه مزدوجة</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="258"/>
        <source>None</source>
        <translation>لاشيء</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="268"/>
        <source>Long side</source>
        <translation>جانب طويل</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="36"/>
        <location filename="../../src/printdialog/printdialog.ui" line="275"/>
        <source>Auto</source>
        <translation>تلقائي</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="282"/>
        <source>Short side</source>
        <translation>جانب قصير</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="489"/>
        <source>Page</source>
        <translation>صفحة</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="499"/>
        <source>of:</source>
        <translation>من:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="57"/>
        <source>Resolution</source>
        <translation>الدقة</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="140"/>
        <source>Page Range</source>
        <translation>نطاق الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="168"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="698"/>
        <source>Current Page</source>
        <translation>الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="200"/>
        <source>to:</source>
        <translation>الى:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="90"/>
        <source>of </source>
        <translation>من</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="126"/>
        <source>Print</source>
        <translation>طباعه</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="17"/>
        <source>Attachment</source>
        <translation>مرفق</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Name</source>
        <translation>الاسم</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Description</source>
        <translation>الوصف</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Size</source>
        <translation>حجم</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Location</source>
        <translation>موقع</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="37"/>
        <source>Insert</source>
        <translation>ادراج</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="38"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="39"/>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="479"/>
        <source>Save As...</source>
        <translation>حفظ باسم...</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="40"/>
        <source>Open</source>
        <translation>فتح</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="109"/>
        <source>Page</source>
        <translation>صفحة</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="113"/>
        <source>Attachment Tab</source>
        <translation>تبويب المرفقات</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="459"/>
        <source>Open File</source>
        <translation>فتح ملف</translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="17"/>
        <source>Add Bookmark</source>
        <translation>اضافة قائمةَ العناوين</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="18"/>
        <source>Delete Bookmark</source>
        <translation>حذف قائمةَ العناوين</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="19"/>
        <source>Bookmark Properties</source>
        <translation>خصائص  قائمة العناوين</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="20"/>
        <source>Set Destination</source>
        <translation>تعيين الوجهه</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="36"/>
        <source>Close</source>
        <translation>اغلاق</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="40"/>
        <source>Close All</source>
        <translation>إغلاق الكل</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="44"/>
        <source>Save</source>
        <translation>حفظ</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="48"/>
        <source>Save As...</source>
        <translation>حفظ باسم...</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="52"/>
        <source>Move to New Window</source>
        <translation>الانتقال إلى اطار جديد</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="153"/>
        <source>untitled</source>
        <translation>معنونة</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="921"/>
        <location filename="../../src/document/qdoctab.cpp" line="944"/>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation>لا تحتوي الحافظة علي بيانات</translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="14"/>
        <source>Email delivery</source>
        <translation>تسليم البريد الكتروني</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="29"/>
        <source>To</source>
        <translation>الى</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="39"/>
        <source>Subject</source>
        <translation>الموضوع</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="49"/>
        <source>Text</source>
        <translation>نص</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.cpp" line="9"/>
        <source>Send</source>
        <translation>إرسال</translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="96"/>
        <source>Zoom In</source>
        <translation>تكبير</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="100"/>
        <source>Zoom Out</source>
        <translation>تصغير</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="104"/>
        <source>Zoom to Selection</source>
        <translation>تكبير/تصغير للتحديد</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="108"/>
        <source>Fit Page</source>
        <translation>ملاءمة الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="112"/>
        <source>Clear Selections</source>
        <translation>مسح التحديدات</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/app_config.cpp" line="8"/>
        <source>You are not allowed to use this function in the free version</source>
        <translation>لا يسمح لك باستخدام هذه الدالة في الإصدار المجاني</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="12"/>
        <source>The unregistered version will insert a watermark</source>
        <translation>الإصدار غير المسجل سيدرج علامة مائية</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="17"/>
        <source>Open with</source>
        <translation>مفتوح مع</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="23"/>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="30"/>
        <location filename="../../src/app_config.cpp" line="35"/>
        <location filename="../../src/app_config.cpp" line="39"/>
        <location filename="../../src/app_config.cpp" line="43"/>
        <source>Build</source>
        <translation>بناء</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="23"/>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="30"/>
        <source>Based on</source>
        <translation>استنادا إلى</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="23"/>
        <location filename="../../src/app_config.cpp" line="39"/>
        <source>32 bit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="30"/>
        <location filename="../../src/app_config.cpp" line="35"/>
        <location filename="../../src/app_config.cpp" line="43"/>
        <source>64 bit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="50"/>
        <source>Reset</source>
        <translation>أعاده</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="55"/>
        <source>Set</source>
        <translation>مجموعه</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="60"/>
        <source>Brightness</source>
        <translation>سطوع</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="65"/>
        <source>Contrast</source>
        <translation>نقيض</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="70"/>
        <source>Gamma</source>
        <translation>غاما</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="75"/>
        <source>Approved</source>
        <translation>موافق عليه</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="80"/>
        <source>Confidential</source>
        <translation>سري</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="85"/>
        <source>Received</source>
        <translation>تلقي</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="90"/>
        <source>Reviewed</source>
        <translation>مستعرض</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="95"/>
        <source>Revised</source>
        <translation>مراجعة</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="100"/>
        <source>Completed</source>
        <translation>اكتملت</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="105"/>
        <source>Draft</source>
        <translation>مسودة</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="110"/>
        <source>Emergency</source>
        <translation>حالة طوارئ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="115"/>
        <source>Expired</source>
        <translation>منتهية الصلاحية</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="120"/>
        <source>Final</source>
        <translation>نهائي</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="125"/>
        <source>Verified</source>
        <translation>التحقق</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="130"/>
        <source>Void</source>
        <translation>باطل</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="135"/>
        <source>Accepted</source>
        <translation>قبلت</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="140"/>
        <source>Initial</source>
        <translation>مبدئي</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="145"/>
        <source>Rejected</source>
        <translation>مرفوض</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="150"/>
        <source>SignHere</source>
        <translation>وقع هنا</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="155"/>
        <source>Witness</source>
        <translation>شاهد</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="160"/>
        <source>Dynamic</source>
        <translation>حيوي</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="165"/>
        <source>Standard</source>
        <translation>قياسي</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="170"/>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="183"/>
        <source>Icon</source>
        <translation>أيقونة</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="188"/>
        <source>Info</source>
        <translation>معلومات</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="193"/>
        <source>Press Help button to get more info.</source>
        <translation>اضغط على زر المساعدة للحصول على مزيد من المعلومات.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="198"/>
        <source>Error.</source>
        <translation>خطا.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="203"/>
        <source>Object</source>
        <translation>الموضوع</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="208"/>
        <source>Objects</source>
        <translation>الكائنات</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="213"/>
        <source>Text</source>
        <translation>نص</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="218"/>
        <source>Image</source>
        <translation>صوره</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="223"/>
        <source>Path</source>
        <translation>مسار</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="228"/>
        <source>Shading</source>
        <translation>تظليل</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="233"/>
        <source>All Objects</source>
        <translation>كل الكائنات</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="238"/>
        <source>Forms</source>
        <translation>إستمارات</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="243"/>
        <source>Comments</source>
        <translation>التعليقات</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="248"/>
        <source>Container</source>
        <translation>الحاويات</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="253"/>
        <source>Sticky Note</source>
        <translation>ملاحظه دبقة</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="258"/>
        <source>Highlight</source>
        <translation>تمييز</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="263"/>
        <source>Underline</source>
        <translation>أكد</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="268"/>
        <source>StrikeOut</source>
        <translation>إضراب</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="273"/>
        <source>Reply</source>
        <translation>رد</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="278"/>
        <source>Typewriter</source>
        <translation>كاتبه</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="283"/>
        <source>Text Box</source>
        <translation>مربع النص</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="288"/>
        <source>Formatted Text</source>
        <translation>نص منسق</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="13"/>
        <source>Mouse Enter</source>
        <translation>أدخل الماوس</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="15"/>
        <source>Mouse Exit</source>
        <translation>خروج الماوس</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="17"/>
        <source>Mouse Down</source>
        <translation>فارة أسفل</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="19"/>
        <source>Mouse Up</source>
        <translation>فأر فوق</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="21"/>
        <source>On Receive Focus</source>
        <translation>عند تلقي التركيز</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="23"/>
        <source>On Lose Focus</source>
        <translation>عند فقدان التركيز</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="25"/>
        <source>Page Open</source>
        <translation>فتح للصفحة</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="27"/>
        <source>Page Close</source>
        <translation>إغلاق الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="29"/>
        <source>Page Visible</source>
        <translation>الصفحة مرئية</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="31"/>
        <source>Page Invisible</source>
        <translation>الصفحة غير مرئية</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="33"/>
        <source>Open Page</source>
        <translation>فتح للصفحة</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="35"/>
        <source>Close Page</source>
        <translation>إغلاق الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="37"/>
        <source>KeyStroke</source>
        <translation>ضربة المفتاح</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="39"/>
        <source>Format</source>
        <translation>صيغة</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="41"/>
        <source>Validate</source>
        <translation>التحقق من صحة</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="43"/>
        <source>Calculate</source>
        <translation>حساب</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="45"/>
        <source>Close Document</source>
        <translation>إغلاق المستند</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="47"/>
        <source>Save Document</source>
        <translation>حفظ المستند</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="49"/>
        <source>Document Saved</source>
        <translation>تم حفظ المستند</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="51"/>
        <source>Print Document</source>
        <translation>طباعه المستند</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="53"/>
        <source>Document Printed</source>
        <translation>المستند المطبوع</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="68"/>
        <source>Unknown</source>
        <translation>مجهول</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="70"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="72"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="74"/>
        <source>Goto a Page View</source>
        <translation>انتقل إلى عرض الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="76"/>
        <source>Open/execute a File</source>
        <translation>فتح/تنفيذ ملف</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="78"/>
        <source>Thread</source>
        <translation>ترابط</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="80"/>
        <source>Open a web link</source>
        <translation>فتح ارتباط ويب</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="82"/>
        <source>Sound</source>
        <translation>صوت</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="84"/>
        <source>Movie</source>
        <translation>فيلم</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="86"/>
        <source>Show/Hide fields</source>
        <translation>إظهار/إخفاء الحقول</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="90"/>
        <source>Submit Form</source>
        <translation>إرسال نموذج</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="92"/>
        <source>Reset Form</source>
        <translation>أعاده تعيين النموذج</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="94"/>
        <source>Import Data</source>
        <translation>استيراد البيانات</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="96"/>
        <source>Run a JavaScript</source>
        <translation>تشغيل جافا سكريبت</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="100"/>
        <source>Rendition</source>
        <translation>تسليم</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="104"/>
        <source>Goto 3D View</source>
        <translation>الانتقال إلى عرض ثلاثي الابعاد</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="53"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="56"/>
        <source>Open File</source>
        <translation>فتح ملف</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="53"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="56"/>
        <source>FDF Files (*.fdf)</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="583"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="585"/>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="587"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="589"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="599"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="601"/>
        <source>of</source>
        <translation>من</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="595"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="597"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="599"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="601"/>
        <source>Page</source>
        <translation>صفحة</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="2340"/>
        <source>Error!</source>
        <translation>خطا!</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="2813"/>
        <source>There was a problem with your form submission.</source>
        <translation>كانت هناك مشكله في إرسال نموذجك.</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="2815"/>
        <source>Your form was successfully submitted!</source>
        <translation>تم إرسال نموذجك بنجاح!</translation>
    </message>
</context>
<context>
    <name>QStartWidget</name>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="25"/>
        <source>Open Document</source>
        <translation>فتح مستند</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="30"/>
        <source>Blank PDF</source>
        <translation>مستند محمول فارغ</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="35"/>
        <source>From Files</source>
        <translation>من الملفات</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="40"/>
        <source>From Scanner</source>
        <translation>من الماسح الضوئي</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="47"/>
        <source>Settings</source>
        <translation>الإعدادات</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="53"/>
        <source>User Guide</source>
        <translation>دليل المستخدم</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="63"/>
        <source>Register...</source>
        <translation>تسجيل...</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="69"/>
        <source>Buy Online</source>
        <translation>شراء عبر الإنترنت</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="231"/>
        <source>Create New Document</source>
        <translation>إنشاء مستند جديد</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="234"/>
        <source>Recent Files</source>
        <translation>الملفات الأخيرة</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="119"/>
        <source>Pages</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="124"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>تكبير مصغرات الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="127"/>
        <source>Reduce Page Thumbnails</source>
        <translation>تصغير مصغرات الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="144"/>
        <source>Page Properties</source>
        <translation>خصائص الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="132"/>
        <source>Delete Pages</source>
        <translation>حذف الصفحه</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="136"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>تدوير 90 درجه باتجاه عقارب الساعة</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="139"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>تدوير 90 درجه مقابل عقارب الساعة</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="161"/>
        <source>Bookmarks</source>
        <translation>قائمةَ العناوين</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="173"/>
        <source>Attachment</source>
        <translation>مرفق</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="183"/>
        <source>Search</source>
        <translation>بحث</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="187"/>
        <source>Object TreeView</source>
        <translation>عرض شجره الكائنات</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="207"/>
        <source>Object Inspector</source>
        <translation>كائن المفتش</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="547"/>
        <source>This document contains interactive form fields</source>
        <translation>يحتوي هذا المستند علي حقول نموذج تفاعليه</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="548"/>
        <source>Highlight Fields</source>
        <translation>تمييز الحقول</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="566"/>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation>هذا المستند محمي. ليس لديك أذونات لتحرير هذا المستند</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="567"/>
        <source>Change</source>
        <translation>تغيير</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1091"/>
        <location filename="../../src/docpage/qtabpage.cpp" line="1190"/>
        <location filename="../../src/docpage/qtabpage_win.cpp" line="17"/>
        <source>There was an error printing the document</source>
        <translation>حدث خطا اثناء فتح المستند</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1433"/>
        <source>Error loading font: </source>
        <translation>خطا في تحميل الخط:</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1472"/>
        <source>Error!</source>
        <translation>خطا!</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1949"/>
        <source>Insert Blank Pages</source>
        <translation>ادراج صفحات فارغه</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="2881"/>
        <source>Do you want to open?</source>
        <translation>هل تريد فتح ؟</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3645"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>هل تريد بالتاكيد تعيين وجهه قائمة العناوين المحددة إلى الموقع الحالي ؟</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3711"/>
        <source>untitled</source>
        <translation>معنونة</translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="132"/>
        <source>More...</source>
        <translation>أكثر...</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="321"/>
        <source>User Color 99</source>
        <translation>لون المستخدم 99</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="335"/>
        <source>Black</source>
        <translation>اسود</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="336"/>
        <source>White</source>
        <translation>أبيض</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="337"/>
        <source>Red</source>
        <translation>احمر</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>Dark red</source>
        <translation>احمر داكن</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="339"/>
        <source>Green</source>
        <translation>اخضر</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="340"/>
        <source>Dark green</source>
        <translation>اخضر داكن</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="341"/>
        <source>Blue</source>
        <translation>ازرق</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="342"/>
        <source>Dark blue</source>
        <translation>ازرق داكن</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="343"/>
        <source>Cyan</source>
        <translation>سماوي</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="344"/>
        <source>Dark cyan</source>
        <translation>سماوي داكن</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="345"/>
        <source>Magenta</source>
        <translation>أرجواني</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="346"/>
        <source>Dark magenta</source>
        <translation>أرجواني داكن</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="347"/>
        <source>Yellow</source>
        <translation>اصفر</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="348"/>
        <source>Dark yellow</source>
        <translation>اصفر داكن</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="349"/>
        <source>Gray</source>
        <translation>رمادي</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="350"/>
        <source>Dark gray</source>
        <translation>رمادي داكن</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="351"/>
        <source>Light gray</source>
        <translation>رمادي فاتح</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="353"/>
        <source>Transparent</source>
        <translation>شفاف</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation>معلومات التسجيل</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="132"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>بعد إتمام طلبك ،
سوف تلقائيا
تلقي رمز تسجيلك عن طريق البريد الكتروني.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation>شراء عبر الإنترنت</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="39"/>
        <location filename="../../src/regdialog.ui" line="248"/>
        <source>Registration Code</source>
        <translation>رمز التسجيل</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="46"/>
        <location filename="../../src/regdialog.ui" line="268"/>
        <source>Activate</source>
        <translation>تنشيط</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation>تنشيط دون اتصال</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="176"/>
        <source>Registered version</source>
        <translation>النسخة المسجلة</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="183"/>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>إذا كنت ترغب في تسجيل هذا الترخيص على حاسوب آخر
انقر على زر &quot;إلغاء التنشيط&quot;.

ثم سجله حيث تحتاج.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="209"/>
        <source>Deactivate</source>
        <translation>إلغاء تنشيط</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="288"/>
        <source>Back</source>
        <translation>للخلف</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="309"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;يرجى إرسال رمز الهوية ورمز التسجيل إلى: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;عندما تستلم رمزك ادخله إلى &amp;quot؛ رمز تنشيط &amp;quot؛ الحقل&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="258"/>
        <source>Activation Code</source>
        <translation>رمز التنشيط</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="295"/>
        <source>ID</source>
        <translation>هوية</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="22"/>
        <source>Thanks for registration.</source>
        <translation>شكرا للتسجيل.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="23"/>
        <source>License is deactivated.</source>
        <translation>تم إلغاء تنشيط الترخيص.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="24"/>
        <source>You have exceeded the number of available activations.</source>
        <translation>لقد تجاوزت عدد عمليات التنشيط المتوفرة.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="25"/>
        <source>Too many activations!</source>
        <translation>الكثير من التنشيط!</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation>استدارة</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="20"/>
        <source>Page Range</source>
        <translation>نطاق الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="52"/>
        <source>Pages</source>
        <translation>الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="62"/>
        <source>Sample: 1,6-8,12</source>
        <translation>العينة: 1 ، 6-8 ، 12</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="72"/>
        <source>Current Page</source>
        <translation>الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="83"/>
        <source>Even and Odd pages</source>
        <translation>وحتى الصفحات الفردية</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="88"/>
        <source>Even pages</source>
        <translation>حتى صفحات</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="93"/>
        <source>Odd pages</source>
        <translation>الصفحات الفردية</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="101"/>
        <source>All Pages</source>
        <translation>كل الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="111"/>
        <source>Direction</source>
        <translation>الاتجاه</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="118"/>
        <source>Clockwise 90 degrees</source>
        <translation>اتجاه عقارب الساعة 90 درجه</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="123"/>
        <source>180 degrees</source>
        <translation>180 درجه</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="128"/>
        <source>Counterclockwise 90 degrees</source>
        <translation>عكس عقارب الساعة 90 درجه</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation>تصدير إلى صوره</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="318"/>
        <source>File Name</source>
        <translation>اسم الملف</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="327"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="250"/>
        <source>Page Range</source>
        <translation>نطاق الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="262"/>
        <source>All Pages</source>
        <translation>كل الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="278"/>
        <source>Pages from</source>
        <translation>صفحات من</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="295"/>
        <source>to:</source>
        <translation>الى:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="20"/>
        <source>Format</source>
        <translation>صيغة</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="61"/>
        <location filename="../../src/SaveImageDialog.ui" line="130"/>
        <source>JPEG</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="26"/>
        <source>BMP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="33"/>
        <source>PNG</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="71"/>
        <source>TIFF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="40"/>
        <source>JPEG Quality</source>
        <translation>JPEG جودة</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="110"/>
        <source>LZW</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="115"/>
        <source>ZIP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="120"/>
        <source>CCITT FAX 3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="125"/>
        <source>CCITT FAX 4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="47"/>
        <source>TIFF Compression</source>
        <translation>ضغط TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="54"/>
        <source>Transparent</source>
        <translation>شفاف</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="138"/>
        <source>MultiPage</source>
        <translation>متعدد الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="148"/>
        <source>Size</source>
        <translation>حجم</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="154"/>
        <source>Width</source>
        <translation>العرض</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="183"/>
        <source>Height</source>
        <translation>الارتفاع</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="337"/>
        <source>Antialiasing</source>
        <translation>مضاد للحواف</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="379"/>
        <source>Export:</source>
        <translation>تصدير</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="387"/>
        <source>Document</source>
        <translation>مستند</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="392"/>
        <source>Document and Annotations</source>
        <translation>الوثيقة والشروح</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="212"/>
        <source>DPI</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="13"/>
        <source>Cancel</source>
        <translation>الغاء الامر</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="14"/>
        <source>Export</source>
        <translation>تصدير</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="77"/>
        <source>Can&apos;t save to the file:</source>
        <translation>لا يمكن الحفظ إلى الملف:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="77"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
قد يكون الملف للقراءة فقط أو مستخدم من قبل تطبيق آخر.</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="439"/>
        <source>Save As TIFF Image</source>
        <translation>حفظ كصوره TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="439"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="458"/>
        <source>Save As Image</source>
        <translation>حفظ كصوره</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="458"/>
        <source>All Files (*)</source>
        <translation>كل الملفات (*. *)</translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation>حفظ الأمثل كما...</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="39"/>
        <source>Remove unused elements</source>
        <translation>أزاله العناصر غير المستخدمة</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="49"/>
        <source>Flatten form fields</source>
        <translation>تسطيح حقول النموذج</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="78"/>
        <source>Color and Grayscale Images</source>
        <translation>صور ملونه ورمادية</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="233"/>
        <source>DPI</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="123"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="266"/>
        <source>Compression</source>
        <translation>ضغط</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="143"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="286"/>
        <source>ZIP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="148"/>
        <source>JPEG</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="156"/>
        <source>Lossless</source>
        <translation>خسارة أقل</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="176"/>
        <source>JPEG Quality</source>
        <translation>JPEG جودة</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="221"/>
        <source>Black and White Images</source>
        <translation>الصور السوداء والبيضاء</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="291"/>
        <source>CCITT Group 4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="296"/>
        <source>JBIG2</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="14"/>
        <source>Scanning...</source>
        <translation>المسح...</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="40"/>
        <source>Cancel</source>
        <translation>الغاء الامر</translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="12"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="12"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="10"/>
        <source>Scan</source>
        <translation>مسح</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="37"/>
        <source>Settings</source>
        <translation>الإعدادات</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="62"/>
        <source>Single Page</source>
        <translation>صفحه واحده</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="67"/>
        <source>All Pages From Feeder</source>
        <translation>كافة الصفحات من علبه التغذية</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="101"/>
        <source>Scan:</source>
        <translation>مسح</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="143"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="84"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="74"/>
        <source>Output</source>
        <translation>ناتج</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="152"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="93"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="83"/>
        <source>Position</source>
        <translation>موقع</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="158"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="99"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="89"/>
        <source>Before current page</source>
        <translation>قبل الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="168"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="109"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="99"/>
        <source>After last page</source>
        <translation>بعد الصفحة الاخيره</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="175"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="116"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="106"/>
        <source>After current page</source>
        <translation>بعد الصفحة الحالية</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="185"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="126"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="116"/>
        <source>Before first page</source>
        <translation>قبل الصفحة الاولي</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="220"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="161"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="141"/>
        <source>Append to Current Document </source>
        <translation>إلحاق بالمستند الحالي</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="210"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="151"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="148"/>
        <source>Create New Document</source>
        <translation>إنشاء مستند جديد</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="49"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="20"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="36"/>
        <source>Input</source>
        <translation>إدخال</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="132"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="42"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="64"/>
        <source>Options</source>
        <translation>الخيارات</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="81"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="35"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="48"/>
        <source>Scanner</source>
        <translation>ماسح ضوئي</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="121"/>
        <source>Reload</source>
        <translation>إعادة تحميل</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="233"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="174"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="164"/>
        <source>Browse</source>
        <translation>استعراض</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="263"/>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="302"/>
        <source>Preview</source>
        <translation>معاينه</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="322"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="219"/>
        <source>Looking for devices. Please wait.</source>
        <translation>بحث عن الاجهزه. الرجاء الانتظار.</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="48"/>
        <source>Mode</source>
        <translation>وضع</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="58"/>
        <source>Resolution</source>
        <translation>الدقة</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="68"/>
        <source>Color</source>
        <translation>لون</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="259"/>
        <source>Flatbed</source>
        <translation>مسطح</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="261"/>
        <source>Positive Transparency</source>
        <translation>شفافية ايجابيه</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="263"/>
        <source>Negative Transparency</source>
        <translation>الشفافية السلبية</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="265"/>
        <source>Document Feeder</source>
        <translation>علبه تغذيه المستندات</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="55"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="41"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="33"/>
        <source>untitled</source>
        <translation>معنونة</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="123"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="344"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="287"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="318"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="164"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="201"/>
        <source>Save As PDF</source>
        <translation>حفظ باسم PDF</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="125"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="346"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="289"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="320"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="166"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="203"/>
        <source>PDF Files (*.pdf)</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="26"/>
        <source>Scan more pages</source>
        <translation>مسح المزيد من الصفحات</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="33"/>
        <source>Scanning complete</source>
        <translation>اكتمال المسح</translation>
    </message>
</context>
<context>
    <name>ScannerOptionsDialog</name>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="14"/>
        <source>Preview</source>
        <translation>معاينه</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="30"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="33"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="36"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="39"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>تدوير 90 درجه باتجاه عقارب الساعة</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="59"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="62"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="65"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="68"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>تدوير 90 درجه مقابل عقارب الساعة</translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="20"/>
        <source>Search</source>
        <translation>بحث</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="46"/>
        <source>0 result</source>
        <translation>0 نتيجة</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="11"/>
        <source>Case Sensitive</source>
        <translation>تحسس حاله الأحرف</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="15"/>
        <source>Include Comments</source>
        <translation>تضمين تعليقات</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="19"/>
        <source>Whole Words Only</source>
        <translation>الكلمات كلها فقط</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="55"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="63"/>
        <source> result</source>
        <translation>النتيجة</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="65"/>
        <source> result(s)</source>
        <translation>النتائج</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="67"/>
        <source> results</source>
        <translation>النتائج</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="126"/>
        <source>Case Sensitive</source>
        <translation>تحسس حاله الأحرف</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="127"/>
        <source>Include Comments</source>
        <translation>تضمين تعليقات</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="128"/>
        <source>Whole Words Only</source>
        <translation>الكلمات كلها فقط</translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="14"/>
        <source>Security PDF</source>
        <translation>أمان المستند المحمول</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation>مطلوب كلمه سر لفتح المستند</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation>كلمة سر فتح المستند </translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="71"/>
        <location filename="../../src/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation>تأكيد كلمة السر</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation>أذونات</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation>تعليق</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation>تعديل المستند</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation>نسخ المحتوي لامكانيه الوصول</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation>طباعه المستند</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation>استخراج محتوي المستند</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation>طباعه إصدار عالي الدقة من المستند</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation>تعبئة حقول النموذج أو التوقيع الموجودة</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation>أذونات كلمة السر</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="233"/>
        <source>Manage Pages and bookmarks</source>
        <translation>أداره الصفحات و قوائم العناوين </translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="275"/>
        <source>Encryption</source>
        <translation>التشفير</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="281"/>
        <source>128 bit RC4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="291"/>
        <source>256 bit AES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.cpp" line="94"/>
        <source>Document Open password does not match.</source>
        <translation>لا تتطابق كلمه سر فتح المستند.</translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.cpp" line="106"/>
        <source>Document Permission password does not match.</source>
        <translation>لا تتطابق كلمه سر اذن المستند.</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation>خصائص التوقيع</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="27"/>
        <source>Signature is VALID</source>
        <translation>التوقيع صالح</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation>تفاصيل</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation>موقعة من قبل:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="78"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="388"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="441"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="482"/>
        <source>Reason:</source>
        <translation>السبب:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="92"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="395"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="489"/>
        <source>Date:</source>
        <translation>التأريخ:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation>موقع:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation>ملخص التحقق من الصحة</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation>معلومات الاتصال بالموقع:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="405"/>
        <source>Edit</source>
        <translation>تحرير</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="432"/>
        <source>Custom</source>
        <translation>مخصص</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="448"/>
        <source>Show Image</source>
        <translation>إظهار الصورة</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="477"/>
        <source>Stretch Image</source>
        <translation>امتداد الصورة</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="333"/>
        <source>Saved Settings</source>
        <translation>الإعدادات المحفوظة</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="352"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="366"/>
        <source>None</source>
        <translation>لاشيء</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="374"/>
        <source>Save</source>
        <translation>حفظ</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="470"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="396"/>
        <source>Show Text</source>
        <translation>إظهار النص</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../../src/signature/SignatureDialog.ui" line="258"/>
        <source>Info</source>
        <translation>معلومات</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="277"/>
        <source>Sign As</source>
        <translation>تسجيل باسم</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="206"/>
        <source>Text For Signing</source>
        <translation>نص للتوقيع</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="219"/>
        <source>Location</source>
        <translation>موقع</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="226"/>
        <source>Reason</source>
        <translation>سبب</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="326"/>
        <source>Lock document after signing</source>
        <translation>قفل المستند بعد التوقيع</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="496"/>
        <source>Signature Preview</source>
        <translation>معاينه التوقيع</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="45"/>
        <source>I have reviewed this document</source>
        <translation> قمت بمراجعه هذه الوثيقة</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="46"/>
        <source>I am approving this document</source>
        <translation>انا موافق علي هذا المستند</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="47"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>اشهد علي دقه وسلامه هذه الوثيقة</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="48"/>
        <source>I agree to specified parts of this document</source>
        <translation>أوافق علي أجزاء محدده من هذا المستند</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="24"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>تم تغيير المستند أو تلفه منذ تطبيق التوقيعات.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="25"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>لم يتم تغيير المستند منذ تطبيق التواقيع.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="26"/>
        <source>Signature is INVALID</source>
        <translation>التوقيع غير صالح</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="28"/>
        <source>Signature validity is UNKNOWN</source>
        <translation>صلاحيه التوقيع مجهولة</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="29"/>
        <source>This certificate is not trusted</source>
        <translation>هذه الشهادة غير موثوق بها</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="30"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>هويه الموقعين غير معروفه لأنه لم يتم تضمينها في قائمه الهويات الموثوقه الخاصة بك ولا الشهادات الأصل الخاصة به هي الثقة الهويات.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="31"/>
        <source>Error during signature verification.</source>
        <translation>خطا اثناء التحقق من التوقيع.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="32"/>
        <source>Details: The signature byte range is invalid</source>
        <translation>تفاصيل: نطاق بايت التوقيع غير صالح</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="33"/>
        <source>I am the author of this document</source>
        <translatorcomment>انا مؤلف هذه الوثيقة</translatorcomment>
        <translation>انا مؤلف هذه الوثيقة</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="91"/>
        <source>Open Image</source>
        <translation>فتح الصورة</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="91"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>(*.tif *.png *.jpg *.jpeg *.bmp) ملفات الصور</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="379"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="475"/>
        <source>Digitally signed by </source>
        <translation>موقعه رقميا من قبل</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="385"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="479"/>
        <source>Email</source>
        <translation>بريد الكتروني</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="422"/>
        <source>Open File</source>
        <translation>فتح ملف</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="422"/>
        <source>p12 Files (*.p12)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="707"/>
        <source>Save Settings</source>
        <translation>حفظ الإعدادات</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="707"/>
        <source>Save current settings as:</source>
        <translation>حفظ الإعدادات الحالية ك:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="717"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>الإعدادات بهذا الاسم موجودة بالفعل. هل تريد استبدال الإعدادات القديمة ؟</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="779"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>هل تريد بالتاكيد حذف الاعداد</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="779"/>
        <source> ?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="407"/>
        <source>A error occurred during the signature verification!</source>
        <translation>حدث خطأ أثناء التحقق من التوقيع!</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="242"/>
        <source>Browse...</source>
        <translation>استعراض...</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="319"/>
        <source>A password is required to open certificate:</source>
        <translation>مطلوب كلمه سر لفتح الشهادة:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="191"/>
        <source>Sign</source>
        <translation>توقيع</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation>معلومات</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation>مصدر</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation>الاسم الشائع (CN)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation>المنظمة (O)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation>الوحدة التنظيمية (OU)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation>الرقم التسلسلي</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation>خوارزميه</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation>الموضوع</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation>بريد الكتروني</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation>التحقق من صحة</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation>ليس قبل</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation>ليس بعد</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>MD5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation>أضافه إلى الهويات الموثوق بها</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="286"/>
        <source>Data</source>
        <translation>البيانات</translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="99"/>
        <source>Custom</source>
        <translation>مخصص</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="82"/>
        <source>Settings</source>
        <translation>الإعدادات</translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="14"/>
        <source>Custom Stamps</source>
        <translation>طوابع مخصصه</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="23"/>
        <source>Add</source>
        <translation>اضافة</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="30"/>
        <source>Edit</source>
        <translation>تحرير</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="43"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="63"/>
        <source>Preview</source>
        <translation>معاينه</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="79"/>
        <source>Stamps</source>
        <translation>طابع</translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="14"/>
        <source>Edit Stamp</source>
        <translation>تحرير الطابع</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="26"/>
        <source>Name</source>
        <translation>الاسم</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="36"/>
        <source>Template</source>
        <translation>قالب</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="53"/>
        <source>Text</source>
        <translation>نص</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.ui" line="17"/>
        <source>Form</source>
        <translation>من</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.cpp" line="22"/>
        <source>Options</source>
        <translation>الخيارات</translation>
    </message>
</context>
<context>
    <name>TextEditDlg</name>
    <message>
        <location filename="../../src/widgets/TextEditDlg.ui" line="14"/>
        <source>Text Editor</source>
        <translation>محرر نصوص</translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="29"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;عائلة الخط&lt;/span&gt;&lt;/p&gt;&lt;p&gt;غير عائلة الخط&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="35"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;لون الخط&lt;/span&gt;&lt;/p&gt;&lt;p&gt;تغيير لون الخط&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="44"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;لون خلفية الخط&lt;/span&gt;&lt;/p&gt;&lt;p&gt;تغيير لون الخلفية&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="14"/>
        <source>Watermark</source>
        <translation>علامة مائية</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="20"/>
        <source>Saved Settings</source>
        <translation>الإعدادات المحفوظة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="39"/>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="53"/>
        <source>None</source>
        <translation>لاشيء</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="61"/>
        <source>Save</source>
        <translation>حفظ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="71"/>
        <source>Source</source>
        <translation>مصدر</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="77"/>
        <source>Text</source>
        <translation>نص</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="107"/>
        <source>File</source>
        <translation>ملف</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="114"/>
        <source>Scale</source>
        <translation>مقياس</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="124"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="362"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="368"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="462"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="578"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="584"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="615"/>
        <source>Total pages :</source>
        <translation>مجموع الصفحات:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="131"/>
        <source>Page Number</source>
        <translation>رقم الصفحة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="148"/>
        <source>Font</source>
        <translation>خط</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="154"/>
        <source>Color</source>
        <translation>لون</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="174"/>
        <source>Size</source>
        <translation>حجم</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="181"/>
        <source>auto</source>
        <translation>تلقائي</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="197"/>
        <source>Font Family</source>
        <translation>عائله الخط</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="230"/>
        <source>Browse</source>
        <translation>استعراض</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="260"/>
        <source>Appearance</source>
        <translation>مظهر</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="266"/>
        <source>Rotation</source>
        <translation>دوران</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="284"/>
        <source>Options</source>
        <translation>الخيارات</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="304"/>
        <source>Opacity</source>
        <translation>العتامه</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="360"/>
        <source>Scale relative to target page</source>
        <translation>مقياس نسبه إلى الصفحة المستهدفة</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="370"/>
        <source>Position</source>
        <translation>موقع</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="376"/>
        <source>Vertical distance</source>
        <translation>مسافة عموديه</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="390"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="449"/>
        <source>from</source>
        <translation>من</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="404"/>
        <source>Top</source>
        <translation>أعلى</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="409"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="465"/>
        <source>Center</source>
        <translation>توسيط</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="414"/>
        <source>Bottom</source>
        <translation>اسفل</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="435"/>
        <source>Horizontal distance</source>
        <translation>مسافة أفقيه</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="460"/>
        <source>Left</source>
        <translation>يسار</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="470"/>
        <source>Right</source>
        <translation>يمين</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="478"/>
        <source>Units</source>
        <translation>وحدات</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="486"/>
        <source>Points</source>
        <translation>نقاط</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="491"/>
        <source>Inches</source>
        <translation>بوصه</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="496"/>
        <source>Millimeters</source>
        <translation>ملليمتر</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="528"/>
        <source>Page Range Options...</source>
        <translation>خيارات نطاق الصفحة...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="169"/>
        <source>Save Settings</source>
        <translation>حفظ الإعدادات</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="169"/>
        <source>Save current settings as:</source>
        <translation>حفظ الإعدادات الحالية ك:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="179"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>الإعدادات بهذا الاسم موجودة بالفعل. هل تريد استبدال الإعدادات القديمة ؟</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="215"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>هل تريد بالتاكيد حذف الاعداد</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="215"/>
        <source> ?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="290"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="306"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="324"/>
        <source> mm</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="346"/>
        <source>Open File</source>
        <translation>فتح ملف</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="346"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>(*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm) كل الملفات المدعومة </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="372"/>
        <source>There was an error opening the document !</source>
        <translation>حدث خطا اثناء فتح المستند!</translation>
    </message>
</context>
</TS>
