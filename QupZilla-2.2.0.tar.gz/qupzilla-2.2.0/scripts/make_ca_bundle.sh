#!/bin/bash
#Will probably work only for Debian based distros

cp /etc/ssl/certs/ca-certificates.crt ../src/lib/data/data/ca-bundle.crt

exit 0
