<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr_FR" version="2.1">
<context>
    <name>AutoScrollSettings</name>
    <message>
        <location filename="../autoscrollsettings.ui" line="14"/>
        <source>AutoScroll Settings</source>
        <translation>Paramètres du défilement automatique</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="72"/>
        <source>&lt;h1&gt;AutoScroll&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Défilement automatique&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="109"/>
        <source>Scroll Divider:</source>
        <translation>Pas du défilement :</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="138"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Setting higher divider will slow down scrolling</source>
        <translation>&lt;b&gt;Remarque :&lt;/b&gt; la vitesse de défilement est inversement proportionnelle au pas de défilement</translation>
    </message>
</context>
</TS>