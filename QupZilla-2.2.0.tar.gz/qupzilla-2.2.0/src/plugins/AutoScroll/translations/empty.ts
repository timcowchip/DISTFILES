<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>AutoScrollSettings</name>
    <message>
        <location filename="../autoscrollsettings.ui" line="14"/>
        <source>AutoScroll Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="68"/>
        <source>&lt;h1&gt;AutoScroll&lt;/h1&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="105"/>
        <source>Scroll Divider:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="134"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Setting higher divider will slow down scrolling</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
