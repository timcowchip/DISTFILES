<?xml version="1.0" ?><!DOCTYPE TS><TS language="da_DK" version="2.1">
<context>
    <name>AutoScrollSettings</name>
    <message>
        <location filename="../autoscrollsettings.ui" line="14"/>
        <source>AutoScroll Settings</source>
        <translation>Indstillinger for autorul</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="68"/>
        <source>&lt;h1&gt;AutoScroll&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Autorul&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="105"/>
        <source>Scroll Divider:</source>
        <translation>Ruladskiller:</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="134"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Setting higher divider will slow down scrolling</source>
        <translation>&lt;b&gt;Bemærk:&lt;/b&gt; Indstilling af højere adskillere vil gøre rulning langsommere</translation>
    </message>
</context>
</TS>