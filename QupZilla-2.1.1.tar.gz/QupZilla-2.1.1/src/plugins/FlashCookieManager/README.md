FlashCookieManager extension for QupZilla
-------------------------------------------------
An extension to manage flash cookies.

![conf2](http://i.imgur.com/TGCG5ok.png)

You will find more information about the configuration and usage of this extension in the [wiki](https://github.com/QupZilla/qupzilla-plugins/wiki/Flash-Cookie-Manager).

**Links about flash cookie**
 - [Local shared object] (http://en.wikipedia.org/wiki/Local_shared_object)
 - [You Deleted Your Cookies? Think Again] (http://www.wired.com/2009/08/you-deleted-your-cookies-think-again/)
 