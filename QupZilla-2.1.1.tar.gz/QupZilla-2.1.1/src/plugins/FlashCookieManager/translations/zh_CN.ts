<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.1">
<context>
    <name>FCM_Dialog</name>
    <message>
        <location filename="../fcm_dialog.ui" line="14"/>
        <source>Flash Cookies</source>
        <translation>Flash Cookie</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="24"/>
        <source>Stored Flash Cookies</source>
        <translation>存储的 Flash Cookie</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="45"/>
        <source>Find: </source>
        <translation>查找：</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="73"/>
        <location filename="../fcm_dialog.ui" line="120"/>
        <location filename="../fcm_dialog.ui" line="130"/>
        <location filename="../fcm_dialog.ui" line="140"/>
        <location filename="../fcm_dialog.ui" line="256"/>
        <location filename="../fcm_dialog.cpp" line="151"/>
        <location filename="../fcm_dialog.cpp" line="152"/>
        <location filename="../fcm_dialog.cpp" line="153"/>
        <location filename="../fcm_dialog.cpp" line="154"/>
        <source>&lt;flash cookie not selected&gt;</source>
        <translation>&lt;未选择 Flash Cookie&gt;</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="83"/>
        <source>Last Modified:</source>
        <translation>最后修改：</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="96"/>
        <source>Name:</source>
        <translation>名称：</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="106"/>
        <source>Size:</source>
        <translation>大小：</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="113"/>
        <location filename="../fcm_dialog.cpp" line="277"/>
        <location filename="../fcm_dialog.cpp" line="305"/>
        <source>Origin:</source>
        <translation>来源：</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="152"/>
        <source>Extracted latin1 strings:</source>
        <translation>提取的 latin1 字符串：</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="182"/>
        <source>These flash cookies are stored on your computer:</source>
        <translation>存储在您的计算机上的 Flash Cookie：</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="202"/>
        <source>Origin</source>
        <translation>来源</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="227"/>
        <source>Reload from disk</source>
        <translation>重新从磁盘加载</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="240"/>
        <source>Path:</source>
        <translation>路径：</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="253"/>
        <source>Click to open containing folder</source>
        <translation>点击打开所在文件夹</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="276"/>
        <source>Remove all flash cookies</source>
        <translation>移除所有 Flash Cookie</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="283"/>
        <location filename="../fcm_dialog.cpp" line="156"/>
        <source>Remove flash cookies</source>
        <translation>移除 Flash Cookie</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="308"/>
        <source>Flash Cookies Filtering</source>
        <translation>Flash Cookie 筛选</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="316"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Flash cookie whitelist&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Flash Cookie 白名单&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="348"/>
        <location filename="../fcm_dialog.ui" line="416"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="355"/>
        <location filename="../fcm_dialog.ui" line="423"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="364"/>
        <source>Flash cookies from these origins will not be deleted automatically. (Also detection of them will not be notified to user.)</source>
        <translation>来自这些来源的 Flash Cookie 将不会被自动删除（检测到它们时也将不会通知用户）。</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="374"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Flash cookie blacklist&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Flash Cookies 黑名单&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="381"/>
        <source>Flash cookies from these origins will be deleted without any notification.</source>
        <translation>来自这些来源的 Flash Cookie 将会被自动删除，没有任何通知。</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="442"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="453"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Flash Cookie Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Flash Cookie 设置&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="475"/>
        <source>Auto mode: The flash data directory will be checked regularly. and flash cookies in blacklist will be deleted automatically.</source>
        <translation>自动模式：Flash 数据目录将被定期检查，列在黑名单中的 Flash Cookie 将被自动删除。</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="510"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; This settings are just applied to flash cookies, to manage HTTP cookies use &lt;span style=&quot; font-weight:600;&quot;&gt;Cookies Manager&lt;/span&gt;. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;注意：&lt;/span&gt;此设置只适用于 Flash Cookie，若要管理 HTTP Cookie，请使用 &lt;span style=&quot; font-weight:600;&quot;&gt;Cookie 管理器&lt;/span&gt;。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="538"/>
        <source>Notification: User will be notified for every new flash cookie that is not in blacklist and whitelist.</source>
        <translation>通知：每个新出现的 Flash Cookie 且未列于白名单和黑名单时，用户将收到通知。</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.ui" line="565"/>
        <source>Delete all flash cookies on exit/start. (except those are in whitelist)</source>
        <translation>退出/启动时删除所有 Flash Cookie。（除非其在白名单中）</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="76"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="93"/>
        <source>Confirmation</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="94"/>
        <source>Are you sure you want to delete all flash cookies on your computer?</source>
        <translation>您确定要删除计算机上的所有 Flash Cookie？</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="166"/>
        <location filename="../fcm_dialog.cpp" line="237"/>
        <source> (settings)</source>
        <translation>（设置）</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="169"/>
        <source> Byte</source>
        <translation>字节</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="175"/>
        <source>Remove flash cookie</source>
        <translation>移除 Flash Cookie</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="241"/>
        <source> [new]</source>
        <translation>[新]</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="277"/>
        <location filename="../fcm_dialog.cpp" line="375"/>
        <source>Add to whitelist</source>
        <translation>添加到白名单</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="289"/>
        <location filename="../fcm_dialog.cpp" line="317"/>
        <source>Already whitelisted!</source>
        <translation>已在白名单！</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="289"/>
        <source>The server &quot;%1&quot; is already in blacklist, please remove it first.</source>
        <translation>服务器 &quot;%1&quot; 已经存在于黑名单中，请先移除它。</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="305"/>
        <location filename="../fcm_dialog.cpp" line="374"/>
        <source>Add to blacklist</source>
        <translation>添加到黑名单</translation>
    </message>
    <message>
        <location filename="../fcm_dialog.cpp" line="317"/>
        <source>The origin &quot;%1&quot; is already in whitelist, please remove it first.</source>
        <translation>来源 &quot;%1&quot; 已经存在于白名单中，请先移除它。</translation>
    </message>
</context>
<context>
    <name>FCM_Notification</name>
    <message>
        <location filename="../fcm_notification.ui" line="45"/>
        <source>New flash cookie was detected!</source>
        <translation>检测到新的 Flash Cookie！</translation>
    </message>
    <message>
        <location filename="../fcm_notification.ui" line="52"/>
        <source>View</source>
        <translation>查看</translation>
    </message>
    <message>
        <location filename="../fcm_notification.cpp" line="34"/>
        <source>A new flash cookie was detected</source>
        <translation>检测到了一个新的 Flash Cookie</translation>
    </message>
    <message>
        <location filename="../fcm_notification.cpp" line="37"/>
        <source>%1 new flash cookies were detected</source>
        <translation>检测到了 %1 个新的 Flash Cookie</translation>
    </message>
</context>
<context>
    <name>FCM_Plugin</name>
    <message>
        <location filename="../fcm_plugin.cpp" line="129"/>
        <source>Flash Cookie Manager</source>
        <translation>Flash Cookie 管理器</translation>
    </message>
    <message>
        <location filename="../fcm_plugin.cpp" line="357"/>
        <source>Show Flash Cookie Manager</source>
        <translation>显示 Flash Cookie 管理器</translation>
    </message>
    <message>
        <location filename="../fcm_plugin.cpp" line="439"/>
        <source>!default</source>
        <translation>!默认</translation>
    </message>
    <message>
        <location filename="../fcm_plugin.cpp" line="451"/>
        <source>!other</source>
        <translation>!其他</translation>
    </message>
</context>
</TS>