<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr@ijekavianlatin" version="2.1">
<context>
    <name>AutoScrollSettings</name>
    <message>
        <location filename="../autoscrollsettings.ui" line="14"/>
        <source>AutoScroll Settings</source>
        <translation>Postavke Autoklizanja</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="72"/>
        <source>&lt;h1&gt;AutoScroll&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Autoklizanje&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="109"/>
        <source>Scroll Divider:</source>
        <translation>Djelilac:</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="138"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Setting higher divider will slow down scrolling</source>
        <translation>&lt;b&gt;Napomena:&lt;/b&gt; Postavljanje djelioca na višu vrijednost će usporiti klizanje</translation>
    </message>
</context>
</TS>