<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_PT" version="2.1">
<context>
    <name>AutoScrollSettings</name>
    <message>
        <location filename="../autoscrollsettings.ui" line="14"/>
        <source>AutoScroll Settings</source>
        <translation>Definições</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="68"/>
        <source>&lt;h1&gt;AutoScroll&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Deslocação automática&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="105"/>
        <source>Scroll Divider:</source>
        <translation>Divisor de deslocação:</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="134"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Setting higher divider will slow down scrolling</source>
        <translation>&lt;b&gt;Nota:&lt;/b&gt; um número de divisor alto atrasa a deslocação</translation>
    </message>
</context>
</TS>