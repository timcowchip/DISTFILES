<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.1">
<context>
    <name>AutoScrollSettings</name>
    <message>
        <location filename="../autoscrollsettings.ui" line="14"/>
        <source>AutoScroll Settings</source>
        <translation>Ustawienia Automatycznego Przewijania</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="72"/>
        <source>&lt;h1&gt;AutoScroll&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Automatyczne przewijanie&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="109"/>
        <source>Scroll Divider:</source>
        <translation>Dzielnik przewijania:</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="138"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Setting higher divider will slow down scrolling</source>
        <translation>&lt;b&gt;Uwaga:&lt;/b&gt; Ustawienie wyższego dzielnika spowolni przewijanie</translation>
    </message>
</context>
</TS>