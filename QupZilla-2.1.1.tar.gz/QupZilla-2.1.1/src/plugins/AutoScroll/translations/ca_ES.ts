<?xml version="1.0" ?><!DOCTYPE TS><TS language="ca_ES" version="2.1">
<context>
    <name>AutoScrollSettings</name>
    <message>
        <location filename="../autoscrollsettings.ui" line="14"/>
        <source>AutoScroll Settings</source>
        <translation>Ajustaments del desplaçament automàtic</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="72"/>
        <source>&lt;h1&gt;AutoScroll&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Desplaçament automàtic&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="109"/>
        <source>Scroll Divider:</source>
        <translation>Separador de desplaçament</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="138"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Setting higher divider will slow down scrolling</source>
        <translation>&lt;b&gt;Nota:&lt;/b&gt; Posar el separador molt alt farà que el desplaçament sigui més lent</translation>
    </message>
</context>
</TS>