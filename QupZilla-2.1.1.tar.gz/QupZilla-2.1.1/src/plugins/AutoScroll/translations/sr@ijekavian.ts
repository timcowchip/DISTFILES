<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr@Ijekavian" version="2.1">
<context>
    <name>AutoScrollSettings</name>
    <message>
        <location filename="../autoscrollsettings.ui" line="14"/>
        <source>AutoScroll Settings</source>
        <translation>Поставке Аутоклизања</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="68"/>
        <source>&lt;h1&gt;AutoScroll&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Аутоклизање&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="105"/>
        <source>Scroll Divider:</source>
        <translation>Дјелилац:</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="134"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Setting higher divider will slow down scrolling</source>
        <translation>&lt;b&gt;Напомена:&lt;/b&gt; Постављање дјелиоца на вишу вриједност ће успорити клизање</translation>
    </message>
</context>
</TS>