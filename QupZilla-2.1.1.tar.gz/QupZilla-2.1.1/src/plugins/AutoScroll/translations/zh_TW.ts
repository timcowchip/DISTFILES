<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_TW" version="2.1">
<context>
    <name>AutoScrollSettings</name>
    <message>
        <location filename="../autoscrollsettings.ui" line="14"/>
        <source>AutoScroll Settings</source>
        <translation>自動捲動設定</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="72"/>
        <source>&lt;h1&gt;AutoScroll&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;自動捲動&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="109"/>
        <source>Scroll Divider:</source>
        <translation>捲軸分隔器：</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="138"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Setting higher divider will slow down scrolling</source>
        <translation>&lt;b&gt;注意：&lt;/b&gt;設定過高的分隔器會導致捲動速度變慢</translation>
    </message>
</context>
</TS>