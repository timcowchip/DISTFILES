<?xml version="1.0" ?><!DOCTYPE TS><TS language="nqo" version="2.1">
<context>
    <name>AutoScrollSettings</name>
    <message>
        <location filename="../autoscrollsettings.ui" line="14"/>
        <source>AutoScroll Settings</source>
        <translation>ߖߘߍ߬ߟߕߊ߬ߡߌ߲߬ߠߌ߲ ߘߐ߬ߓߍ߲߬ߠߌ߲ ߠߎ߬</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="72"/>
        <source>&lt;h1&gt;AutoScroll&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;ߖߘߍ߬ߟߕߊ߬ߡߌ߲߬ߠߌ߲&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="109"/>
        <source>Scroll Divider:</source>
        <translation>ߟߕߊ߬ߡߌ߲߬ߠߌ߲ ߕߍߓߐߟߊ߲:</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="138"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Setting higher divider will slow down scrolling</source>
        <translation>&lt;b&gt;ߦߟߌߣߐ:&lt;/b&gt;  ߘߐ߬ߓߍ߲߬ߠߌ߲ ߕߍߓߐߟߊ߲ ߛߊ߲ߘߐߕߊ ߘߌ߫ ߟߕߊ߬ߡߌ߲߬ߠߌ߲ ߠߊߛߎߡߦߊ߫</translation>
    </message>
</context>
</TS>