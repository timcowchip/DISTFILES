TabManager extension for QupZilla
-------------------------------------------------
This extension adds the ability to manage tabs and windows in QupZilla.

![tbm3](http://i.imgur.com/Gh8bEXo.png)

You will find more information about the configuration and usage of this extension in the [wiki](https://github.com/QupZilla/qupzilla-plugins/wiki/Tab-Manager).

**TODOs**

* Modifying `refresh` algorithm for updating changed items and not all items.
