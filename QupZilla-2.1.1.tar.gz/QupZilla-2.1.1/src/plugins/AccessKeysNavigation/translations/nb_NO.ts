<?xml version="1.0" ?><!DOCTYPE TS><TS language="nb_NO" version="2.0">
<context>
    <name>AKN_Settings</name>
    <message>
        <location filename="../akn_settings.ui" line="14"/>
        <source>Access Keys Navigation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="20"/>
        <source>&lt;h1&gt;Access Keys Navigation&lt;/h1&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="33"/>
        <source>Ctrl</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="38"/>
        <source>Alt</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="43"/>
        <source>Shift</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="51"/>
        <source>Double press</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="58"/>
        <source>Key for showing access keys:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="103"/>
        <source>License</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>