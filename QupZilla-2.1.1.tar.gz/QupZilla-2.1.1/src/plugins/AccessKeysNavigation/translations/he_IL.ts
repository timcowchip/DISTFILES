<?xml version="1.0" ?><!DOCTYPE TS><TS language="he_IL" version="2.1">
<context>
    <name>AKN_Settings</name>
    <message>
        <location filename="../akn_settings.ui" line="14"/>
        <source>Access Keys Navigation</source>
        <translation>ניווט מקשי גישה</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="20"/>
        <source>&lt;h1&gt;Access Keys Navigation&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;ניווט מקשי גישה&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="33"/>
        <source>Ctrl</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="38"/>
        <source>Alt</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="43"/>
        <source>Shift</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="51"/>
        <source>Double press</source>
        <translation>לחיצה כפולה</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="58"/>
        <source>Key for showing access keys:</source>
        <translation>מקש לשם הצגת מקשי גישה:</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="103"/>
        <source>License</source>
        <translation>רשיון</translation>
    </message>
</context>
</TS>