<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk_UA" version="2.1">
<context>
    <name>MouseGesturesSettingsDialog</name>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="14"/>
        <source>Mouse Gestures</source>
        <translation>Мишачі жести</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="42"/>
        <source>&lt;h1&gt;Mouse Gestures&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Мишачі жести&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="181"/>
        <source>&lt;b&gt;Stop&lt;/b&gt;&lt;br/&gt;Stop loading page</source>
        <translation>&lt;b&gt;Зупинити&lt;/b&gt;&lt;br/&gt;Зупинити завантаження сторінки</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="195"/>
        <source>&lt;b&gt;New tab&lt;/b&gt;&lt;br/&gt;Open new tab</source>
        <translation>&lt;b&gt;Нова вкладка&lt;/b&gt;&lt;br/&gt;Відкрити нову вкладку</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="209"/>
        <source>&lt;b&gt;Back&lt;/b&gt;&lt;br/&gt;Go back in history</source>
        <translation>&lt;b&gt;Назад&lt;/b&gt;&lt;br/&gt;Перейти назад</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="299"/>
        <source>&lt;b&gt;Reload&lt;/b&gt;&lt;br/&gt;Reload page</source>
        <translation>&lt;b&gt;Перезавантажити&lt;/b&gt;&lt;br/&gt;Перезавантажити сторінку</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="236"/>
        <source>&lt;b&gt;Close tab&lt;/b&gt;&lt;br/&gt;Close current tab</source>
        <translation>&lt;b&gt;Закрити вкладку&lt;/b&gt;&lt;br/&gt;Закрити поточну вкладку</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="90"/>
        <source>Mouse button:</source>
        <translation>Кнопка миші:</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="98"/>
        <source>Middle button</source>
        <translation>Середня кнопка</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="103"/>
        <source>Right button</source>
        <translation>Права кнопка</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="108"/>
        <source>Disabled</source>
        <translation>Вимкнено</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="116"/>
        <source>Rocker Navigation:</source>
        <translation>Навігація Rocker:</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="123"/>
        <source>Enable Rocker Navigation</source>
        <translation>Увімкнути навігацію в стилі Rocker</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="147"/>
        <source>Press and hold the mouse button and move your mouse in the indicated directions.</source>
        <translation>Затисніть кнопку миші и пересувайте мишу у зазначених напрямах.</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="250"/>
        <source>&lt;b&gt;Forward&lt;/b&gt;&lt;br/&gt;Go forward in history</source>
        <translation>&lt;b&gt;Вперед&lt;/b&gt;&lt;br/&gt;Перейти вперед</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="257"/>
        <source>&lt;b&gt;Previous tab&lt;/b&gt;&lt;br/&gt;Switch to previous tab</source>
        <translation>&lt;b&gt;Попередня вкладка&lt;/b&gt;&lt;br/&gt;Перемкнутись на попередню вкладку</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="271"/>
        <source>&lt;b&gt;Home&lt;/b&gt;&lt;br/&gt;Go to homepage</source>
        <translation>&lt;b&gt;Домашня сторнка&lt;/b&gt;&lt;br/&gt;Перейти на домашню сторінку</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="285"/>
        <source>&lt;b&gt;Next tab&lt;/b&gt;&lt;br/&gt;Switch to next tab</source>
        <translation>&lt;b&gt;Наступна вкладка&lt;/b&gt;&lt;br/&gt;Перемкнутись на наступну вкладку</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="313"/>
        <source>&lt;b&gt;Duplicate&lt;/b&gt;&lt;br/&gt;Duplicate current tab</source>
        <translation>&lt;b&gt;Дублювати&lt;/b&gt;&lt;br/&gt;Дублювати поточну вкладку</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="337"/>
        <source>License</source>
        <translation>Ліцензія</translation>
    </message>
</context>
</TS>