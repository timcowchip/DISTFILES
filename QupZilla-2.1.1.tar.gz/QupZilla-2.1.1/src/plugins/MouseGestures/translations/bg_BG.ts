<?xml version="1.0" ?><!DOCTYPE TS><TS language="bg_BG" version="2.1">
<context>
    <name>MouseGesturesSettingsDialog</name>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="14"/>
        <source>Mouse Gestures</source>
        <translation>Жестове с мишката</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="42"/>
        <source>&lt;h1&gt;Mouse Gestures&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Жестове с мишката&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="181"/>
        <source>&lt;b&gt;Stop&lt;/b&gt;&lt;br/&gt;Stop loading page</source>
        <translation>&lt;b&gt;Прекратяване&lt;/b&gt;&lt;br/&gt;Прекратяване зареждането на страницата</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="195"/>
        <source>&lt;b&gt;New tab&lt;/b&gt;&lt;br/&gt;Open new tab</source>
        <translation>&lt;b&gt;Нов раздел&lt;/b&gt;&lt;br/&gt;Отваряне на нов раздел</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="209"/>
        <source>&lt;b&gt;Back&lt;/b&gt;&lt;br/&gt;Go back in history</source>
        <translation>&lt;b&gt;Назад&lt;/b&gt;&lt;br/&gt;Връщане назад</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="299"/>
        <source>&lt;b&gt;Reload&lt;/b&gt;&lt;br/&gt;Reload page</source>
        <translation>&lt;b&gt;Презареждане&lt;/b&gt;&lt;br/&gt;Презареждане на страницата</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="236"/>
        <source>&lt;b&gt;Close tab&lt;/b&gt;&lt;br/&gt;Close current tab</source>
        <translation>&lt;b&gt;Затваряне на раздел&lt;/b&gt;&lt;br/&gt;Затваряне на настоящия раздел</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="90"/>
        <source>Mouse button:</source>
        <translation>Бутон на мишката:</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="98"/>
        <source>Middle button</source>
        <translation>Среден бутон</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="103"/>
        <source>Right button</source>
        <translation>Десен бутон</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="108"/>
        <source>Disabled</source>
        <translation>Изключено</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="116"/>
        <source>Rocker Navigation:</source>
        <translation>Поклащаща Навигация:</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="123"/>
        <source>Enable Rocker Navigation</source>
        <translation>Разрешаване на Поклащаща Навигация</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="147"/>
        <source>Press and hold the mouse button and move your mouse in the indicated directions.</source>
        <translation>Натиснете и задръжте бутона на мишката и я преместете в указаните посоки.</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="250"/>
        <source>&lt;b&gt;Forward&lt;/b&gt;&lt;br/&gt;Go forward in history</source>
        <translation>&lt;b&gt;Напред&lt;/b&gt;&lt;br/&gt;Отиване напред в историята</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="257"/>
        <source>&lt;b&gt;Previous tab&lt;/b&gt;&lt;br/&gt;Switch to previous tab</source>
        <translation>&lt;b&gt;Предишен раздел&lt;/b&gt;&lt;br/&gt;Превключване към предишен раздел</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="271"/>
        <source>&lt;b&gt;Home&lt;/b&gt;&lt;br/&gt;Go to homepage</source>
        <translation>&lt;b&gt;Начало&lt;/b&gt;&lt;br/&gt;Отваряне на началната страница</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="285"/>
        <source>&lt;b&gt;Next tab&lt;/b&gt;&lt;br/&gt;Switch to next tab</source>
        <translation>&lt;b&gt;Следващ раздел&lt;/b&gt;&lt;br/&gt;Превключване към следващ раздел</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="313"/>
        <source>&lt;b&gt;Duplicate&lt;/b&gt;&lt;br/&gt;Duplicate current tab</source>
        <translation>Повторно отваряне на този раздел</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="337"/>
        <source>License</source>
        <translation>Лиценз</translation>
    </message>
</context>
</TS>