<?xml version="1.0" ?><!DOCTYPE TS><TS language="te" version="2.0">
<context>
    <name>MouseGesturesSettingsDialog</name>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="14"/>
        <source>Mouse Gestures</source>
        <translation>మౌస్ సంజ్ఞలు</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="42"/>
        <source>&lt;h1&gt;Mouse Gestures&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;మౌస్ సంజ్ఞలు&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="64"/>
        <source>Press and hold the middle mouse button and move your mouse in the indicated directions.</source>
        <translation>మౌస్ మద్య మీటను నొక్కి ఉంచి సూచించిన దిస వైపు మౌస్ ను కదపండి</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="111"/>
        <source>&lt;b&gt;Stop&lt;/b&gt;&lt;br/&gt;Stop loading page</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="125"/>
        <source>&lt;b&gt;New tab&lt;/b&gt;&lt;br/&gt;Open new tab</source>
        <translation>&lt;b&gt;కొత్త ట్యాబ్&lt;/b&gt;&lt;br/&gt;కొత్త ట్యాబ్ ను తెరువు</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="139"/>
        <source>&lt;b&gt;Back&lt;/b&gt;&lt;br/&gt;Go back in history</source>
        <translation>&lt;b&gt;వెనుకకు&lt;/b&gt;&lt;br/&gt;చరిత్రలొ వెన్నకి వెల్లండి</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="159"/>
        <source>&lt;b&gt;Reload&lt;/b&gt;&lt;br/&gt;Reload page</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="173"/>
        <source>&lt;b&gt;Close tab&lt;/b&gt;&lt;br/&gt;Close current tab</source>
        <translation>&lt;b&gt;ట్యాబ్ ను మూసివేయ్&lt;/b&gt;&lt;br/&gt;ప్రస్తుత ట్యాబ్ ను మూసివేయ్</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="187"/>
        <source>&lt;b&gt;Forward&lt;/b&gt;&lt;br/&gt;Go forward in history</source>
        <translation>&lt;b&gt;ముందుకు&lt;/b&gt;&lt;br/&gt;చరిత్రలొ ముందుకు వెల్లు</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="194"/>
        <source>&lt;b&gt;Previous tab&lt;/b&gt;&lt;br/&gt;Switch to previous tab</source>
        <translation>&lt;b&gt;పూర్వపు ట్యాబ్&lt;/b&gt;&lt;br/&gt;పూర్వపు ట్యాబ్ కు మారు</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="208"/>
        <source>&lt;b&gt;Home&lt;/b&gt;&lt;br/&gt;Go to homepage</source>
        <translation>&lt;b&gt;హొం&lt;/b&gt;&lt;br/&gt;హొం పేజ్ కు వెల్లు</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="222"/>
        <source>&lt;b&gt;Next tab&lt;/b&gt;&lt;br/&gt;Switch to next tab</source>
        <translation>&lt;b&gt;తరువత ట్యాబ్&lt;/b&gt;&lt;br/&gt;తరువత ట్యాబ్ కు మారు</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="253"/>
        <source>License</source>
        <translation>అనుమతి పత్రం</translation>
    </message>
</context>
</TS>