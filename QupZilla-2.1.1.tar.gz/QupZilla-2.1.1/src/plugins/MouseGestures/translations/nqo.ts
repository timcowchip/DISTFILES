<?xml version="1.0" ?><!DOCTYPE TS><TS language="nqo" version="2.1">
<context>
    <name>MouseGesturesSettingsDialog</name>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="14"/>
        <source>Mouse Gestures</source>
        <translation>ߢߌߣߊߣߍ߲ ߠߊߡߊ߰ ߢߊ ߟߎ߬</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="42"/>
        <source>&lt;h1&gt;Mouse Gestures&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;ߢߌߣߊߣߍ߲ ߠߊߡߊ߰ ߢߊ ߟߎ߬&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="181"/>
        <source>&lt;b&gt;Stop&lt;/b&gt;&lt;br/&gt;Stop loading page</source>
        <translation>&lt;b&gt;ߊ߬ ߟߊߟߐ߬&lt;/b&gt;&lt;br/&gt;ߞߐߜߍ߫ ߟߊߦߟߍ ߟߊߟߐ߬</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="195"/>
        <source>&lt;b&gt;New tab&lt;/b&gt;&lt;br/&gt;Open new tab</source>
        <translation>&lt;b&gt;ߛߏ߬ߙߌ߲߬ߘߐ߬ ߞߎߘߊ&lt;/b&gt;&lt;br/&gt;ߛߏ߬ߙߌ߲߬ߘߐ߬ ߞߎߘߊ ߘߊߦߟߍ߬</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="209"/>
        <source>&lt;b&gt;Back&lt;/b&gt;&lt;br/&gt;Go back in history</source>
        <translation>&lt;b&gt;ߛߊ߬ߦߌ߲߬&lt;/b&gt;&lt;br/&gt;ߛߊ߬ߦߌ߲߫ ߞߊ߬ߞߘߐ ߘߐ߫</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="299"/>
        <source>&lt;b&gt;Reload&lt;/b&gt;&lt;br/&gt;Reload page</source>
        <translation>&lt;b&gt;ߊ߬ ߢߟߊߕߍ߰&lt;/b&gt;&lt;br/&gt;ߞߐߜߍ ߢߟߊߕߍ߰</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="236"/>
        <source>&lt;b&gt;Close tab&lt;/b&gt;&lt;br/&gt;Close current tab</source>
        <translation>&lt;b&gt;ߛߏ߬ߙߌ߲߬ߘߐ ߕߎ߲߯&lt;/b&gt;&lt;br/&gt;ߛߋ߲߬ߠߊ߬ ߛߏߙߌ߲ߘߐ ߕߎ߲߯</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="90"/>
        <source>Mouse button:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="98"/>
        <source>Middle button</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="103"/>
        <source>Right button</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="108"/>
        <source>Disabled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="116"/>
        <source>Rocker Navigation:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="123"/>
        <source>Enable Rocker Navigation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="147"/>
        <source>Press and hold the mouse button and move your mouse in the indicated directions.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="250"/>
        <source>&lt;b&gt;Forward&lt;/b&gt;&lt;br/&gt;Go forward in history</source>
        <translation>&lt;b&gt;ߟߊ߬ߕߎ߲߬ߠߊ&lt;/b&gt;&lt;br/&gt;ߕߊ߯ ߢߍ߫ ߞߊ߬ߞߘߐ ߘߐ߫</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="257"/>
        <source>&lt;b&gt;Previous tab&lt;/b&gt;&lt;br/&gt;Switch to previous tab</source>
        <translation>&lt;b&gt;ߛߏ߬ߙߌ߲߬ߘߐ ߞߐ߬ߣߍ߲&lt;/b&gt;&lt;br/&gt;ߕߊ߯ ߛߏ߬ߙߌ߲߬ߘߐ ߞߐ߲߬ߣߍ߲ ߘߐ߫</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="271"/>
        <source>&lt;b&gt;Home&lt;/b&gt;&lt;br/&gt;Go to homepage</source>
        <translation>&lt;b&gt;ߓߏ߬ߟߏ߲&lt;/b&gt;&lt;br/&gt;ߕߊ߯ ߓߏ߬ߟߏ߲ ߠߊ߫</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="285"/>
        <source>&lt;b&gt;Next tab&lt;/b&gt;&lt;br/&gt;Switch to next tab</source>
        <translation>&lt;b&gt;ߟߊ߬ߕߎ߲߬ߠߊ߬ ߛߏߙߌ߲ߘߐ&lt;/b&gt;&lt;br/&gt;ߕߊ߯ ߟߊ߬ߕߎ߲߬ߠߊ߬ ߛߏߙߌ߲ߘߐ ߘߐ߫</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="313"/>
        <source>&lt;b&gt;Duplicate&lt;/b&gt;&lt;br/&gt;Duplicate current tab</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="337"/>
        <source>License</source>
        <translation>ߟߊ߬ߘߌߢߍ</translation>
    </message>
</context>
</TS>