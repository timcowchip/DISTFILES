<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr@Ijekavian" version="2.1">
<context>
    <name>MouseGesturesSettingsDialog</name>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="14"/>
        <source>Mouse Gestures</source>
        <translation>Гестови миша</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="42"/>
        <source>&lt;h1&gt;Mouse Gestures&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Гестови миша&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="181"/>
        <source>&lt;b&gt;Stop&lt;/b&gt;&lt;br/&gt;Stop loading page</source>
        <translation>&lt;b&gt;Заустави&lt;/b&gt;&lt;br/&gt;Заустави учитавање странице</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="195"/>
        <source>&lt;b&gt;New tab&lt;/b&gt;&lt;br/&gt;Open new tab</source>
        <translation>&lt;b&gt;Нови језичак&lt;/b&gt;&lt;br/&gt;Отвори нови језичак</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="209"/>
        <source>&lt;b&gt;Back&lt;/b&gt;&lt;br/&gt;Go back in history</source>
        <translation>&lt;b&gt;Назад&lt;/b&gt;&lt;br/&gt;Иди назад у историјату</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="299"/>
        <source>&lt;b&gt;Reload&lt;/b&gt;&lt;br/&gt;Reload page</source>
        <translation>&lt;b&gt;Поново учитај&lt;/b&gt;&lt;br/&gt;Поново учитај страницу</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="236"/>
        <source>&lt;b&gt;Close tab&lt;/b&gt;&lt;br/&gt;Close current tab</source>
        <translation>&lt;b&gt;Затвори језичак&lt;/b&gt;&lt;br/&gt;Затвори текући језичак</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="90"/>
        <source>Mouse button:</source>
        <translation>Дугме миша:</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="98"/>
        <source>Middle button</source>
        <translation>средње</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="103"/>
        <source>Right button</source>
        <translation>десно</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="108"/>
        <source>Disabled</source>
        <translation>онемогућено</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="116"/>
        <source>Rocker Navigation:</source>
        <translation>Брза навигација:</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="123"/>
        <source>Enable Rocker Navigation</source>
        <translation>Навигација историјата користећи десно + лијево дугме</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="147"/>
        <source>Press and hold the mouse button and move your mouse in the indicated directions.</source>
        <translation>Притисните и држите дугме миша и помјерајте миша у наведеним смјеровима.</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="250"/>
        <source>&lt;b&gt;Forward&lt;/b&gt;&lt;br/&gt;Go forward in history</source>
        <translation>&lt;b&gt;Напријед&lt;/b&gt;&lt;br/&gt;Иди напријед у историјату</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="257"/>
        <source>&lt;b&gt;Previous tab&lt;/b&gt;&lt;br/&gt;Switch to previous tab</source>
        <translation>&lt;b&gt;Претходни језичак&lt;/b&gt;&lt;br/&gt;Пребаци на претходни језичак</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="271"/>
        <source>&lt;b&gt;Home&lt;/b&gt;&lt;br/&gt;Go to homepage</source>
        <translation>&lt;b&gt;Домаћа&lt;/b&gt;&lt;br/&gt;Иди на домаћу страницу</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="285"/>
        <source>&lt;b&gt;Next tab&lt;/b&gt;&lt;br/&gt;Switch to next tab</source>
        <translation>&lt;b&gt;Сљедећи језичак&lt;/b&gt;&lt;br/&gt;Пребаци на сљедећи језичак</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="313"/>
        <source>&lt;b&gt;Duplicate&lt;/b&gt;&lt;br/&gt;Duplicate current tab</source>
        <translation>&lt;b&gt;Удвостручи&lt;/b&gt;&lt;br/&gt;Удвостручи текући језичак</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="337"/>
        <source>License</source>
        <translation>Лиценца</translation>
    </message>
</context>
</TS>