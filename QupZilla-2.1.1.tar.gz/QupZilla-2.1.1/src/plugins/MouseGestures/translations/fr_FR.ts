<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr_FR" version="2.1">
<context>
    <name>MouseGesturesSettingsDialog</name>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="14"/>
        <source>Mouse Gestures</source>
        <translation>Mouvements de souris</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="42"/>
        <source>&lt;h1&gt;Mouse Gestures&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Mouvements de souris&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="181"/>
        <source>&lt;b&gt;Stop&lt;/b&gt;&lt;br/&gt;Stop loading page</source>
        <translation>&lt;b&gt;Stop&lt;/b&gt;&lt;br/&gt;Arrêter le chargement de la page</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="195"/>
        <source>&lt;b&gt;New tab&lt;/b&gt;&lt;br/&gt;Open new tab</source>
        <translation>&lt;b&gt;Nouvel onglet&lt;/b&gt;&lt;br/&gt;Ouvrir un nouvel onglet</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="209"/>
        <source>&lt;b&gt;Back&lt;/b&gt;&lt;br/&gt;Go back in history</source>
        <translation>&lt;b&gt;Retour&lt;/b&gt;&lt;br/&gt;Retourner à l&apos;historique</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="299"/>
        <source>&lt;b&gt;Reload&lt;/b&gt;&lt;br/&gt;Reload page</source>
        <translation>&lt;b&gt;Actualiser&lt;/b&gt;&lt;br/&gt;Actualiser la page</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="236"/>
        <source>&lt;b&gt;Close tab&lt;/b&gt;&lt;br/&gt;Close current tab</source>
        <translation>&lt;b&gt;Fermer l&apos;onglet&lt;/b&gt;&lt;br/&gt;Fermer l&apos;onglet actuel</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="90"/>
        <source>Mouse button:</source>
        <translation>Bouton de souris :</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="98"/>
        <source>Middle button</source>
        <translation>Bouton central</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="103"/>
        <source>Right button</source>
        <translation>Bouton droit</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="108"/>
        <source>Disabled</source>
        <translation>Désactivé</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="116"/>
        <source>Rocker Navigation:</source>
        <translation>Navigation à deux boutons :</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="123"/>
        <source>Enable Rocker Navigation</source>
        <translation>Autoriser la navigation à deux boutons</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="147"/>
        <source>Press and hold the mouse button and move your mouse in the indicated directions.</source>
        <translation>Appuyer et maintenir le bouton de souris et la déplacer dans les directions indiquées.</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="250"/>
        <source>&lt;b&gt;Forward&lt;/b&gt;&lt;br/&gt;Go forward in history</source>
        <translation>&lt;b&gt;Précédent&lt;/b&gt;&lt;br/&gt;Remonter dans l&apos;historique</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="257"/>
        <source>&lt;b&gt;Previous tab&lt;/b&gt;&lt;br/&gt;Switch to previous tab</source>
        <translation>&lt;b&gt;Onglet précédent&lt;/b&gt;&lt;br/&gt;Passer à l&apos;onglet précédent</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="271"/>
        <source>&lt;b&gt;Home&lt;/b&gt;&lt;br/&gt;Go to homepage</source>
        <translation>&lt;b&gt;Home&lt;/b&gt;&lt;br/&gt;Retourner à la page d&apos;accueil</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="285"/>
        <source>&lt;b&gt;Next tab&lt;/b&gt;&lt;br/&gt;Switch to next tab</source>
        <translation>&lt;b&gt;Onglet suivant&lt;/b&gt;&lt;br/&gt;Passer à l&apos;onglet suivant</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="313"/>
        <source>&lt;b&gt;Duplicate&lt;/b&gt;&lt;br/&gt;Duplicate current tab</source>
        <translation>&lt;b&gt;Dupliquer&lt;/b&gt;&lt;br/&gt;Dupliquer l&apos;onglet actuel</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="337"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
</context>
</TS>