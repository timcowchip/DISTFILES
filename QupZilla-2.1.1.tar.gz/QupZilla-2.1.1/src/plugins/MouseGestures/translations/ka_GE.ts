<?xml version="1.0" ?><!DOCTYPE TS><TS language="ka_GE" version="2.0">
<context>
    <name>MouseGesturesSettingsDialog</name>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="14"/>
        <source>Mouse Gestures</source>
        <translation>მაუსით ჟესტიკულაცია</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="42"/>
        <source>&lt;h1&gt;Mouse Gestures&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;მაუსით ჟესტიკულაცია&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="64"/>
        <source>Press and hold the middle mouse button and move your mouse in the indicated directions.</source>
        <translation>დააჭირეთ და გეჭიროთ მაუსის შუა ღიკაკი, შემდეგ გადაადგილეთ თქვენი მაუსი მითითებული მიმართულებით.</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="111"/>
        <source>&lt;b&gt;Stop&lt;/b&gt;&lt;br/&gt;Stop loading page</source>
        <translation>&lt;b&gt;გაჩერება&lt;/b&gt;&lt;br/&gt;გვერდის ჩატვირთვის გაჩერება</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="125"/>
        <source>&lt;b&gt;New tab&lt;/b&gt;&lt;br/&gt;Open new tab</source>
        <translation>&lt;b&gt;ახალი ჩანართი&lt;/b&gt;&lt;br/&gt;ახალი ჩანართის გახსნა</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="139"/>
        <source>&lt;b&gt;Back&lt;/b&gt;&lt;br/&gt;Go back in history</source>
        <translation>&lt;b&gt;უკან&lt;/b&gt;&lt;br/&gt;ისტორიაში უკან გადასვლა</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="159"/>
        <source>&lt;b&gt;Reload&lt;/b&gt;&lt;br/&gt;Reload page</source>
        <translation>&lt;b&gt;გადატვირთვა&lt;/b&gt;&lt;br/&gt;გვერდის გადატვირთვა</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="173"/>
        <source>&lt;b&gt;Close tab&lt;/b&gt;&lt;br/&gt;Close current tab</source>
        <translation>&lt;b&gt;ჩანართის დახურვა&lt;/b&gt;&lt;br/&gt;მიმდინარე ჩანართის დახურვა</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="187"/>
        <source>&lt;b&gt;Forward&lt;/b&gt;&lt;br/&gt;Go forward in history</source>
        <translation>&lt;b&gt;წინ&lt;/b&gt;&lt;br/&gt;ისტორიაში წინ გადასვლა</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="194"/>
        <source>&lt;b&gt;Previous tab&lt;/b&gt;&lt;br/&gt;Switch to previous tab</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="208"/>
        <source>&lt;b&gt;Home&lt;/b&gt;&lt;br/&gt;Go to homepage</source>
        <translation>&lt;b&gt;სახლი&lt;/b&gt;&lt;br/&gt;მთავარ გვერდზე გადასვლა</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="222"/>
        <source>&lt;b&gt;Next tab&lt;/b&gt;&lt;br/&gt;Switch to next tab</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="253"/>
        <source>License</source>
        <translation>ლიცენზია</translation>
    </message>
</context>
</TS>