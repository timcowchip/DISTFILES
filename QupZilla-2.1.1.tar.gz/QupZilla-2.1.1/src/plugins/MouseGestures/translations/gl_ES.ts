<?xml version="1.0" ?><!DOCTYPE TS><TS language="gl_ES" version="2.1">
<context>
    <name>MouseGesturesSettingsDialog</name>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="14"/>
        <source>Mouse Gestures</source>
        <translation>Movementos do rato</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="42"/>
        <source>&lt;h1&gt;Mouse Gestures&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Movementos do rato&lt;h1&gt;</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="181"/>
        <source>&lt;b&gt;Stop&lt;/b&gt;&lt;br/&gt;Stop loading page</source>
        <translation>&lt;b&gt;Parar&lt;/b&gt;&lt;br/&gt;Parar de cargar a páxina</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="195"/>
        <source>&lt;b&gt;New tab&lt;/b&gt;&lt;br/&gt;Open new tab</source>
        <translation>&lt;b&gt;Nova lapela&lt;/b&gt;&lt;br/&gt;Abrir a nova lapela</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="209"/>
        <source>&lt;b&gt;Back&lt;/b&gt;&lt;br/&gt;Go back in history</source>
        <translation>&lt;b&gt;Atrás&lt;/b&gt;&lt;br/&gt;Ir a atrás no historial</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="299"/>
        <source>&lt;b&gt;Reload&lt;/b&gt;&lt;br/&gt;Reload page</source>
        <translation>&lt;b&gt;Recargar&lt;/b&gt;&lt;br/&gt;Volver a cargar a páxina</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="236"/>
        <source>&lt;b&gt;Close tab&lt;/b&gt;&lt;br/&gt;Close current tab</source>
        <translation>&lt;b&gt;Pechar a lapela&lt;/b&gt;&lt;br/&gt;Pechar a lapela actual</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="90"/>
        <source>Mouse button:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="98"/>
        <source>Middle button</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="103"/>
        <source>Right button</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="108"/>
        <source>Disabled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="116"/>
        <source>Rocker Navigation:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="123"/>
        <source>Enable Rocker Navigation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="147"/>
        <source>Press and hold the mouse button and move your mouse in the indicated directions.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="250"/>
        <source>&lt;b&gt;Forward&lt;/b&gt;&lt;br/&gt;Go forward in history</source>
        <translation>&lt;b&gt;Adiante&lt;/b&gt;&lt;br/&gt;Ir a adiante no historial</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="257"/>
        <source>&lt;b&gt;Previous tab&lt;/b&gt;&lt;br/&gt;Switch to previous tab</source>
        <translation>&lt;b&gt;Lapela anterior&lt;/b&gt;&lt;br/&gt;Ir a lapela anterior</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="271"/>
        <source>&lt;b&gt;Home&lt;/b&gt;&lt;br/&gt;Go to homepage</source>
        <translation>&lt;b&gt;Inicio&lt;/b&gt;&lt;br/&gt;Ir á páxina de inicio</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="285"/>
        <source>&lt;b&gt;Next tab&lt;/b&gt;&lt;br/&gt;Switch to next tab</source>
        <translation>&lt;b&gt;Seguinte lapela&lt;/b&gt;&lt;br/&gt;Ir á seguinte lapela</translation>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="313"/>
        <source>&lt;b&gt;Duplicate&lt;/b&gt;&lt;br/&gt;Duplicate current tab</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mousegesturessettingsdialog.ui" line="337"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
</context>
</TS>