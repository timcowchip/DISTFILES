<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.1">
<context>
    <name>KWalletPlugin</name>
    <message>
        <location filename="../kwalletpasswordbackend.cpp" line="53"/>
        <source>KWallet</source>
        <translation>KWallet</translation>
    </message>
</context>
</TS>