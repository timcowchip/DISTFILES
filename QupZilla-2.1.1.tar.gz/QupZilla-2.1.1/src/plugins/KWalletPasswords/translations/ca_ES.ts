<?xml version="1.0" ?><!DOCTYPE TS><TS language="ca_ES" version="2.1">
<context>
    <name>KWalletPlugin</name>
    <message>
        <location filename="../kwalletpasswordbackend.cpp" line="53"/>
        <source>KWallet</source>
        <translation>KWallet</translation>
    </message>
</context>
</TS>