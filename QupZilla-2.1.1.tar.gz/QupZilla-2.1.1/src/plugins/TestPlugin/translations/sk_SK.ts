<?xml version="1.0" ?><!DOCTYPE TS><TS language="sk_SK" version="2.1">
<context>
    <name>TestPlugin</name>
    <message>
        <location filename="../testplugin.cpp" line="122"/>
        <source>Close</source>
        <translation>Zavrieť</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="133"/>
        <source>Example Plugin Settings</source>
        <translation>Nastavenie ukážkového doplnku</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="163"/>
        <source>My first plugin action</source>
        <translation>Moje první akce z doplnku</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="178"/>
        <source>Hello</source>
        <translation>Ahoj</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="178"/>
        <source>First plugin action works :-)</source>
        <translation>První doplnek funguje :-)</translation>
    </message>
</context>
<context>
    <name>TestPlugin_Sidebar</name>
    <message>
        <location filename="../testplugin_sidebar.cpp" line="32"/>
        <location filename="../testplugin_sidebar.cpp" line="40"/>
        <source>Testing Sidebar</source>
        <translation>Testovací bočný panel</translation>
    </message>
</context>
</TS>