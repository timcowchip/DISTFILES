<?xml version="1.0" ?><!DOCTYPE TS><TS language="te" version="2.1">
<context>
    <name>TestPlugin</name>
    <message>
        <location filename="../testplugin.cpp" line="122"/>
        <source>Close</source>
        <translation>మూసివేయి</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="133"/>
        <source>Example Plugin Settings</source>
        <translation>ఉదాహరణ ప్లగిన్ సెటింగ్స్</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="163"/>
        <source>My first plugin action</source>
        <translation>నా మొదటి ప్లగిన్ పని</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="178"/>
        <source>Hello</source>
        <translation>నమస్తే</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="178"/>
        <source>First plugin action works :-)</source>
        <translation>నా మొదటి ప్లగిన్ పని పనిచేస్తుంది :-)</translation>
    </message>
</context>
<context>
    <name>TestPlugin_Sidebar</name>
    <message>
        <location filename="../testplugin_sidebar.cpp" line="32"/>
        <location filename="../testplugin_sidebar.cpp" line="40"/>
        <source>Testing Sidebar</source>
        <translation>సైడ్ బార్ను పరీక్షిస్తున్నా</translation>
    </message>
</context>
</TS>