<?xml version="1.0" ?><!DOCTYPE TS><TS language="ja_JP" version="2.1">
<context>
    <name>TestPlugin</name>
    <message>
        <location filename="../testplugin.cpp" line="122"/>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="133"/>
        <source>Example Plugin Settings</source>
        <translation>拡張の設定例</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="163"/>
        <source>My first plugin action</source>
        <translation>拡張の動作確認</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="178"/>
        <source>Hello</source>
        <translation>Hello</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="178"/>
        <source>First plugin action works :-)</source>
        <translation>拡張の動作は正常です :-)</translation>
    </message>
</context>
<context>
    <name>TestPlugin_Sidebar</name>
    <message>
        <location filename="../testplugin_sidebar.cpp" line="32"/>
        <location filename="../testplugin_sidebar.cpp" line="40"/>
        <source>Testing Sidebar</source>
        <translation>サイドバーを試す</translation>
    </message>
</context>
</TS>