<?xml version="1.0" ?><!DOCTYPE TS><TS language="nqo" version="2.1">
<context>
    <name>TestPlugin</name>
    <message>
        <location filename="../testplugin.cpp" line="122"/>
        <source>Close</source>
        <translation>ߊ߬ ߕߎ߲߯</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="133"/>
        <source>Example Plugin Settings</source>
        <translation>ߛߐߙߐ߲ߕߊ ߞߐߕߐ߯ߘߐߛߙߋ ߟߎ߫ ߡߌ߬ߛߊ߬ߟߌ</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="163"/>
        <source>My first plugin action</source>
        <translation>ߒ ߠߊ߫ ߛߐߙߐ߲ߕߊ ߟߊ߫ ߞߍߟߌ ߝߟߐ</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="178"/>
        <source>Hello</source>
        <translation>ߌ ߣߌ߫ ߕߎ߬ߡߊ߬</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="178"/>
        <source>First plugin action works :-)</source>
        <translation>ߛߐߙߐ߲ߕߊ ߟߊ߫ ߞߍߟߌ ߝߟߐ߫ ߦߋ߫ ߓߊ߯ߙߊ߫ ߟߊ߫ :-)</translation>
    </message>
</context>
<context>
    <name>TestPlugin_Sidebar</name>
    <message>
        <location filename="../testplugin_sidebar.cpp" line="32"/>
        <location filename="../testplugin_sidebar.cpp" line="40"/>
        <source>Testing Sidebar</source>
        <translation>ߞߙߍ߬ߝߍ߬ ߡߙߎߝߋ ߞߘߐߓߐߟߌ</translation>
    </message>
</context>
</TS>