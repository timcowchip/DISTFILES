<?xml version="1.0" ?><!DOCTYPE TS><TS language="es_MX" version="2.1">
<context>
    <name>TestPlugin</name>
    <message>
        <location filename="../testplugin.cpp" line="122"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="133"/>
        <source>Example Plugin Settings</source>
        <translation>Ejemplo de configuracion de complemento</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="163"/>
        <source>My first plugin action</source>
        <translation>Acción de mi primer complemento</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="178"/>
        <source>Hello</source>
        <translation>Hola</translation>
    </message>
    <message>
        <location filename="../testplugin.cpp" line="178"/>
        <source>First plugin action works :-)</source>
        <translation>La acción del primer complemento funciona :-)</translation>
    </message>
</context>
<context>
    <name>TestPlugin_Sidebar</name>
    <message>
        <location filename="../testplugin_sidebar.cpp" line="32"/>
        <location filename="../testplugin_sidebar.cpp" line="40"/>
        <source>Testing Sidebar</source>
        <translation>Barra lateral de pruebas</translation>
    </message>
</context>
</TS>