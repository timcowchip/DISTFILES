<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_HK" version="2.1">
<context>
    <name>GnomeKeyringPlugin</name>
    <message>
        <location filename="../gnomekeyringpasswordbackend.cpp" line="84"/>
        <source>Gnome Keyring</source>
        <translation>Gnome匙圈</translation>
    </message>
</context>
</TS>