<?xml version="1.0" ?><!DOCTYPE TS><TS language="da_DK" version="2.1">
<context>
    <name>GnomeKeyringPlugin</name>
    <message>
        <location filename="../gnomekeyringpasswordbackend.cpp" line="84"/>
        <source>Gnome Keyring</source>
        <translation>Gnome Nøglering</translation>
    </message>
</context>
</TS>