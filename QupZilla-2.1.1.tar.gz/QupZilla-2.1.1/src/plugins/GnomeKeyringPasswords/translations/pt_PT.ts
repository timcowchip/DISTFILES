<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_PT" version="2.1">
<context>
    <name>GnomeKeyringPlugin</name>
    <message>
        <location filename="../gnomekeyringpasswordbackend.cpp" line="84"/>
        <source>Gnome Keyring</source>
        <translation>Chaveiro Gnome</translation>
    </message>
</context>
</TS>