<?xml version="1.0" ?><!DOCTYPE TS><TS language="hr_HR" version="2.1">
<context>
    <name>GnomeKeyringPlugin</name>
    <message>
        <location filename="../gnomekeyringpasswordbackend.cpp" line="84"/>
        <source>Gnome Keyring</source>
        <translation>Gnome keyring</translation>
    </message>
</context>
</TS>