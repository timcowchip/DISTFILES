<?xml version="1.0" ?><!DOCTYPE TS><TS language="he_IL" version="2.1">
<context>
    <name>GnomeKeyringPlugin</name>
    <message>
        <location filename="../gnomekeyringpasswordbackend.cpp" line="84"/>
        <source>Gnome Keyring</source>
        <translation>מחזיק מפתחות Gnome</translation>
    </message>
</context>
</TS>