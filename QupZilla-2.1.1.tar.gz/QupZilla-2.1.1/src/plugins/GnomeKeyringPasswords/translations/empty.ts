<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>GnomeKeyringPlugin</name>
    <message>
        <location filename="../gnomekeyringpasswordbackend.cpp" line="84"/>
        <source>Gnome Keyring</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
