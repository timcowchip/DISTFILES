<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ImageFinderPlugin</name>
    <message>
        <location filename="../imagefinderplugin.cpp" line="92"/>
        <source>Search image in </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../imagefinderplugin.cpp" line="99"/>
        <source>Search image with...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageFinderSettings</name>
    <message>
        <location filename="../imagefindersettings.ui" line="14"/>
        <source>ImageFinder Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../imagefindersettings.ui" line="75"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:xx-large; font-weight:600;&quot;&gt;ImageFinder&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../imagefindersettings.ui" line="112"/>
        <source>&lt;h3&gt;Search engine&lt;/h3&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../imagefindersettings.ui" line="132"/>
        <source>Google</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../imagefindersettings.ui" line="141"/>
        <source>Yandex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../imagefindersettings.ui" line="150"/>
        <source>TinEye</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
