<?xml version="1.0" ?><!DOCTYPE TS><TS language="is" version="2.1">
<context>
    <name>GM_AddScriptDialog</name>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="14"/>
        <source>GreaseMonkey Installation</source>
        <translation>GreaseMonkey uppsetning</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="51"/>
        <source>&lt;h3&gt;GreaseMonkey Installation&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;GreaseMonkey uppsetning&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="73"/>
        <source>You are about to install this userscript into GreaseMonkey:</source>
        <translation>Þú ert að fara að setja þessa notandaskriftu upp í GreaseMonkey:</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="86"/>
        <source>&lt;b&gt;You should only install scripts from sources you trust!&lt;/b&gt;</source>
        <translation>&lt;b&gt;Ekki setja upp skriftur nema þú treystir uppruna þeirra&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="96"/>
        <source>Are you sure you want to install it?</source>
        <translation>Ertu viss að þú viljir setja hana inn?</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="114"/>
        <source>Show source code of script</source>
        <translation>Birta frumkóða skriftu</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="49"/>
        <source>&lt;p&gt;runs at&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;keyrir&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="53"/>
        <source>&lt;p&gt;does not run at&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;keyrir ekki&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="83"/>
        <source>Cannot install script</source>
        <translation>Get ekki sett inn skriftu</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="86"/>
        <source>&apos;%1&apos; installed successfully</source>
        <translation>Uppsetningu &apos;%1&apos; er lokið</translation>
    </message>
</context>
<context>
    <name>GM_Icon</name>
    <message>
        <location filename="../gm_icon.cpp" line="29"/>
        <source>Open GreaseMonkey settings</source>
        <translation>Opna stillingar GreaseMonkey</translation>
    </message>
</context>
<context>
    <name>GM_Manager</name>
    <message>
        <location filename="../gm_manager.cpp" line="206"/>
        <source>GreaseMonkey</source>
        <translation>GreaseMonkey</translation>
    </message>
    <message>
        <location filename="../gm_manager.cpp" line="270"/>
        <source>&apos;%1&apos; is already installed</source>
        <translation>&apos;%1&apos; er þegar uppsett</translation>
    </message>
</context>
<context>
    <name>GM_Notification</name>
    <message>
        <location filename="../gm_notification.ui" line="45"/>
        <source>This script can be installed with the GreaseMonkey plugin.</source>
        <translation>Þessa skriftu er hægt að setja upp með GreaseMonkey-viðbótinni.</translation>
    </message>
    <message>
        <location filename="../gm_notification.ui" line="65"/>
        <source>Install</source>
        <translation>Setja upp</translation>
    </message>
    <message>
        <location filename="../gm_notification.cpp" line="50"/>
        <source>Cannot install script</source>
        <translation>Get ekki sett inn skriftu</translation>
    </message>
    <message>
        <location filename="../gm_notification.cpp" line="58"/>
        <source>&apos;%1&apos; installed successfully</source>
        <translation>Uppsetningu &apos;%1&apos; er lokið</translation>
    </message>
</context>
<context>
    <name>GM_Settings</name>
    <message>
        <location filename="../settings/gm_settings.ui" line="14"/>
        <source>GreaseMonkey Scripts</source>
        <translation>GreaseMonkey skriftur</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="51"/>
        <source>&lt;h3&gt;GreaseMonkey Scripts&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;GreaseMonkey skriftur&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="73"/>
        <source>Double clicking script will show additional information</source>
        <translation>Tvísmellur á skriftu mun birta viðbótarupplýsingar</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="153"/>
        <source>More scripts can be downloaded from</source>
        <translation>Fleiri skriftur má sækja á</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="196"/>
        <source>Open scripts directory</source>
        <translation>Opna skriftumöppu</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="203"/>
        <source>New user script</source>
        <translation>Ný skrifta notanda</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="90"/>
        <source>Remove script</source>
        <translation>Fjarlægja skriftu</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="91"/>
        <source>Are you sure you want to remove &apos;%1&apos;?</source>
        <translation>Ertu viss um að þú viljir fjarlægja &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="121"/>
        <source>Add script</source>
        <translation>Bæta við skriftu</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="121"/>
        <source>Choose name for script:</source>
        <translation>Veldu nafn á skriftu:</translation>
    </message>
</context>
<context>
    <name>GM_SettingsScriptInfo</name>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="85"/>
        <source>Name:</source>
        <translation>Heiti:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="55"/>
        <source>Version:</source>
        <translation>Útgáfa:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="115"/>
        <source>URL:</source>
        <translation>Slóð:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="138"/>
        <source>Namespace:</source>
        <translation>Nafnrými:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="155"/>
        <source>Edit in text editor</source>
        <translation>Breyta með textaritli</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="65"/>
        <source>Start at:</source>
        <translation>Byrja í:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="45"/>
        <source>Description:</source>
        <translation>Lýsing:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="19"/>
        <source>Runs at:</source>
        <translation>Keyrir:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="128"/>
        <source>Does not run at:</source>
        <translation>Keyrir ekki:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.cpp" line="45"/>
        <source>Script Details of %1</source>
        <translation>Nánar um skriftuna %1</translation>
    </message>
</context>
</TS>