<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr@latin" version="2.1">
<context>
    <name>GM_AddScriptDialog</name>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="14"/>
        <source>GreaseMonkey Installation</source>
        <translation>Instalacija GreaseMonkey skripte</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="51"/>
        <source>&lt;h3&gt;GreaseMonkey Installation&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;Instalacija GreaseMonkey skripte&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="73"/>
        <source>You are about to install this userscript into GreaseMonkey:</source>
        <translation>Instaliraćete ovu skriptu u GreaseMonkey:</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="86"/>
        <source>&lt;b&gt;You should only install scripts from sources you trust!&lt;/b&gt;</source>
        <translation>&lt;b&gt;Instalirajte samo skripte od izvora kojima verujete!&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="96"/>
        <source>Are you sure you want to install it?</source>
        <translation>Želite li zaista da je instalirate?</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="114"/>
        <source>Show source code of script</source>
        <translation>Prikaži izvorni kôd skripte</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="49"/>
        <source>&lt;p&gt;runs at&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;pokreće se na&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="53"/>
        <source>&lt;p&gt;does not run at&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;ne pokreće se na&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="83"/>
        <source>Cannot install script</source>
        <translation>Ne mogu da instaliram skriptu</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="86"/>
        <source>&apos;%1&apos; installed successfully</source>
        <translation>„%1“ je uspešno instalirana</translation>
    </message>
</context>
<context>
    <name>GM_Icon</name>
    <message>
        <location filename="../gm_icon.cpp" line="29"/>
        <source>Open GreaseMonkey settings</source>
        <translation>GreaseMonkey postavke</translation>
    </message>
</context>
<context>
    <name>GM_Manager</name>
    <message>
        <location filename="../gm_manager.cpp" line="206"/>
        <source>GreaseMonkey</source>
        <translation>GreaseMonkey</translation>
    </message>
    <message>
        <location filename="../gm_manager.cpp" line="270"/>
        <source>&apos;%1&apos; is already installed</source>
        <translation>„%1“ je već instalirana</translation>
    </message>
</context>
<context>
    <name>GM_Notification</name>
    <message>
        <location filename="../gm_notification.ui" line="45"/>
        <source>This script can be installed with the GreaseMonkey plugin.</source>
        <translation>Ova skripta može biti instalirana pomoću GreaseMonkey priključka.</translation>
    </message>
    <message>
        <location filename="../gm_notification.ui" line="65"/>
        <source>Install</source>
        <translation>Instaliraj</translation>
    </message>
    <message>
        <location filename="../gm_notification.cpp" line="50"/>
        <source>Cannot install script</source>
        <translation>Ne mogu da instaliram skriptu</translation>
    </message>
    <message>
        <location filename="../gm_notification.cpp" line="58"/>
        <source>&apos;%1&apos; installed successfully</source>
        <translation>„%1“ je uspešno instalirana</translation>
    </message>
</context>
<context>
    <name>GM_Settings</name>
    <message>
        <location filename="../settings/gm_settings.ui" line="14"/>
        <source>GreaseMonkey Scripts</source>
        <translation>GreaseMonkey skripte</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="51"/>
        <source>&lt;h3&gt;GreaseMonkey Scripts&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;GreaseMonkey skripte&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="73"/>
        <source>Double clicking script will show additional information</source>
        <translation>Dvoklikom ćete prikazati dodatne podatke</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="153"/>
        <source>More scripts can be downloaded from</source>
        <translation>Skripte možete preuzeti sa</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="196"/>
        <source>Open scripts directory</source>
        <translation>Otvori fasciklu skripti</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="203"/>
        <source>New user script</source>
        <translation>Nova skripta</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="90"/>
        <source>Remove script</source>
        <translation>Ukloni skriptu</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="91"/>
        <source>Are you sure you want to remove &apos;%1&apos;?</source>
        <translation>Želite li zaista da uklonite „%1“?</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="121"/>
        <source>Add script</source>
        <translation>Dodavanje skripte</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="121"/>
        <source>Choose name for script:</source>
        <translation>Ime za skriptu:</translation>
    </message>
</context>
<context>
    <name>GM_SettingsScriptInfo</name>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="85"/>
        <source>Name:</source>
        <translation>Ime:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="55"/>
        <source>Version:</source>
        <translation>Izdanje:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="115"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="138"/>
        <source>Namespace:</source>
        <translation>Imenski prostor:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="155"/>
        <source>Edit in text editor</source>
        <translation>Uredi skriptu</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="65"/>
        <source>Start at:</source>
        <translation>Pokreće se pri:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="45"/>
        <source>Description:</source>
        <translation>Opis:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="19"/>
        <source>Runs at:</source>
        <translation>Pokreće se na:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="128"/>
        <source>Does not run at:</source>
        <translation>Ne pokreće se na:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.cpp" line="45"/>
        <source>Script Details of %1</source>
        <translation>Detalji skripte %1</translation>
    </message>
</context>
</TS>