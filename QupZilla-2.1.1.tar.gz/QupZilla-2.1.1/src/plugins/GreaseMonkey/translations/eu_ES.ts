<?xml version="1.0" ?><!DOCTYPE TS><TS language="eu_ES" version="2.1">
<context>
    <name>GM_AddScriptDialog</name>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="14"/>
        <source>GreaseMonkey Installation</source>
        <translation>GreaseMonkey Ezarpena</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="51"/>
        <source>&lt;h3&gt;GreaseMonkey Installation&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;GreaseMonkey Ezarpena&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="73"/>
        <source>You are about to install this userscript into GreaseMonkey:</source>
        <translation>Erabiltzaile-eskript hau GreaseMonkeyn ezartzear zaude:</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="86"/>
        <source>&lt;b&gt;You should only install scripts from sources you trust!&lt;/b&gt;</source>
        <translation>&lt;b&gt;Iturburu fidagarrietako eskriptak bakarrik ezarri behar dituzu!&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="96"/>
        <source>Are you sure you want to install it?</source>
        <translation>Zihur zaude ezartzea nahi duzula?</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="114"/>
        <source>Show source code of script</source>
        <translation>Erakutsi eskriptaren iturburu kodea</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="49"/>
        <source>&lt;p&gt;runs at&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;ekiten du&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="53"/>
        <source>&lt;p&gt;does not run at&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;ez du ekiten&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="83"/>
        <source>Cannot install script</source>
        <translation>Ezinezkoa eskripta ezartzea</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="86"/>
        <source>&apos;%1&apos; installed successfully</source>
        <translation>&apos;%1&apos; ongi ezarri da</translation>
    </message>
</context>
<context>
    <name>GM_Icon</name>
    <message>
        <location filename="../gm_icon.cpp" line="29"/>
        <source>Open GreaseMonkey settings</source>
        <translation>Ireki GreaseMonkey ezarpenak</translation>
    </message>
</context>
<context>
    <name>GM_Manager</name>
    <message>
        <location filename="../gm_manager.cpp" line="206"/>
        <source>GreaseMonkey</source>
        <translation>GreaseMonkey</translation>
    </message>
    <message>
        <location filename="../gm_manager.cpp" line="270"/>
        <source>&apos;%1&apos; is already installed</source>
        <translation>&apos;%1&apos; jadanik ezarrita dago</translation>
    </message>
</context>
<context>
    <name>GM_Notification</name>
    <message>
        <location filename="../gm_notification.ui" line="45"/>
        <source>This script can be installed with the GreaseMonkey plugin.</source>
        <translation>Eskript hau GreaseMonkey pluginarekin ezarri daiteke.</translation>
    </message>
    <message>
        <location filename="../gm_notification.ui" line="65"/>
        <source>Install</source>
        <translation>Ezarri</translation>
    </message>
    <message>
        <location filename="../gm_notification.cpp" line="50"/>
        <source>Cannot install script</source>
        <translation>Ezinezkoa eskripta ezartzea</translation>
    </message>
    <message>
        <location filename="../gm_notification.cpp" line="58"/>
        <source>&apos;%1&apos; installed successfully</source>
        <translation>&apos;%1&apos; ongi ezarri da</translation>
    </message>
</context>
<context>
    <name>GM_Settings</name>
    <message>
        <location filename="../settings/gm_settings.ui" line="14"/>
        <source>GreaseMonkey Scripts</source>
        <translation>GreaseMonkey Eskriptak</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="51"/>
        <source>&lt;h3&gt;GreaseMonkey Scripts&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;GreaseMonkey Eskriptak&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="73"/>
        <source>Double clicking script will show additional information</source>
        <translation>Klik bikoitzak eskriptean argibide gehigarriak erakutsiko ditu</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="153"/>
        <source>More scripts can be downloaded from</source>
        <translation>Eskript gehiago jeitsi daitezke hemendik</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="196"/>
        <source>Open scripts directory</source>
        <translation>Ireki eskripten zuzenbidea</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="203"/>
        <source>New user script</source>
        <translation>Erabiltzaile berri eskripta</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="90"/>
        <source>Remove script</source>
        <translation>Kendu eskripta</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="91"/>
        <source>Are you sure you want to remove &apos;%1&apos;?</source>
        <translation>Zihur zaude &apos;%1&apos; kentzea nahi duzula?</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="121"/>
        <source>Add script</source>
        <translation>Gehitu eskripta</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="121"/>
        <source>Choose name for script:</source>
        <translation>Hautatu eskriptarentzako izena: </translation>
    </message>
</context>
<context>
    <name>GM_SettingsScriptInfo</name>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="85"/>
        <source>Name:</source>
        <translation>Izena:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="55"/>
        <source>Version:</source>
        <translation>Bertsioa:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="115"/>
        <source>URL:</source>
        <translation>URL-a:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="138"/>
        <source>Namespace:</source>
        <translation>Izentartea:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="155"/>
        <source>Edit in text editor</source>
        <translation>Editatu idazki editatzailean</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="65"/>
        <source>Start at:</source>
        <translation>Hasiera:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="45"/>
        <source>Description:</source>
        <translation>Azalpena:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="19"/>
        <source>Runs at:</source>
        <translation>Ekiten du:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="128"/>
        <source>Does not run at:</source>
        <translation>Ez du ekiten:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.cpp" line="45"/>
        <source>Script Details of %1</source>
        <translation>%1-ren Eskript Xehetasunak</translation>
    </message>
</context>
</TS>