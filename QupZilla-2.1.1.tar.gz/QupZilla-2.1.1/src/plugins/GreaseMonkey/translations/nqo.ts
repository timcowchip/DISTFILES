<?xml version="1.0" ?><!DOCTYPE TS><TS language="nqo" version="2.1">
<context>
    <name>GM_AddScriptDialog</name>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="14"/>
        <source>GreaseMonkey Installation</source>
        <translation>ߛߎ߬ߟߊ߬ߕߟߎ ߡߊߞߍߟߌ</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="51"/>
        <source>&lt;h3&gt;GreaseMonkey Installation&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;ߛߎ߬ߟߊ߬ߕߟߎ ߡߊߞߍߟߌ&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="73"/>
        <source>You are about to install this userscript into GreaseMonkey:</source>
        <translation>ߌ ߦߋ߫ ߕߣߐ߬ߓߐ߬ߣߐߣߐߟߊ ߣߌ߲߬ ߠߋ߫ ߡߊߞߍ߫ ߞߊ߲߬ ߛߎ߬ߟߊ߬ߕߟߎ ߣߌ߲߬ ߞߊ߲߬ ߕߋ߲߬:</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="86"/>
        <source>&lt;b&gt;You should only install scripts from sources you trust!&lt;/b&gt;</source>
        <translation>&lt;b&gt;ߌ ߞߊ߫ ߣߐ߬ߣߐ߬ߟߊ߬ ߛߌ߫ ߡߊߞߍ߫ ߝߏ߫ ߌ ߜߍߣߍ߲߫ ߡߍ߲ ߠߎ߬ ߓߐ߫ ߦߙߐ ߡߊ߬&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="96"/>
        <source>Are you sure you want to install it?</source>
        <translation>ߌ ߦߴߊ߬ ߝߍ߬ ߞߵߊ߬ ߡߊߞߍ߫ ߟߋ߬ ߢߍ؟</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="114"/>
        <source>Show source code of script</source>
        <translation>ߊ߬ ߘߏߞߊ߲߫ ߓߊߛߎ߲ ߦߌ߬ߘߊ߬</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="49"/>
        <source>&lt;p&gt;runs at&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</source>
        <translation>&lt;i&gt;%1&lt;/i&gt;&lt;p&gt;ߟߊߥߟߌ߬&lt;br/&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="53"/>
        <source>&lt;p&gt;does not run at&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</source>
        <translation>&lt;i&gt;%1&lt;/i&gt;&lt;p&gt;ߞߊ߫ ߟߊߥߟߌ߬&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="83"/>
        <source>Cannot install script</source>
        <translation>ߣߐ߬ߣߐ߬ߟߊ ߕߍ߫ ߛߋ߫ ߡߊߞߍ߫ ߟߊ߫</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="86"/>
        <source>&apos;%1&apos; installed successfully</source>
        <translation>&apos;%1&apos; ߓߘߊ߫ ߡߊߞߍ߫ ߞߏ߫ ߢߊ߬</translation>
    </message>
</context>
<context>
    <name>GM_Icon</name>
    <message>
        <location filename="../gm_icon.cpp" line="29"/>
        <source>Open GreaseMonkey settings</source>
        <translation>ߛߎ߬ߟߊ߬ߕߟߎ ߞߐߕߐ߯ߘߐߛߙߋ ߟߎ߬ ߘߊߦߟߍ߬</translation>
    </message>
</context>
<context>
    <name>GM_Manager</name>
    <message>
        <location filename="../gm_manager.cpp" line="206"/>
        <source>GreaseMonkey</source>
        <translation>ߛߎ߬ߟߊ߬ߕߟߎ</translation>
    </message>
    <message>
        <location filename="../gm_manager.cpp" line="270"/>
        <source>&apos;%1&apos; is already installed</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>GM_Notification</name>
    <message>
        <location filename="../gm_notification.ui" line="45"/>
        <source>This script can be installed with the GreaseMonkey plugin.</source>
        <translation>ߣߐ߬ߣߐ߬ߟߊ ߣߌ߲߬ ߘߌ߫ ߛߋ߫ ߡߊߞߍ߫ ߟߊ߫ ߛߎ߬ߟߊ߬ߕߟߎ ߛߐߙߐ߲ߕߊ ߝߍ߬.</translation>
    </message>
    <message>
        <location filename="../gm_notification.ui" line="65"/>
        <source>Install</source>
        <translation>ߊ߬ ߡߊߞߍ߫</translation>
    </message>
    <message>
        <location filename="../gm_notification.cpp" line="50"/>
        <source>Cannot install script</source>
        <translation>ߣߐ߬ߣߐ߬ߟߊ ߕߍ߫ ߛߋ߫ ߡߊߞߍ߫ ߟߊ߫</translation>
    </message>
    <message>
        <location filename="../gm_notification.cpp" line="58"/>
        <source>&apos;%1&apos; installed successfully</source>
        <translation>&apos;%1&apos; ߡߊߞߍߣߍ߲߫ ߞߏ߫ ߢߊ߬</translation>
    </message>
</context>
<context>
    <name>GM_Settings</name>
    <message>
        <location filename="../settings/gm_settings.ui" line="14"/>
        <source>GreaseMonkey Scripts</source>
        <translation>ߛߎ߬ߟߊ߬ߕߟߎ ߣߐ߬ߣߐ߬ߟߊ ߟߎ߬</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="51"/>
        <source>&lt;h3&gt;GreaseMonkey Scripts&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;ߛߎ߬ߟߊ߬ߕߟߎ ߣߐ߬ߣߐ߬ߟߊ ߟߎ߬&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="73"/>
        <source>Double clicking script will show additional information</source>
        <translation>ߛߐ߲߬ߞߌ߬ ߝߌ߬ߟߊ߬ߣߍ߲ ߞߍ߫ ߣߐ߬ߣߐ߬ߟߊ ߞߊ߲߬ ߞߊ߬ ߞߌ߬ߓߊ߬ߙߏ ߕߐ߭ ߟߎ߬ ߟߊߟߐ߲߫</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="153"/>
        <source>More scripts can be downloaded from</source>
        <translation>ߣߐ߬ߣߐ߬ߟߊ߬ ߜߘߍ߫ ߟߎ߫ ߘߌ߫ ߛߋ߫ ߟߊߖߌ߰ ߟߊ߫ ߞߊ߬ ߝߙߊ߫</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="196"/>
        <source>Open scripts directory</source>
        <translation>ߘߋ߬ߌ߬ߘߊ ߘߊߦߟߍ߬</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="203"/>
        <source>New user script</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="90"/>
        <source>Remove script</source>
        <translation>ߣߐ߬ߣߐ߬ߟߊ ߖߐ߬ߛߌ߬</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="91"/>
        <source>Are you sure you want to remove &apos;%1&apos;?</source>
        <translation>ߌ ߦߴߊ߬ ߝߍ߬ ߞߊ߬ &apos;%1&apos; ߖߐ߬ߛߌ߫ ߟߋ߬ ߝߋߎ߫؟</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="121"/>
        <source>Add script</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="121"/>
        <source>Choose name for script:</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>GM_SettingsScriptInfo</name>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="85"/>
        <source>Name:</source>
        <translation>ߕߐ߮:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="55"/>
        <source>Version:</source>
        <translation>ߓߐߞߏ:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="115"/>
        <source>URL:</source>
        <translation>ߛߘߌ߬ߜߋ߲:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="138"/>
        <source>Namespace:</source>
        <translation>ߕߐ߮ ߞߣߍ:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="155"/>
        <source>Edit in text editor</source>
        <translation>ߊ߬ ߡߊߦߟߍ߬ߡߊ߲߬ ߞߟߏߜߍ߫ ߡߊߦߟߍߡߊ߲ߠߊ ߘߐ߫</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="65"/>
        <source>Start at:</source>
        <translation>ߊ߬ ߟߊߥߟߌ߬:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="45"/>
        <source>Description:</source>
        <translation>ߡߊ߲߬ߞߕߎ߬ߟߌ:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="19"/>
        <source>Runs at:</source>
        <translation>ߊ߬ ߟߥߊߟߌ߫:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="128"/>
        <source>Does not run at:</source>
        <translation>ߊ߬ ߞߊ߫ ߟߥߊߟߌ߫:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.cpp" line="45"/>
        <source>Script Details of %1</source>
        <translation>%1 ߟߊ߫ ߣߐ߬ߣߐ߬ߟߌ߬ ߕߐߝߍߦߊ ߟߎ߬</translation>
    </message>
</context>
</TS>