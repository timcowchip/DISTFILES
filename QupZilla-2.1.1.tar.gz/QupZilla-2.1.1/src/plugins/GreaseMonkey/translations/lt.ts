<?xml version="1.0" ?><!DOCTYPE TS><TS language="lt" version="2.1">
<context>
    <name>GM_AddScriptDialog</name>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="14"/>
        <source>GreaseMonkey Installation</source>
        <translation>GreaseMonkey diegimas</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="51"/>
        <source>&lt;h3&gt;GreaseMonkey Installation&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;GreaseMonkey diegimas&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="73"/>
        <source>You are about to install this userscript into GreaseMonkey:</source>
        <translation>Jūs ruošiatės įdiegti šį naudotojo scenarijų į GreaseMonkey:</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="86"/>
        <source>&lt;b&gt;You should only install scripts from sources you trust!&lt;/b&gt;</source>
        <translation>&lt;b&gt;Jūs turėtumėte diegti scenarijus tik iš šaltinių, kuriais pasitikite!&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="96"/>
        <source>Are you sure you want to install it?</source>
        <translation>Ar tikrai norite jį įdiegti?</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.ui" line="114"/>
        <source>Show source code of script</source>
        <translation>Rodyti scenarijaus pirminį kodą</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="49"/>
        <source>&lt;p&gt;runs at&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;paleidžiamas puslapiuose&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="53"/>
        <source>&lt;p&gt;does not run at&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;nepaleidžiamas puslapiuose&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="83"/>
        <source>Cannot install script</source>
        <translation>Nepavyko įdiegti scenarijaus</translation>
    </message>
    <message>
        <location filename="../gm_addscriptdialog.cpp" line="86"/>
        <source>&apos;%1&apos; installed successfully</source>
        <translation>&apos;%1&apos; sėkmingai įdiegtas</translation>
    </message>
</context>
<context>
    <name>GM_Icon</name>
    <message>
        <location filename="../gm_icon.cpp" line="29"/>
        <source>Open GreaseMonkey settings</source>
        <translation>Atverti GreaseMonkey nustatymus</translation>
    </message>
</context>
<context>
    <name>GM_Manager</name>
    <message>
        <location filename="../gm_manager.cpp" line="206"/>
        <source>GreaseMonkey</source>
        <translation>GreaseMonkey</translation>
    </message>
    <message>
        <location filename="../gm_manager.cpp" line="270"/>
        <source>&apos;%1&apos; is already installed</source>
        <translation>&apos;%1&apos; jau yra įdiegtas</translation>
    </message>
</context>
<context>
    <name>GM_Notification</name>
    <message>
        <location filename="../gm_notification.ui" line="45"/>
        <source>This script can be installed with the GreaseMonkey plugin.</source>
        <translation>Šis scenarijus negali būti įdiegtas, naudojant GreaseMonkey papildinį.</translation>
    </message>
    <message>
        <location filename="../gm_notification.ui" line="65"/>
        <source>Install</source>
        <translation>Įdiegti</translation>
    </message>
    <message>
        <location filename="../gm_notification.cpp" line="50"/>
        <source>Cannot install script</source>
        <translation>Nepavyko įdiegti scenarijaus</translation>
    </message>
    <message>
        <location filename="../gm_notification.cpp" line="58"/>
        <source>&apos;%1&apos; installed successfully</source>
        <translation>&apos;%1&apos; sėkmingai įdiegtas</translation>
    </message>
</context>
<context>
    <name>GM_Settings</name>
    <message>
        <location filename="../settings/gm_settings.ui" line="14"/>
        <source>GreaseMonkey Scripts</source>
        <translation>GreaseMonkey scenarijai</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="51"/>
        <source>&lt;h3&gt;GreaseMonkey Scripts&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;GreaseMonkey scenarijai&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="73"/>
        <source>Double clicking script will show additional information</source>
        <translation>Du kartus spustelėjus scenarijų, bus rodoma papildoma informacija</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="153"/>
        <source>More scripts can be downloaded from</source>
        <translation>Daugiau scenarijų gali būti atsisiųsta iš</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="196"/>
        <source>Open scripts directory</source>
        <translation>Atverti scenarijų katalogą</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.ui" line="203"/>
        <source>New user script</source>
        <translation>Naujas naudotojo scenarijus</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="90"/>
        <source>Remove script</source>
        <translation>Šalinti scenarijų</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="91"/>
        <source>Are you sure you want to remove &apos;%1&apos;?</source>
        <translation>Ar tikrai norite pašalinti &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="121"/>
        <source>Add script</source>
        <translation>Pridėti scenarijų</translation>
    </message>
    <message>
        <location filename="../settings/gm_settings.cpp" line="121"/>
        <source>Choose name for script:</source>
        <translation>Pasirinkite scenarijaus pavadinimą:</translation>
    </message>
</context>
<context>
    <name>GM_SettingsScriptInfo</name>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="85"/>
        <source>Name:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="55"/>
        <source>Version:</source>
        <translation>Versija:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="115"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="138"/>
        <source>Namespace:</source>
        <translation>Vardų erdvė:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="155"/>
        <source>Edit in text editor</source>
        <translation>Redaguoti teksto redaktoriuje</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="65"/>
        <source>Start at:</source>
        <translation>Paleidžiamas ties:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="45"/>
        <source>Description:</source>
        <translation>Aprašas:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="19"/>
        <source>Runs at:</source>
        <translation>Paleidžiamas puslapiuose:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.ui" line="128"/>
        <source>Does not run at:</source>
        <translation>Nepaleidžiamas puslapiuose:</translation>
    </message>
    <message>
        <location filename="../settings/gm_settingsscriptinfo.cpp" line="45"/>
        <source>Script Details of %1</source>
        <translation>Išsamesnė %1 scenarijaus Informacija</translation>
    </message>
</context>
</TS>