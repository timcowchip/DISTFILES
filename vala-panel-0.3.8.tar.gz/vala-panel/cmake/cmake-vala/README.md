#Elementary CMake modules

This is a set of CMake modules: Translations, GSettings, and Vala modules.

For all the Vala related modules see README.Vala.rst: 
* ParseArguments.cmake
* ValaPrecompile.cmake
* ValaVersion.cmake
* FindVala.cmake

By Athor:
* Modified Translations.cmake to support desktop files.
* Added GResource.cmake