This is git submodule for Vala-DBusMenu. Now it builds standalone as a set of object files.
