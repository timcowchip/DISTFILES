#ifndef APPLETINFO_H
#define APPLETINFO_H

#include <glib-object.h>
#include <glib.h>

#include "applet-widget.h"

G_BEGIN_DECLS

G_DECLARE_FINAL_TYPE(ValaPanelAppletInfo, vala_panel_applet_info, VALA_PANEL, APPLET_INFO, GObject)

G_END_DECLS

#endif // APPLETINFO_H
