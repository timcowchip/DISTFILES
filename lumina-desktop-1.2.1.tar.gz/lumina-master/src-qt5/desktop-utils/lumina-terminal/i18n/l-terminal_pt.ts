<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>TerminalWidget</name>
    <message>
        <location filename="../TerminalWidget.cpp" line="61"/>
        <source>Copy Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TerminalWidget.cpp" line="62"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../TrayIcon.cpp" line="123"/>
        <source>Trigger Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="125"/>
        <source>Top of Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="130"/>
        <source>Close Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="139"/>
        <source>Move To Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="142"/>
        <source>Monitor %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
