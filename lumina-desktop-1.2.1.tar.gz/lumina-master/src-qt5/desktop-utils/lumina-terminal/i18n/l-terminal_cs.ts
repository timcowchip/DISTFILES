<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs_CZ">
<context>
    <name>TerminalWidget</name>
    <message>
        <location filename="../TerminalWidget.cpp" line="61"/>
        <source>Copy Selection</source>
        <translation>Kopírovat výběr</translation>
    </message>
    <message>
        <location filename="../TerminalWidget.cpp" line="62"/>
        <source>Paste</source>
        <translation>Vložit</translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../TrayIcon.cpp" line="123"/>
        <source>Trigger Terminal</source>
        <translation>Spustit terminál</translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="125"/>
        <source>Top of Screen</source>
        <translation>Nahoře na obrazovce</translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="130"/>
        <source>Close Terminal</source>
        <translation>Zavřít terminál</translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="139"/>
        <source>Move To Monitor</source>
        <translation>Přesunout na obrazovku</translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="142"/>
        <source>Monitor %1</source>
        <translation>Obrazovka %1</translation>
    </message>
</context>
</TS>
