<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="el_GR">
<context>
    <name>TerminalWidget</name>
    <message>
        <location filename="../TerminalWidget.cpp" line="61"/>
        <source>Copy Selection</source>
        <translation>Αντιγραφή Επιλογής</translation>
    </message>
    <message>
        <location filename="../TerminalWidget.cpp" line="62"/>
        <source>Paste</source>
        <translation>Επικόλληση</translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../TrayIcon.cpp" line="123"/>
        <source>Trigger Terminal</source>
        <translation>Εμφάνιση/Απόκρυψη Γραμμής Εντολών</translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="125"/>
        <source>Top of Screen</source>
        <translation>Επάνω Μέρος της Οθόνης</translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="130"/>
        <source>Close Terminal</source>
        <translation>Κλείσιμο Γραμμής Εντολών</translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="139"/>
        <source>Move To Monitor</source>
        <translation>Μετακίνηση στην Οθόνη</translation>
    </message>
    <message>
        <location filename="../TrayIcon.cpp" line="142"/>
        <source>Monitor %1</source>
        <translation>Οθόνη %1</translation>
    </message>
</context>
</TS>
