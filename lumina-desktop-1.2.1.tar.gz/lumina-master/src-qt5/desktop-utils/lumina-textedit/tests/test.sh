#!/bin/sh

echo "some text" #with a comment
for i in ["a","b","c"]
do
echo ${i}withsometext
done

variable$variable sdfgbuj
variable${variable}satoibnsoin
