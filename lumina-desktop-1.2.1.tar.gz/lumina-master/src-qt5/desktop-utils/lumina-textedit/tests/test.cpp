Test(QString test){
 nestedFunction(){ }
}
if else done
return exit
bool float double

some stuff // in-line comment

some stuff /*multi
line
comment */
stuff

some /*single line comment with multi-line tags */

"some text"
"some text with url: http://sample.com"
