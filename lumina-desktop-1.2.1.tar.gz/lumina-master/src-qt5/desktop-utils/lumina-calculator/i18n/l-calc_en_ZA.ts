<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_ZA">
<context>
    <name>mainUI</name>
    <message>
        <location filename="../mainUI.ui" line="14"/>
        <location filename="../mainUI.cpp" line="53"/>
        <source>Calculator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.ui" line="657"/>
        <source>Advanced Operations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="77"/>
        <source>Percentage %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="79"/>
        <source>Power %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="81"/>
        <source>Base-10 Exponential %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="83"/>
        <source>Exponential %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="85"/>
        <source>Constant Pi %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="88"/>
        <source>Square Root %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="90"/>
        <source>Logarithm %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="92"/>
        <source>Natural Log %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="95"/>
        <source>Sine %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="97"/>
        <source>Cosine %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="99"/>
        <source>Tangent %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="102"/>
        <source>Arc Sine %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="104"/>
        <source>Arc Cosine %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="106"/>
        <source>Arc Tangent %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="109"/>
        <source>Hyperbolic Sine %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="111"/>
        <source>Hyperbolic Cosine %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="113"/>
        <source>Hyperbolic Tangent %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainUI.cpp" line="176"/>
        <source>Save Calculator History</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
