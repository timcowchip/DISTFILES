#!/bin/bash

cd ..

mv src/plugins/AccessKeysNavigation/translations/sr@{I,i}jekavian.ts
mv src/plugins/AutoScroll/translations/sr@{I,i}jekavian.ts
mv src/plugins/FlashCookieManager/translations/sr@{I,i}jekavian.ts
mv src/plugins/GnomeKeyringPasswords/translations/sr@{I,i}jekavian.ts
mv src/plugins/GreaseMonkey/translations/sr@{I,i}jekavian.ts
mv src/plugins/KWalletPasswords/translations/sr@{I,i}jekavian.ts
mv src/plugins/MouseGestures/translations/sr@{I,i}jekavian.ts
mv src/plugins/PIM/translations/sr@{I,i}jekavian.ts
mv src/plugins/StatusBarIcons/translations/sr@{I,i}jekavian.ts
mv src/plugins/TabManager/translations/sr@{I,i}jekavian.ts
mv src/plugins/TestPlugin/translations/sr@{I,i}jekavian.ts
mv translations/sr@{I,i}jekavian.ts

echo "Done"
