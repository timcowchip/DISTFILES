<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.1">
<context>
    <name>AKN_Settings</name>
    <message>
        <location filename="../akn_settings.ui" line="14"/>
        <source>Access Keys Navigation</source>
        <translation>Nawigacja klawiszami dostępu</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="20"/>
        <source>&lt;h1&gt;Access Keys Navigation&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Nawigacja klawiszami dostępu&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="33"/>
        <source>Ctrl</source>
        <translation>Ctrl</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="38"/>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="43"/>
        <source>Shift</source>
        <translation>Shift</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="51"/>
        <source>Double press</source>
        <translation>Dwukrotne kliknięcie</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="58"/>
        <source>Key for showing access keys:</source>
        <translation>Klawisz pokazujący klawisze dostępu:</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="103"/>
        <source>License</source>
        <translation>Licencja</translation>
    </message>
</context>
</TS>