<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs_CZ" version="2.1">
<context>
    <name>AKN_Settings</name>
    <message>
        <location filename="../akn_settings.ui" line="14"/>
        <source>Access Keys Navigation</source>
        <translation>Klávesové zkratky</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="20"/>
        <source>&lt;h1&gt;Access Keys Navigation&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Klávesové zkratky&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="33"/>
        <source>Ctrl</source>
        <translation>Ctrl</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="38"/>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="43"/>
        <source>Shift</source>
        <translation>Shift</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="51"/>
        <source>Double press</source>
        <translation>Dvojitý stisk</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="58"/>
        <source>Key for showing access keys:</source>
        <translation>Klávesa pro zobrazení zkratek:</translation>
    </message>
    <message>
        <location filename="../akn_settings.ui" line="103"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
</context>
</TS>