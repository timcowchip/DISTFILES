<?xml version="1.0" ?><!DOCTYPE TS><TS language="hu_HU" version="2.1">
<context>
    <name>AutoScrollSettings</name>
    <message>
        <location filename="../autoscrollsettings.ui" line="14"/>
        <source>AutoScroll Settings</source>
        <translation>Automatikus görgetés beállítások</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="68"/>
        <source>&lt;h1&gt;AutoScroll&lt;/h1&gt;</source>
        <translation>&lt;h1&gt;Automatikus görgetés&lt;/h1&gt;</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="105"/>
        <source>Scroll Divider:</source>
        <translation>Görgetés elosztás:</translation>
    </message>
    <message>
        <location filename="../autoscrollsettings.ui" line="134"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Setting higher divider will slow down scrolling</source>
        <translation>&lt;b&gt;Megjegyzés:&lt;/b&gt; A magasabb elosztás beállítása lassítja a görgetést</translation>
    </message>
</context>
</TS>